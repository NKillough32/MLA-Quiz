# MLA Combined
Generated on: 2025-09-19 09:25:30

## Specialty: General

### 1. Question 1
A 67 year old woman attends the emergency department with sudden onset of blurred vision. She is otherwise in good health with no history of eye disease and is taking no medication. Her right eye is normal. Visual acuity in her left eye is reduced and her left pupil reacts sluggishly to light. Her fundal photograph is shown (see image)

[IMAGE: image_001_MLA1_page2_image_2_2.png]

What is the most likely cause of her visual loss?

A. Branch retinal artery occlusion
B. Branch retinal vein occlusion
C. Central retinal artery occlusion
D. Central retinal vein occlusion
E. Optic neuritis

**Answer**: B

**Explanation**: The image shows the typical appearance of a branch retinal vein occlusion.

---
### 2. Question 2
A 78 year old man develops increasing confusion on the ward at night. He is wandering around naked asking for his wife, shouting, and threatening staff and patients. He was admitted earlier in the day with a productive cough and fever. He has idiopathic Parkinson disease. His temperature is 37.6°C, pulse 100 bpm, BP 132/71 mmHg and oxygen saturation 95% breathing air. His capillary blood glucose is 5 mmol/L. Attempts to calm him with nursing measures do not improve the situation and he begins hitting staff

What is the most appropriate treatment?

A. Amitriptyline
B. Haloperidol
C. Immediate release carbidopa-levodopa
D. Lorazepam
E. Risperidone

**Answer**: D

**Explanation**: This patient has delirium due to his LRTI, is aggressive, and is a danger to staff, other patients and himself. He requires sedation. Haloperidol is contra-indicated by his Parkinson's disease and the most appropriate agent is a benzodiazepine such as lorazepam.

---
### 3. Question 3
A 78 year old woman has had back pain for 2 weeks and bilateral leg weakness for 2 days. She had surgery for breast cancer 14 years ago. She had a minor fall at home a few days ago. She has weakness of hip flexion bilaterally with brisk knee reflexes, extensor plantar responses and reduced sensation to pinprick in her feet

What is the most likely diagnosis?

A. Lumbar disc prolapse
B. Mechanical back pain
C. Osteomalacia
D. Osteoporotic vertebral collapse
E. Spinal cord compression

**Answer**: E

**Explanation**: This patient has back pain and rapidly progressive bilateral lower limb weakness with upper motor neurone signs in her legs. This presentation is very suggestive of spinal cord compression, likely due to bony metastases from her breast cancer.

---
### 4. Question 4
A 28 year old man has polyuria and polydipsia. He has bipolar disorder for which he has taken lithium carbonate for 2 years

**Investigations:**
Sodium 145 mmol/L (135–146) Potassium 3.9 mmol/L (3.5–5.3) Serum osmolality 296 mOsmol/kg (275–295) Urinary osmolality 356 mOsmol/kg (350–1000) Fasting glucose 5.8 mmol/L (3.0–6.0) Serum lithium 0.75 mmol/L (0.5–1.2)

Initial What is the most appropriate next investigation?

A. 24-h urinary cortisol
B. Glucose tolerance test
C. Serum corrected calcium
D. Short Synacthen test
E. Water deprivation test

**Answer**: C

**Explanation**: It is likely that this patient has nephrogenic diabetes insipidus secondary to lithium therapy but this is more common with long-term use and it is essential to exclude hypercalcaemia (e.g. due to hyperparathyroidism) here before progressing to a water deprivation test.

---
### 5. Question 5
A 65 year old woman is seen in clinic 2 weeks following a stroke. CT scan of the head shows a left frontal lobe infarct. She is currently taking aspirin, atorvastatin and ramipril

**Investigations:**
ECG: atrial fibrillation, heart rate 68 bpm, otherwise normal.

What is the most appropriate long-term anti-thrombotic therapy?

A. Apixaban
B. Aspirin
C. Aspirin and dipyridamole
D. Clopidogrel
E. Ticagrelor

**Answer**: A

**Explanation**: Patients with a stroke and AF should start anticoagulation as secondary prevention, typically a DOAC agent such as apixaban started after 2 weeks of initial therapy with aspirin. This is covered in both NICE AF (2021 update) and stroke (2022 update) guidelines: https://www.nice.org.uk/guidance/NG128/chapter/recommendations https://www.nice.org.uk/guidance/NG196/chapter/recommendations#stroke- prevention

---
### 6. Question 6
A 49 year old man has 3 days of cough and fever. He undergoes haemodialysis three times per week. His temperature is 38.6°C, pulse 90 bpm, BP 122/80 mmHg, respiratory rate 30 breaths per minute and oxygen saturation 95% breathing 15 L/min oxygen via a non-rebreather mask. His JVP is 4 cm above the sternal angle. He has inspiratory crackles in the right mid and lower zone and left upper zone. His blood capillary glucose is 12 mmol/L

**Investigations:**
Sodium 131 mmol/L (135–146) Potassium 5.7 mmol/L (3.5–5.3) Urea 16.7 mmol/L (2.5–7.8) Creatinine 327 μmol/L (60–120) Chest X-ray: see image

[IMAGE: image_006_MLA1_page7_image_7_2.png]

What is the most appropriate initial treatment?

A. Haemodialysis
B. Intravenous 10 mL 10% calcium gluconate
C. Intravenous 1000 mL 0.9% sodium chloride over 1 h
D. Intravenous co-amoxiclav and clarithromycin
E. Intravenous furosemide

**Answer**: D

**Explanation**: This patient has severe pneumonia with evidence of multifocal consolidation on the chest X-ray. He requires treatment with antibiotics first. The other interventions are not indicated.

---
### 7. Question 7
A 67 year old man is due to have a CT scan of the chest, abdomen and pelvis with intravenous contrast as assessment for possible lymphoma. He had a renal transplant 5 years previously. He takes prednisolone, tacrolimus and lisinopril. His BP is 131/86 mmHg

**Investigations:**
Urea 12.9 mmol/L (2.5–7.8) Creatinine 165 µmol/L (60–120) eGFR 39 mL/min/1.73 m2 (>60)

What is the most appropriate treatment to give before the scan?

A. Intravenous 0.9% sodium chloride
B. Intravenous acetylcysteine
C. Intravenous furosemide
D. Intravenous hydrocortisone
E. Intravenous mannitol

**Answer**: A

**Explanation**: The patient is due to receive IV contrast and has existing CKD. He is an increased risk of contrast-induced nephropathy. Volume expansion with 0.9% sodium chloride infusion (1 mL/kg) is recommended and shown to reduce the incidence of contrast nephropathy. Some units still recommend oral acetylcysteine (although trial data is lacking), but IV acetylcysteine is no longer used due to a risk of anaphylactoid reactions. There is no indication for additional steroids. IV furosemide may increase the risk of contrast-induced nephropathy. IV mannitol is no longer used as there is no evidence of benefit.

---
### 8. Question 8
A 78 year old woman is admitted after being found collapsed at home. She has been lying on the floor overnight. She has hypertension and takes amlodipine. A urinary catheter is passed and she passes 60 mL of urine over the next 2 hours. Her temperature is 35.8°C, pulse 88 bpm and irregular, and BP 102/60 mmHg

**Investigations:**
Sodium 136 mmol/L (135–146) Potassium 5.8 mmol/L (3.5–5.3) Urea 20.9 mmol/L (2.5–7.8) Creatinine 180 μmol/L (60–120) Creatine kinase 870 U/L (25–175) Urinalysis: glucose negative, ketones negative, blood 2+, protein 1+, leucocytes positive (catheter sample). She is treated with trimethoprim for presumed urosepsis.

What is the most likely additional cause for her acute kidney injury?

A. Glomerulonephritis
B. Hypovolaemia
C. Renal arterial emboli
D. Rhabdomyolysis
E. Ureteric obstruction

**Answer**: B

**Explanation**: This patient has an AKI with hypotension and oliguria, likely due to hypovolaemia following a long lie without hydration and has probable urosepsis. The level of CK is compatible with minor soft tissue injury: rhabdomyolysis would normally be associated with a CK of >10,000. There are no indicators of glomerulonephritis and the urinalysis abnormalities are compatible with a catheter sample +/- urosepsis. Renal emboli are rare and usually associated with loin pain. Ureteric obstruction is unlikely as the patient is still passing some urine.

---
### 9. Question 9
A 76 year old woman has become increasingly confused over the previous 2 weeks. She has hypertension for which she takes bendroflumethiazide, doxazosin, amlodipine, ramipril and atenolol. Her BP is 108/71 mmHg

**Investigations:**
Sodium 121 mmol/L (135–146) Potassium 3.5 mmol/L (3.5–5.3) Urea 10.0 mmol/L (2.5–7.8) Creatinine 105 µmol/L (60–120)

Which medication is most likely to be responsible for her presentation?

A. Amlodipine
B. Atenolol
C. Bendroflumethiazide
D. Doxazosin
E. Ramipril

**Answer**: C

**Explanation**: Of the medications listed, bendroflumethiazide is most likely to cause hyponatraemia.

---
### 10. Question 10
A 92 year old woman has severe neck, chest and back pain following a fall. She has bruising around her right eye

**Investigations:**
Full blood count and clotting screen: normal Chest X-ray: lung fields clear, left sided 4th and 5th rib fractures CT scan of head: no intracranial injury or bleed, mild small vessel disease, right orbital fracture

What is the most appropriate next investigation?

A. Cervical spine X-ray
B. CT angiography
C. CT scan of chest
D. CT scan of neck
E. MR scan of brain

**Answer**: D

**Explanation**: The history suggests a possible cervical spine fracture. This is best detected by a CT scan of the neck.

---
### 11. Question 11
A 64 year old woman develops an acutely painful right knee 3 weeks after a prosthetic right knee replacement. Her temperature is 38.2°C and pulse 103 bpm. Her right knee is inflamed with serous fluid discharging from the lower end of the wound

What is the most likely causative organism?

A. Corynebacterium species
B. Enterococcus species
C. Pseudomonas aeruginosa
D. Staphylococcus aureus
E. Streptococcus pyogenes

**Answer**: D

**Explanation**: Staphylococcus aureus is responsible for 20-25% of prosthetic joint infections, with coagulase negative staph next (not included on list). The other bacterial causes would be rare.

---
### 12. Question 12
A 52 year old man has 3 months of fatigue. He has ulcerative colitis and takes mesalazine. He drinks 20 units of alcohol per week. His temperature is 36.8°C and pulse 80 bpm. He has 3 cm hepatomegaly

**Investigations:**
Albumin 36 g/L (35–50) ALT 65 IU/L (10–50) ALP 580 IU/L (25–115) Bilirubin 18 µmol/L (<17) γGT 230 IU/L (9–40) Ultrasound scan of abdomen: bile duct wall thickening and dilatation

What is the most appropriate next diagnostic investigation?

A. CT scan of abdomen
B. Endoscopic retrograde cholangiopancreatography
C. Liver biopsy
D. MR cholangiopancreatography
E. Percutaneous transhepatic cholangiography

**Answer**: D

**Explanation**: The patient has a classic cholestatic pattern of blood test abnormalities. Primary sclerosing cholangitis often has limited symptoms at presentation, and bilirubin and albumin are often normal. There is a strong association with UC. Ultrasound shows evidence of abnormal bile ducts. MRCP is the typical initial diagnostic investigation as it is non-invasive: this usually shows typical beaded appearance of the bile duct.

---
### 13. Question 13
A 60 year old woman has 6 weeks cough productive of blood streaked sputum

**Investigations:**
CT scan of chest: mass in left lower lobe. Needle biopsy: nuclei that are enlarged, hyperchromatic and pleomorphic.

What is the most likely diagnosis?

A. Adenoma
B. Carcinoma
C. Hamartoma
D. Sarcoidosis
E. Tuberculosis

**Answer**: B

**Explanation**: This is because nuclear enlargement, hyperchromasia and pleomorphism are features that suggest carcinoma in all sites of the body.

---
### 14. Question 14
A 65 year old woman has an infective exacerbation of COPD and has been treated with nebulised bronchodilators, antibiotics and steroids. She is alert. Her temperature is 37.8°C, pulse 108 bpm, BP 100/75mmHg, respiratory rate 26 breaths per minute and oxygen saturation 88% breathing 15 L/minute oxygen via a non-rebreather mask

**Investigations:**
Arterial blood gas on 15 L/min oxygen pH 7.28 (7.35–7.45) PO2 7.2 kPa (11–15) PCO2 8.9 kPa (4.6–6.4) Bicarbonate 31.3 mmol/L (22–30) Lactate 1.2 mmol/L (1–2)

What is the most appropriate next management step?

A. Continuous positive airway pressure
B. Invasive ventilation
C. Nasal high flow oxygen
D. Nasopharyngeal airway
E. Non-invasive ventilation

**Answer**: E

**Explanation**: This patient has acute type-2 respiratory failure: respiratory acidosis needs to be corrected with ventilation in an alert patient.

---
### 15. Question 15
A 79 year old man attends the Emergency Department with 2 hours of chest pain and light-headedness. His ECG is shown (see image)

[IMAGE: image_015_MLA1_page17_image_17_2.png]

What is the most likely explanation for the ECG findings?

A. Aortic dissection
B. Hyperkalaemia
C. Myocardial infarction
D. Pericarditis
E. Pulmonary embolism

**Answer**: C

**Explanation**: The ECG shows typical changes of an anterior STEMI.

---
### 16. Question 16
A 50 year old woman has acute onset of breathlessness. She underwent a laparoscopic cholecystectomy 10 days ago. Her temperature is 37.4°C, pulse 104 bpm, BP 122/80 mmHg, respiratory rate 24 breaths per minute and oxygen saturation 94% breathing air. Her chest is clear. She has minimal tenderness over the right hypochondrium

What is the most likely diagnosis?

A. Myocardial infarction
B. Pancreatitis
C. Pneumonia
D. Pulmonary embolus
E. Subphrenic abscess

**Answer**: D

**Explanation**: This patient has acute dyspnoea with a low O2 saturation despite tachypnoea, and also has a tachycardia and clinically clear chest. Following abdominal surgery, pulmonary embolism is the most likely diagnosis.

---
### 17. Question 17
A 39 year old man has had fever, chills and generalised weakness for 1 month. He has a systolic heart murmur. He is an intravenous drug user. 

**Investigations:**
White cell count 15 × 109/L (4.0–11.0) C reactive protein. 88 mg/L (< 5) Blood culture results are awaited

What further investigation will help to establish the diagnosis?

A. Chest X-ray
B. ECG
C. Echocardiogram
D. HIV testing
E. Urine dipstick analysis

**Answer**: C

**Explanation**: The presentation is very suggestive of infective endocarditis and the patient requires an urgent echocardiogram to establish the diagnosis (Duke major criterion). The other investigations are important (CXR to exclude septic lung emboli from the TcV; ECG for first degree heart block (aortic root abscess); urinalysis for haematuria (nearly always seen in IE); HIV testing (IVDU)) but are not key to making the central diagnosis.

---
### 18. Question 18
A 16 year old girl attends the emergency department after an episode of loss of consciousness following a fall. She had consumed an excessive amount of alcohol at a party before the fall. She has a dirty scalp wound and cannot remember recent events. Her pulse is 68 bpm, BP 110/80 mmHg and oxygen saturation 98% breathing air. She opens her eyes to command and is confused. Her capillary blood glucose is 6.0 mmol/L. Her wound is cleaned and sutured

What is the most appropriate immediate management plan?

A. Admit and observe for 24h
B. CT scan of head
C. Discharge with head injury instructions
D. Refer to neurosurgeon
E. X-ray of skull

**Answer**: B

**Explanation**: For people 16 and over who have had some loss of consciousness or amnesia since the injury, a CT head scan within 8 hours of the head injury is recommended. A child of 16 doesn't need a tetanus booster NICE guideline [NG232] Published: 18 May 2023 https://www.nice.org.uk/guidance/ng232/chapter/recommendations

---
### 19. Question 19
A 47 year old woman has had 1 year of increased urinary frequency, urgency and nocturia. She leaks urine if she cannot get to the toilet promptly. She had three normal pregnancies with no complications. The perineum appears normal and there is no uterine prolapse. Incontinence is not provoked by coughing or straining. Urinalysis is negative. A post-micturition ultrasound scan of bladder shows minimal residual urine volume. Her symptoms do not improve following 6 weeks of bladder training

What is the most appropriate next management step?

A. Botulinum toxin type A injection into bladder wall
B. Oral duloxetine
C. Oral oxybutynin
D. Percutaneous sacral nerve stimulation
E. Topical oestrogen

**Answer**: C

**Explanation**: If behavioural therapies such as bladder training for 6 weeks are ineffective at controlling symptoms, anticholinergics are the next step treatment for overactive bladder with urge incontinence. NICE guidance (updated in 2025): https://cks.nice.org.uk/topics/incontinence-urinary-in- women/management/managing-urinary-incontinence/

---
### 20. Question 20
A 72 year old woman has 6 months of constipation

**Investigations:**
Creatinine 70 µmol/L (60–120) Calcium 2.90 mmol/L (2.2–2.6) Phosphate 0.65 mmol/L (0.8–1.5) 24 h urinary calcium 7.0 mmol (2–6) Parathyroid hormone 11.2 pmol/L (1.6–8.5) Vitamin D 65 nmol/L (>60)

What is the most likely diagnosis?

A. Familial hypocalciuric hypercalcaemia
B. Multiple myeloma
C. Primary hyperparathyroidism
D. Tertiary hyperparathyroidism
E. Vitamin D intoxication

**Answer**: C

**Explanation**: The biochemical pattern of hypercalcaemia, hypophosphataemia, elevated PTH and hypercalciuria point towards primary hyperparathyroidism. Tertiary hyperparathyroidism occurs with severe renal impairment. Primary Hyperparathyroidism is commoner in older female patients: in most cases symptoms are typically either mild or absent.

---
### 21. Question 21
A 52 year old man attends his GP for health screening. He is well with no previous medical history. His pulse is 80 bpm and irregular, and BP 128/84 mmHg

**Investigations:**
Sodium 136 mmol/L (135–146) Potassium 3.9 mmol/L (3.5–5.3) Urea 4.9 mmol/L (2.5–7.8) Creatinine 80 μmol/L (60–120) HbA1C 40 mmol/mol (20–42) Thyroid function tests are normal. ECG shows atrial fibrillation, heart rate 76 bpm.

What is the most appropriate medication?

A. Apixaban
B. Aspirin
C. Bisoprolol
D. Diltiazem hydrochloride
E. No medication

**Answer**: E

**Explanation**: The patient has an incidental finding of AF and is asymptomatic with a satisfactory resting heart rate. He does not require any rate-modulating medication. His CHA2DS2-VASc score is 0 and he does not require antithrombotic therapy. NICE topics revised 2025: https://cks.nice.org.uk/topics/atrial-fibrillation/

---
### 22. Question 22
An 80 year old man attends the emergency department with 2 hours of epistaxis that has not stopped despite compression. He has hypertension. A bleeding site is visible in the anterior nasal cavity. His BP is 160/95 mmHg

What is the most appropriate initial management option?

A. Anterior pack
B. Antihypertensive medication
C. Cautery
D. Cryotherapy
E. Ice pack

**Answer**: C

**Explanation**: Minor bleeding from an accessible site can be treated with cautery using a silver nitrate stick or electrocautery. Anterior pack is for profuse bleeding with site difficult to localise. Anti hypertensives will only prevent further attacks of epistaxis. Cryotherapy and ice pack of little advantage and secondary.

---
### 23. Question 23
A 65 year old man has abdominal distension and vomiting 48 hours after a sigmoid colectomy with primary anastomosis for bowel cancer. He has not passed any flatus for 24 hours. He is taking regular paracetamol and as required intravenous morphine. His temperature is 37.6°C, pulse 96 bpm and BP 122/85 mmHg. His abdomen is distended with tenderness over the wound but no rebound or guarding. There are no bowel sounds

What is the most appropriate initial management?

A. Give intravenous piperacillin with tazobactam
B. Give Microlax® enema
C. Insert a nasogastric tube
D. Start regular intravenous morphine
E. Take to theatre for laparotomy

**Answer**: C

**Explanation**: The patient has evidence of a paralytic ileus. The initial treatment would involve making patient nil by mouth and inserting a nasogastric tube. Morphine would make the condition worse. There is no indication for antibiotics. An enema would not be appropriate and unlikely to be of benefit. There is no indication for immediate surgery as further investigations will be required to identify treatable causes.

---
### 24. Question 24
A 23 year old man attends the sexual health clinic with a painful swelling in his groin and pain when opening his bowels. He had unprotected anal sex with a new male partner 4 weeks ago. He has a perianal ulcer and tender inguinal lymphadenopathy

What is the most likely diagnosis?

A. Genital herpes
B. Gonorrhoea
C. HIV seroconversion
D. Lymphogranuloma venereum
E. Secondary syphilis

**Answer**: D

**Explanation**: Proctitis and lymphadenopathy make LGV the most likely, and is endemic in MSM population in UK.

---
### 25. Question 25
A 63 year old man has pain of sudden onset in the right side of his chest radiating to the right shoulder and increasing breathlessness. He has mild COPD and has had a hacking cough for 2 days. Chest X-ray: see image

[IMAGE: image_025_MLA1_page27_image_27_2.png]

What is the most likely cause of his acute deterioration?

A. Diaphragmatic hernia
B. Lobar pneumonia
C. Oesophageal rupture
D. Pneumothorax
E. Pulmonary embolus

**Answer**: D

**Explanation**: The chest X-ray shows a large right-sided pneumothorax.

---
### 26. Question 26
A 25 year old man attends the emergency department after vomiting a large quantity of blood. At endoscopy, there is a deep ulcer in the posterior wall at the junction of the first and second parts of the duodenum, with a bleeding vessel in its base

From which artery is the bleeding most likely to be arising?

A. Gastroduodenal
B. Left gastric
C. Short gastric
D. Splenic
E. Superior mesenteric

**Answer**: A

**Explanation**: The gastroduodenal artery runs posterior to the first and second parts of the duodenum and may be a source of major haemorrhage in peptic ulcer disease.

---
### 27. Question 27
A 27 year old woman has a long history of irregular menstruation. She does not take any medication. Her BMI is 29.4 kg/m2

**Investigations:**
LH (pre-menopausal female) 15 U/L (follicular) (1–11) FSH 6 U/L (follicular) (2–8) Testosterone 3.5 nmol/L (0.2–2.9) Cortisol post 1 mg dexamethasone 40 nmol/L (<50) Prolactin 425 U/L (100–500)

What is the most likely diagnosis?

A. Androgen secreting tumour
B. Cushing syndrome
C. Polycystic ovary syndrome
D. Premature ovarian failure
E. Prolactinoma

**Answer**: C

**Explanation**: The increased ratio of LH:FSH along with oligomenorrhoea and BMI in the overweight range indicates PCOS is most likely. A mild elevation in prolactin is sometimes seen in PCOS.

---
### 28. Question 28
A 30 year old woman attends her GP 3 months after a diagnosis of iron deficiency anaemia. She was advised to take oral iron supplements and has been taking these regularly. She has some looseness of her stools. Her periods are scanty on a combined oral contraceptive

**Investigations:** 
Haemoglobin 92 g/L (115–165) MCV 70 fL (80–96) Ferritin 8 µg/L (12–200) What antibody test is most likely to confirm the underlying cause?

A. Anti-gastric parietal cell
B. Antimitochondrial
C. Antinuclear
D. Anti-smooth muscle
E. Anti-tissue transglutaminase

**Answer**: E

**Explanation**: Coeliac disease is the most likely diagnosis here with an iron deficiency anaemia and no significant source of blood loss.

---
### 29. Question 29
A 75 year old man is admitted with weakness in his legs. He has a squamous cell lung cancer treated by radiotherapy 18 months ago. He is cachectic. He has 4 out of 5 strength in hip flexion and knee flexion bilaterally. Sensation and reflexes are normal, and sphincter function is preserved. His BMI is 17 kg/m2. MR scan of spine shows destructive bony lesions of T12 and of L2, L3 and L4 vertebral bodies

What treatment is most appropriate to preserve neurological function?

A. Chemotherapy
B. External beam radiotherapy
C. Intravenous bisphosphonate
D. Radiation brachytherapy
E. Surgical decompression of the spinal cord

**Answer**: B

**Explanation**: The history and examination findings suggest early cord compression from metastatic lung cancer. He has multiple lesions and is too frail for surgery. Radiotherapy is best treatment option.

---
### 30. Question 30
A 34 year old woman has had headaches for 3 months. Her mother developed hypertension at the age of 38 years. Her BP is 180/92 mmHg. Fundoscopy is normal

**Investigations:**
Sodium 136 mmol/L (135–146) Potassium 3.3 mmol/L (3.5–5.3) Chloride 97 mmol/L (95–106) Urea 4.0 mmol/L (2.5–7.8) Creatinine 94 µmol/L (60–120) Plasma aldosterone:renin ratio 50 (<25) Cortisol (9am) 307 nmol/L (200–700) Urinalysis is normal.

What is the most likely diagnosis?

A. Essential hypertension
B. Glucocorticoid excess
C. Phaeochromocytoma
D. Primary hyperaldosteronism
E. Primary hypoadrenalism

**Answer**: D

**Explanation**: FHx of hypertension and biochemistry suggest mineralocorticod excess with a high PRA ratio.

---
### 31. Question 31
A 20 year old man has had 2 days of visible haematuria. Three days before the haematuria started, he developed tonsillitis and was treated with phenoxymethylpenicillin. His BP is 112/54 mmHg

**Investigations:**
Urea 3.2 mmol/L (2.5–7.8) Creatinine 61 µmol/L (60–120) Urinalysis: glucose negative, ketones negative, blood 3+, protein 3+, nitrites negative, leucocytes negative.

What is the most likely cause of his haematuria?

A. Alport nephropathy
B. Drug reaction
C. Granulomatosis with polyangiitis
D. IgA nephropathy
E. Postinfectious glomerulonephritis

**Answer**: D

**Explanation**: IgA characteristically causes visible haematuria a few days after URTI (post-infectious GN has lag time of around 2 weeks before haematuria occurs and would be a less benign presentation if associated with visible haematuria).

---
### 32. Question 32
A 38 year old man has had 2 months of epigastric pain that radiates into his back. It is worse at night and sometimes wakes him up. It is better after eating. He has been very busy at work. He occasionally misses lunch, which worsens the pain. He has not lost weight. He smokes 10 cigarettes per day and drinks two bottles of wine per week. Examination is normal

What is the most likely diagnosis?

A. Cholecystitis
B. Chronic pancreatitis
C. Duodenal ulcer
D. Gastric ulcer
E. Gastric carcinoma

**Answer**: C

**Explanation**: Duodenal ulcers tend to be made worse with stress and the pain is often worse at night radiating into the back - it is relieved by eating and patients tend to put weight on - in contrast to a gastric ulcer which is made worse with eating and people often lose weight.

---
### 33. Question 33
A 26 year old woman has had 12 months of back pain, located in the low lumbosacral region. She has intermittent bilateral thigh pain. The back pain disturbs her sleep. It is improved by activity but not relieved by resting. She finds it difficult to bend down to pick things up from the floor

Which clinical feature is most specific for inflammatory back pain?

A. Improvement with activity
B. Nocturnal pain
C. Radiation to leg
D. Stiffness during the day
E. Young age

**Answer**: A

**Explanation**: Inflammatory back pain (IBP) is typically improved with activity and not relieved by rest, as opposed to mechanical pain which is worse with activity and is relieved by rest. IBP can wake the patient in the early hours of the morning and sacroiliitis can radiate to the thigh, but these features are much less specific. Morning stiffness is specific for inflammatory back pain but not persistent daytime stiffness. IBP can occur at any age although mechanical pain is less common in young people.

---
### 34. Question 34
A 68 year old man has had a swollen tender knee for 3 days and cannot weight bear. He has had previous episodes of big toe swelling. He has chronic kidney disease stage 4

**Investigations:**
Fluid analysis of knee aspirate: White cell count 55 000/mL, 95% neutrophils Gram stain negative Copious 10 μm intracellular needle shaped crystals

What is the best initial treatment for his acute knee pain and swelling?

A. Arthroscopic joint washout
B. Intravenous flucloxacillin
C. Oral allopurinol
D. Oral naproxen
E. Oral prednisolone

**Answer**: E

**Explanation**: The presentation is likely due to an acute attack of gout. Although infection is not completely excluded at this stage it is less likely as G stain is negative and there are several positive features of gout in the history. IA or oral steroids, colchicine or NSAIDs are all effective treatments for acute gout. NSAIDs are contraindicated in CKD of this stage. Allopurinol will not help the acute attack.

---
### 35. Question 35
An 18 year old man is in the intensive care unit with septic shock as a result of a compound fracture of his leg. His urine output has been <30 mL for the past 2 hours. His pulse is 125 bpm, BP 85/40 mmHg and JVP 4 cm above the sternal angle. There are basal crackles on auscultation of the chest

**Investigations:**
ECG shows sinus rhythm, 125 bpm. He is being treated with intravenous 0.9% sodium chloride at 125 mL/h and antibiotics.

What is the most appropriate additional intravenous treatment?

A. 500 mL 0.9% sodium chloride over 15 min
B. 500 mL Hartmann solution over 15 min
C. Dopamine hydrochloride
D. Furosemide
E. Noradrenaline/norepinephrine

**Answer**: E

**Explanation**: Description of adequate (if not over) hydration, needs vasoconstriction.

---
### 36. Question 36
A 34 year old man has had pain in his right shoulder and upper arm for 6 weeks that worsens when elevating his arm above his head. He does not recall any injury. There is no deformity, tenderness or reduced range of movement. There is pain on abduction of the right shoulder that is worse with the arm in internal rotation and when abduction is resisted. He is treated with ibuprofen

What is the most appropriate next step in management?

A. MR scan of shoulder
B. Refer for orthopaedic opinion
C. Refer for physiotherapy
D. Ultrasound scan of shoulder
E. X-ray of shoulder

**Answer**: C

**Explanation**: Clinically the diagnosis is right supraspinatus tendinopathy and no further investigation is required to confirm the diagnosis. Most cases can be managed in primary care and a referral to orthopaedics is not required. The most appropriate management is either general advice and home exercises or referral to a physiotherapist.

---
### 37. Question 37
A 65 year old woman has advanced carcinoma of the breast with cerebral and liver metastases, and is rapidly deteriorating. She is recognised to be dying. She has become confused and agitated

What is the most suitable initial treatment?

A. Diamorphine hydrochloride
B. Glycopyrronium
C. Hyoscine hydrobromide
D. Midazolam
E. Mirtazapine

**Answer**: D

**Explanation**: Terminal restlessness is a common and distressing condition that requires active management. The diagnosis of dying has already been made and reversible causes of her deterioration will thus have been considered and excluded. Terminal restlessness should be managed with Midazolam by PRN subcutaneous injections / continuous subcutaneous infusion via a syringe driver. NICE guideline [NG31] Published: 16 December 2015

---
### 38. Question 38
A 80 year old man has progressive memory loss over 2 years. He scores 20/30 on the Montreal Cognitive Assessment. The doctor suspects early Alzheimer disease and requests an MR scan of brain

In which part of the brain are changes most likely?

A. Basal ganglia
B. Frontal lobe
C. Medulla oblongata
D. Parietal lobe
E. Temporal lobe

**Answer**: E

**Explanation**: In early Alzheimer disease, the most likely area of the brain to show changes on an MRI scan is the temporal lobe, particularly the hippocampus. The hippocampus is crucial for memory formation, and its early involvement corresponds with the progressive memory loss characteristic of Alzheimer disease. Atrophy in this region is commonly observed and serves as a key indicator supporting the diagnosis of Alzheimer disease.

---
### 39. Question 39
A 43 year old woman is admitted to hospital with an overdose of amitriptyline taken 4 hours ago. She has a history of chronic headache. Her pulse is 105 bpm and BP 95/40 mmHg. She is drowsy and her pupils are dilated. ECG shows significant QRS prolongation

What is the most appropriate immediate management?

A. Activated charcoal
B. Intravenous amiodarone
C. Intravenous atropine
D. Intravenous magnesium
E. Intravenous sodium bicarbonate

**Answer**: E

**Explanation**: Bicarbonate is the treatment of the choice in patients with prolonged QRS complexes following a tricyclic antidepressant overdose.

---
### 40. Question 40
A 76 year old man undergoes an abdominoperineal resection for a low rectal carcinoma. He has severe COPD and hypertension

What is the most appropriate method for providing analgesia during the early postoperative period?

A. Epidural anaesthesia
B. Intramuscular opioid
C. Oral non-steroidal analgesia
D. Patient controlled intravenous analgesia
E. Spinal anaesthesia

**Answer**: A

**Explanation**: This is because for major abdominal surgery in respiratory disease opioid, by whatever route, should be avoided. Epidural is best because it can be topped up and titrated; spinal anaesthesia cannot. Transcutaneous electrical nerve stimulation has been used for post-operative pain, but trial results are contradictory. Intramuscular injection is difficult to titrate.

---
### 41. Question 41
A 75 year old woman becomes breathless while receiving the third unit of a blood transfusion. She was admitted with melaena and her haemoglobin was 65 g/L (115–150). She has ischaemic heart disease and takes aspirin and lisinopril. Her temperature is 37.3°C, pulse 96 bpm, BP 120/80 mmHg, respiratory rate 30 breaths per minute and oxygen saturation 90% breathing air. Chest auscultation reveals bibasal inspiratory crackles and occasional wheeze. She is treated with high flow oxygen and the blood transfusion is stopped

What is the most appropriate additional treatment?

A. Intramuscular adrenaline/epinephrine
B. Intravenous chlorphenamine maleate
C. Intravenous furosemide
D. Intravenous hydrocortisone
E. Nebulised salbutamol

**Answer**: C

**Explanation**: This patient has Transfusion-Associated Circulatory Overload (TACO). Treatment is with an IV loop diuretic.

---
### 42. Question 42
A researcher is seeking to examine whether long-term mobile phone use is linked to the risk of developing vestibular schwannoma (acoustic neuroma). The information on mobile phone usage is collected from participants with vestibular schwannoma and a comparable group of participants without vestibular schwannoma, selected from the general practice register

What type of study design is being used?

A. Case–control study
B. Case series
C. Cohort study
D. Cross-sectional study
E. Ecological study

**Answer**: A

**Explanation**: This is a typical description of a case-control study.

---
### 43. Question 43
A 56 year old woman has home blood pressure readings averaging 160/90 mmHg. She has type 1 diabetes mellitus. 

**Investigations:** 
Urinary albumin: creatinine ratio 42 mg/mmol (<3.5) eGFR 43 mL/min/1.73 m2 (>60) Hypertension is confirmed on 24 hour ambulatory monitoring

What class of antihypertensive drug is most appropriate?

A. ACE inhibitor
B. Alpha blocker
C. Beta blocker
D. Calcium channel blocker
E. Thiazide-like diuretic

**Answer**: A

**Explanation**: There is good evidence for renal function protection in diabetic nephropathy with ACE-1 in addition to its hypertensive properties.

---
### 44. Question 44
A 70 year old man has had a dry cough and breathlessness on exertion for 3 months. He has lost 4 kg in weight. He has ischaemic heart disease and atrial fibrillation. He takes apixaban, ramipril and amiodarone. He has never smoked cigarettes. His temperature is 37.5°C, pulse 70 bpm, respiratory rate 18 breaths per minute and oxygen saturation 91% breathing air. He has fine bibasal inspiratory crackles. There is no finger clubbing. 

**Investigations:** 
Haemoglobin 141 g/L (130–175) White cell count 14.0 × 109/L (3.0–10.0) Erythrocyte sedimentation rate 65 mm/hr (<20) Chest X-ray shows reticular opacities in both bases

What investigation is most likely to confirm the diagnosis?

A. Blood cultures
B. Bronchoscopy
C. Echocardiography
D. High resolution CT scan of chest
E. Induced sputum for microscopy and culture

**Answer**: D

**Explanation**: This is because the patient has pulmonary fibrosis as a complication from amiodarone therapy. This classically does not cause clubbing. Patients present with cough and dyspnoea. Fever and reactive blood changes (raised WCC, ESR) are not uncommon. An HRCT would confirm changes of interstitial lung disease. Blood cultures are indicated but this is unlikely to be an infective cause. Bronchoscopy is not indicated. The features are not those of heart failure so an echo will not confirm the diagnosis. An induced sputum is not indicated at this stage.

---
### 45. Question 45
A 31 year old woman is admitted with 24 hours of confusion. She is having visual hallucinations of snakes and mice on the floor. Her partner says that she often drinks 80 units of alcohol per week. He has not seen her for the past week. She has depression and takes fluoxetine. Her temperature is 37.6°C, pulse 100 bpm and BP 162/98 mmHg. She is disorientated in time and place but has no focal neurological deficit

What is the most likely diagnosis?

A. Delirium tremens
B. Fluoxetine overdose
C. Hepatic encephalopathy
D. Korsakoff psychosis
E. Wernicke encephalopathy

**Answer**: A

**Explanation**: The patient has typical features of delirium tremens with confusion, visual hallucinations, tachycardia and pyrexia on the background of heavy alcohol use. This normally occurs on reduction or abstinence, which may not be clear from the history.

---
### 46. Question 46
A 61 year old woman is admitted with 2 days of confusion. She has hypertension and takes nifedipine. She smokes 20 cigarettes per day. She is confused but has no focal neurological deficit. Her pulse is 75 bpm, BP 139/87 mmHg and JVP 2 cm above the sternal angle

**Investigations:**
Sodium 117 mmol/L (135–146) Potassium 4.2 mmol/L (3.5–5.3) Urea 1.9 mmol/L (2.5–7.8) Creatinine 57 μmol/L (60–120) Serum osmolality 252 mOsmol/kg (285–295) Urine osmolality 585 mOsmol/kg (100–1000)

What mechanism best explains the development of hyponatraemia?

A. Increased sodium secretion in the distal tubule
B. Increased water absorption in the collecting duct
C. Increased water ingestion
D. Reduced cortisol secretion
E. Reduced sodium reabsorption in the proximal tubule

**Answer**: B

**Explanation**: The picture is of syndrome of inappropriate ADH secretion with hyponatraemia and inappropriately concentrated urine. ADH stimulates synthesis of aquaporin-2 channels in the apical membrane of the collecting duct which promotes water absorption. This leads to a dilutional hyponatraemia.

---
### 47. Question 47
A 43 year old woman has a sudden severe headache that started 24 hours ago. She has autosomal dominant polycystic kidney disease. Her temperature is 36.8°C, pulse 92 bpm and BP 140/100 mmHg. Neurological examination is normal. CT scan of head is normal

What is the most appropriate next step in management?

A. Erythrocyte sedimentation rate
B. Lumbar puncture
C. MR scan of brain
D. Refer to outpatient headache clinic
E. Start amlodipine

**Answer**: B

**Explanation**: This is because APKD is associated with subarachnoid haemorrhage. A lumbar puncture should be performed. MRA would be reasonable, but not MRI.

---
### 48. Question 48
A 74 year old man has progressively worsening muscle aches that are now causing him to struggle to get up from a chair or raise his arms above his head. He has oesophageal cancer, treated surgically, and ischaemic heart disease. He takes bisoprolol, clopidogrel, ramipril and simvastatin

**Investigations:**
Haemoglobin 125 g/L (130–175) White cell count 7.8 × 109/L (3.0–10.0) Platelets 391 × 109/L (150–400) Erythrocyte sedimentation rate 105 mm/hr (<20)

What is the most appropriate therapeutic change?

A. Start co-codamol
B. Start ibuprofen
C. Start prednisolone
D. Stop bisoprolol
E. Stop simvastatin

**Answer**: C

**Explanation**: Classical PMR history, presentation and raised inflammatory markers.

---
### 49. Question 49
A 59 year old woman has had 6 months of pain affecting her hips and lower back. She is from Libya and has lived in the UK for 10 years. She has chronic kidney disease stage 3 and hypertension. She takes lisinopril and simvastatin. She has weakness of hip flexion bilaterally. There is no muscle or bony tenderness. 

**Investigations:** 
Urea 7.8 mmol/L (2.5–7.8) Creatinine 122 μmol/L (60–120) Calcium 2.1 mmol/L (2.2–2.6) eGFR 41 mL/min/1.73 m2 (>60) Alkaline phosphatase 230 IU/L (25–115) Parathyroid hormone 14.5 pmol/L (1.6–85) 

What additional investigation is most likely to confirm the diagnosis?

A. Creatine kinase
B. Erythrocyte sedimentation rate
C. Serum 25-OH cholecalciferol
D. Ultrasound scan of neck
E. X-ray of thoracic and lumbar spine

**Answer**: C

**Explanation**: The clinical features suggest osteomalacia. She has hypocalcaemia and proximal muscle weakness. The low serum calcium is not adequately explained by CKD. Serum vitamin D would establish the diagnosis. 24 hour urinary calcium is sometimes performed in primary hyperparathyroidism but not in a secondary case such as this. The presentation is not one of myositis and this is unlikely to be significantly elevated. Ultrasound of neck is another primary hyperparathyroidism test. The lumbar spine X-ray is most likely to show osteopenia but does not give diagnostic features (unlike in children).

---

### 50. Question 50
A 73 year old man collapses on the surgical ward 24 hours after having a sigmoid volvulus reduced by sigmoidoscopy. He has no pulse. ECG shows asystole. Chest compressions and ventilation are started. The cardiac arrest team are with the patient

What is the most appropriate next step in management?

A. Cardiac defibrillation
B. Intravenous 0.9% sodium chloride
C. Intravenous adrenaline/epinephrine
D. Intravenous atropine
E. Transcutaneous pacing

**Answer**: C

**Explanation**: Epinephrine the only recommended treatment for asystole. Atropine no longer recommended.

---
### 51. Question 51
A 78 year old woman has pain in both shoulders, hips and thighs. She is very stiff on waking in the morning and takes 2–3 hours to loosen up. She finds getting dressed difficult

**Investigations:**
Erythrocyte sedimentation rate 67 mm/hr (<20) CRP 87 mg/L (<5)

What is the most appropriate initial treatment?

A. Co-codamol
B. Leflunomide
C. Methotrexate
D. Naproxen
E. Prednisolone

**Answer**: E

**Explanation**: The scenario describes typical features of polymyalgia rheumatica, which responds well to prednisolone. No features to suggest inflammatory arthritis. Naproxen would not be indicated. Cocodamol will not deal with the cause.

---
### 52. Question 52
A 36 year old man is rescued from a house fire. He is alert and talking but has a dull headache. His pulse is 98 bpm, BP 139/86 mmHg, respiratory rate 22 breaths per minute and oxygen saturation 100% breathing 15 L/min oxygen via a non-rebreather mask

What is the most appropriate investigation?

A. Bicarbonate
B. Carboxyhaemoglobin
C. Haemoglobin
D. Lactate
E. Methaemoglobin

**Answer**: B

**Explanation**: Carbon monoxide inhalation likely. Will not show on pulse oximeter as is read as oxyhaemoglobin.

---
### 53. Question 53
A 60 year old man has 2 days of a swollen, painful right leg. He has hypertension and takes ramipril. He is otherwise well. He has a swollen right leg. The remainder of the examination is normal

**Investigations:**
Haemoglobin 140 g/L (130–175) White cell count 8.0 × 109/L (3.8–10.0) Platelets 340 × 109/L (150–400) Creatinine 94 µmol/L (60–120) Calcium 2.5 mmol/L (2.2–2.6) ALT 30 IU/L (10–50) ALP 99 IU/L (25–115) APTT 30 seconds (22–41) PT 12 seconds (10–12) Urinalysis: normal Chest X-ray: normal Venous duplex ultrasound scan: thrombus in superficial femoral vein

What is the most appropriate additional investigation?

A. No further investigation
B. Carcinoembryonic antigen
C. Prostate specific antigen
D. Protein electrophoresis
E. Ultrasound scan of abdomen

**Answer**: A

**Explanation**: NICE guidance has now changed such that further investigations beyond those included in the stem are only indicated on basis of symptoms. So correct answer is “No further investigation”. NICE guideline [NG158] Published: 26 March 2020 Last updated: 02 August 2023 https://www.nice.org.uk/guidance/ng158/chapter/recommendations

---
### 54. Question 54
A 65 year old woman underwent mechanical aortic valve replacement and coronary revascularisation 3 days ago. She takes aspirin long term. She is being treated with dalteparin sodium

What is the most appropriate long-term management?

A. Apixaban
B. Clopidogrel
C. Continue dalteparin
D. Rivaroxaban
E. Warfarin

**Answer**: E

**Explanation**: All patients with mechanical valves require treatment with aspirin and warfarin. Low molecular weight heparin is used as bridging anti- coagulation but not long-term. There is no place for novel oral anticoagulants (yet).

---
### 55. Question 55
In order to assess the association between maternal smoking during pregnancy and low birthweight, smoking histories can be obtained from pregnant women at the first prenatal visit and data analysed by measuring birthweight at delivery

What is the best description of this type of study?

A. Case-control
B. Cross-sectional
C. Prospective cohort
D. Randomised clinical trial
E. Retrospective cohort

**Answer**: C

**Explanation**: A prospective cohort study is a type of longitudinal study that follows a group of individuals (a cohort) over time to observe the development of specific health outcomes (low birth weight in this case). Exposure to specific risk factors (e.g. smoking status) can be identified at the beginning of the study and then tracked to see how this relates to the later development of the outcome of interest.

---
### 56. Question 56
An 18 year old woman has had a chronic skin condition for several years. She describes having well-defined areas of scale formation at the sites of minor skin injuries, such as scratches or insect bites, typically when the injuries are healing. The scaling can persist for several weeks or months

What is the most likely underlying skin condition?

A. Acne vulgaris
B. Eczema
C. Psoriasis
D. Seborrhoeic dermatitis
E. Vitiligo

**Answer**: C

**Explanation**: This is typical of Koebnerisation. Psoriasis is by far the commonest underlying cause, though it can also occur in vitiligo.

---
### 57. Question 57
A 64 year old man has vomiting and severe chest pain after eating a large meal. His temperature is 37.6°C, pulse 130 bpm, BP 95/50 mmHg and respiratory rate 30 breaths per minute. There is palpable subcutaneous emphysema on the left side of his neck

What is the most likely diagnosis?

A. Diaphragmatic rupture
B. Mallory–Weiss tear
C. Necrotising fasciitis
D. Oesophageal rupture
E. Spontaneous pneumohaemothorax

**Answer**: D

**Explanation**: The scenario describes Boerhaave syndrome (oesophageal rupture).

---
### 58. Question 58
A 54 year old woman has polyuria and the feeling that she needs to drink continuously. She drinks at least 1 litre of water before bedtime and gets up three to four times during the night to pass urine. She has another glass of water each time that she gets up

**Investigations:**
Sodium 140 mmol/L (135–146) Potassium 4.1 mmol/L (3.5–5.3) Urea 4.5 mmol/L (2.5–7.8) Creatinine 86 µmol/L (60–120) Calcium (adjusted) 2.56 mmol/L (2.2–2.6) Fasting glucose 4.8 mmol/L (3.0–6.0) Serum osmolality 295 mOsmol/kg (275–295) Urinary osmolality 86 mOsmol/kg (350–1000) After 8 hours of a water deprivation test, serum osmolality is 308 mOsmol/kg and urinary osmolality is 152 mOsmol/kg. Following the administration of desmopressin, serum osmolality is 286 mOsmol/kg and urinary osmolality is 660 mOsmol/kg.

What is the most appropriate next investigation?

A. CT scan of thorax, abdomen and pelvis
B. MR scan of pituitary
C. Oral glucose tolerance test
D. Technetium-99 Sestamibi parathyroid scan
E. Supervised fluid restriction and daily weights

**Answer**: B

**Explanation**: The test results are consistent with cranial diabetes insipidus (now called AVP deficiency).

---
### 59. Question 59
A 30 year old woman has irregular periods, decreased libido and galactorrhoea. Visual field examination is normal

**Investigations:**
Prolactin 5000 mU/L (100–500) Pregnancy test: negative MR scan of pituitary shows a 4 mm mass in the sella turcica.

What is the most appropriate management?

A. Cabergoline
B. Dexamethasone
C. Octreotide
D. Radiotherapy
E. Transsphenoidal surgery

**Answer**: A

**Explanation**: Cabergoline (a dopamine agonist) is the first-line treatment for a micro- and macroprolatinomas.

---
### 60. Question 60
A 23 year old man is diagnosed with appendicitis. He is being prepared for theatre on the acute surgical ward. He has been vomiting intermittently all day, despite not having eaten for 24 hours. The anaesthetist advises using an airway device to protect the lungs from regurgitated stomach contents

Which airway device is most appropriate?

A. Guedel (oral) airway
B. i-gel® (supraglottic) airway
C. Laryngeal mask airway
D. Nasopharyngeal airway
E. Tracheal tube

**Answer**: E

**Explanation**: i-gels® are often used in cardiac arrest situations as they are easier to place than tracheal tubes. However, only the tracheal tube can seal the trachea off and protect against aspiration.

---
### 61. Question 61
A 32 year old man is referred to a gastroenterology clinic with hepatomegaly. He has type 2 diabetes that is diet controlled. He takes no regular medication. He does not smoke. He drinks 16 units of alcohol per week. Cardiovascular and respiratory examinations are normal. His abdomen is soft, with a 3 cm palpable liver edge. His BMI is 23 kg/m2(18–25)

**Investigations:**
Albumin 38 g/L (35–50) ALT 90 IU/L (10–50) ALP 112 IU/L (25–115) Bilirubin 15 µmol/L (<21) Ferritin 710 µg/L (23–540) CRP 6 mg/L (<5)

What is the most appropriate next investigation?

A. Hepatitis C serology
B. Liver biopsy
C. Reticulocyte count
D. Serum γGT
E. Transferrin saturation

**Answer**: E

**Explanation**: Transferrin saturation is the screening test for haemochromatosis.

---
### 62. Question 62
A 30 year old woman has severe headache 24 hours after a spinal anaesthetic. Her temperature is 37.1°C, pulse 90 bpm and BP 120/80 mmHg

What is the most likely diagnosis?

A. Low pressure headache
B. Meningitis
C. Migraine
D. Subarachnoid haemorrhage
E. Subdural haemorrhage

**Answer**: A

**Explanation**: Most likely cause in this setting - common phenomenon.

---
### 63. Question 63
A 27 year old man develops a dry cough and left-sided chest pain of sudden onset. The pain is worse on taking a deep breath and coughing. His temperature is 36.8°C, pulse 126 bpm, BP 108/60 mmHg, respiratory rate 28 breaths per minute and oxygen saturation 94% breathing air

**Investigations:**
ECG: sinus tachycardia

What is the most appropriate next investigation?

A. Chest X-ray
B. CTPA
C. D dimer
D. Echocardiography
E. V/Q scan

**Answer**: A

**Explanation**: CXR to rule out other pathology before Well score and then CTPA (or V/Q) if PE likely or D-dimer if PE unlikely. (NICE CG144) Diagnostic investigations for pulmonary embolism 1.1.7 If a patient presents with signs or symptoms of pulmonary embolism (PE), carry out an assessment of their general medical history, a physical examination and a chest X ray to exclude other causes. [2012]

---
### 64. Question 64
A 23 year old man is scheduled to undergo an elective arthroscopy of his knee. He is to have a general anaesthetic for the operation. The pre-operative assessment nurse advises him how long he needs to fast beforehand

What fasting times for clear liquids and solids are most likely advised?

A. 2 hours for both clear liquids and solids
B. 2 hours for clear liquids, 6 hours for solids
C. 2 hours for clear liquids, 12 hours for solids
D. 6 hours for both clear liquids and solids
E. 6 hours for clear liquids, 12 hours for solids

**Answer**: B

**Explanation**: Standard international consensus for elective patients with no problems affecting gastric emptying is 2 h for clear liquids, 6 h for solids. Too long a period of fasting is unnecessary whilst residual solid food in the stomach poses a big risk of aspiration/asphyxiation.

---
### 65. Question 65
A 28 year old woman has a lump that she noticed incidentally when rubbing her neck. There is a smooth, non-tender 1.5 cm mobile lump within the thyroid gland

**Investigations:**
TSH 2.3 mU/L (0.3–4.2) Free T4 17 pmol/L (9–25)

What is the most appropriate next investigation?

A. CT scan of neck
B. No further investigation needed
C. Thyroid antibodies
D. Thyroid scintigraphy
E. US scan of neck

**Answer**: E

**Explanation**: This is a non-functional thyroid nodule so needs ultrasound to classify - FNA may then be indicated.

---
### 66. Question 66
A 78 year old man has type 2 diabetes. His clinician does not invite him to join an internet-based self-monitoring programme because they consider him to be too old to engage with it effectively

What is the most appropriate description of the clinician's approach?

A. Bias
B. Discrimination
C. Inequity
D. Prejudice
E. Stereotyping

**Answer**: B

**Explanation**: Discrimination is the unjust or prejudicial treatment of different categories of people.

---
### 67. Question 67
A 47 year old man with well controlled hypertension for many years attends for annual review. He takes ramipril (10 mg once daily). His BP is 138/78 mmHg

**Investigations:**
Sodium 139 mmol/L (135–146) Potassium 6.2 mmol/L (3.5–5.3) Urea 5.0 mmol/L (2.5–7.8) Creatinine 90 µmol/L (60–120)

Which is the most appropriate immediate action?

A. Add indapamide
B. Advise low potassium diet
C. Change ramipril to amlodipine
D. Reduce dose of ramipril
E. Repeat urea and electrolytes

**Answer**: E

**Explanation**: This is likely spurious - and needs repeat.

---
### 68. Question 68
A 33 year old woman has 4 months of joint pain and stiffness, predominantly affecting her feet. This is worst in the morning and gradually improves through the day. She feels tired all the time but reports no other health problems

What investigation would confirm the most likely diagnosis?

A. Anti-cyclic citrullinated peptide antibodies
B. Anti-double-stranded DNA antibodies
C. Antinuclear antibody
D. CRP
E. Rheumatoid factor

**Answer**: A

**Explanation**: The correct answer is A (Anti CCP) antibody. This is the test that has the highest specificity for rheumatoid arthritis, which is what the question is asking. CCP antibodies are found in 80% of people with rheumatoid arthritis, but fewer than 0.5% of healthy individuals. Rheumatoid factor is present in up to 10% of the healthy population, and whilst of similar sensitivity to CCP, is much less specific. CRP is a non-specific marker of inflammation, and can often be normal in early rheumatoid. ANA testing is high sensitivity (but low specificity) test for connective tissue disorders such as SLE and Sjorgren .

---
### 69. Question 69
A 27 year old man has severe central chest pain. He admits to using cocaine shortly before the onset of the chest pain, but says that he had used it on only two previous occasions. He is distressed and sweating. His pulse is 115 bpm and BP 118/68 mmHg. An ECG shows sinus tachycardia with ST elevation in the lateral leads, and several ventricular ectopics

What is the most likely mechanism by which cocaine has caused this acute episode?

A. Blockade of myocyte repolarisation
B. Coronary artery spasm
C. Enhanced platelet aggregation
D. Increased systemic vascular resistance
E. Rupture of pre-existing arterial plaques

**Answer**: B

**Explanation**: Cocaine-induced ACS.

---
### 70. Question 70
An 18 year old man, who was born in the UK, develops drowsiness and confusion 2 days after returning from visiting his grandparents in Malawi. Over the past week he has had recurrent episodes of high fever

**Investigations:**
Haemoglobin 92 g/L (130–175) White cell count 3.2 × 109/L (4.0-11.0) Platelets 184 × 109/L (150–400) Blood film parasites visible

Which is the most likely causative organism?

A. Plasmodium falciparum
B. Plasmodium malariae
C. Plasmodium vivax
D. Trypanosoma brucei
E. Trypanosoma cruzi

**Answer**: A

**Explanation**: Malaria is the most likely diagnosis. Cerebral involvement makes falciparum more likely. T cruzi is seen in S America. T brucei could cause these symptoms but is much rarer.

---
### 71. Question 71
A 31 year old man has a painless lump in his scrotum. There is a well-defined, non-tender spherical 1 cm mass on the right side of the scrotum. It is superior to the testis and transilluminates

What is the most likely diagnosis?

A. Abscess
B. Epididymal cyst
C. Hydrocoele
D. Inguinal hernia
E. Testicular tumour

**Answer**: B

**Explanation**: Separate and can get above mass which is cystic is an epididymal cyst (spermatocele) which is benign and usually asymptomatic and managed conservatively. Although a hydrocele trans illuminates it would surround the testis.

---
### 72. Question 72
A 68 year old man has 3 days of worsening vomiting and abdominal pain. He has not passed any stool for 3 days. Six months ago he underwent a right hemicolectomy for Dukes' A (T1, N0) bowel cancer. He is dehydrated and his abdomen is distended

What is the most likely diagnosis?

A. Adhesional small bowel obstruction
B. Anastomotic leak
C. Cholecystitis
D. Pancreatitis
E. Tumour recurrence

**Answer**: A

**Explanation**: Adhesional bowel obstruction is most likely as he has had a hemicolectomy. Recurrence is less likely because this is Dukes A (early stage). Too late after surgery for anastamotic leak. Pancreatitis and cholecystitis are less likely because they don't cause constipation.

---
### 73. Question 73
A 78 year old man is admitted with chronic oropharyngeal dysphagia. He has left ventricular systolic dysfunction (HFrEF). He is breathless on exertion, particularly when climbing stairs. He weighs 70 kg. His pulse is 72 bpm and BP 132/80 mmHg. He is being prepared for a percutaneous endoscopic gastrostomy feeding tube. The passage of a nasogastric tube has been unsuccessful, and he is having nil by mouth

Which is the most appropriate volume of maintenance fluids (in mL) to prescribe for the next 24 hours?

A. 1750
B. 2450
C. 2800
D. 3000
E. 3250

**Answer**: A

**Explanation**: Maintenance fluid requirements for someone with underlying cardiac disease is recommended as 20-25 mL/kg. This gives an upper volume of 25 x 70= 1750. This conforms to current NICE guideline CG 174 (2013).

---
### 74. Question 74
A 75 year old woman is reviewed 4 days after a fractured neck of femur repair. She has been agitated and upset, particularly at night. She has punched nurses and keeps trying to leave the ward. She has seen strange men in black capes entering the ward and believes that they are controlling the hospital. When she was seen in the memory clinic 6 months ago, she was found to have mild cognitive impairment

What is the most appropriate treatment?

A. Chlordiazepoxide
B. Chlorpromazine
C. Donepezil
D. Haloperidol
E. Memantine

**Answer**: D

**Explanation**: This woman has delirium. Therefore, low dose haloperidol would be the best option, according to NICE guidelines.

---
### 75. Question 75
A 72 year old woman has 6 months of increasing pain at the base of her right thumb. She is having difficulty opening jars and sewing. She is otherwise well. No other joints are painful. She is taking regular analgesia. The first carpometacarpal joint is swollen and tender, with reduced opposition of the thumb

What is the most likely diagnosis?

A. De Quervain tenosynovitis
B. Gout
C. Osteoarthritis
D. Rheumatoid arthritis
E. Septic arthritis

**Answer**: C

**Explanation**: This is a classic description of osteoarthritis and a common site. Gout and septic arthritis would have a much more acute history. Rheumatoid arthritis would usually affect multiple joints. The pain of de Quervain tenosynovitis would be felt over the radial aspect of the wrist.

---
### 76. Question 76
A 62 year old man has acute breathlessness with a weak cough, following a recent viral upper respiratory infection. Over the past 4 months, he has had double vision, limb weakness and slurred speech when tired. His respiratory rate is 18 breaths per minute and oxygen saturation 96% breathing air. He is sweating and using his accessory muscles of inspiration

What is the most appropriate test to monitor his respiratory function?

A. Arterial blood gas
B. FEV1
C. FVC
D. Peak expiratory flow rate
E. Ratio of FEV1 to FVC

**Answer**: C

**Explanation**: Myasthenic crisis is an acute respiratory failure characterised by forced vital capacity (FVC) below 1 L, negative inspiratory force (NIF) of 20 cm H2O or less, and the need for ventilatory support. The use of accessory muscles indicates significant inspiratory weakness. Weak cough indicates weakness of expiratory muscles. Arterial blood gas analysis commonly shows hypercapnia before hypoxia. There should be a low threshold for endotracheal intubation due to rapid deterioration of bulbar and respiratory muscles.

---
### 77. Question 77
A 40 year old man has 4 days of left flank pain associated with fever, nausea and vomiting. His temperature is 39.6°C, pulse 118 bpm and BP 90/40 mmHg. Imaging shows an obstructing proximal left ureteric stone with severe hydronephrosis. He is treated with intravenous antibiotics and intravenous fluids

What is the most appropriate next step in management?

A. Lithotripsy
B. Nephrostomy
C. Retrograde pyelography
D. Ureteric stent
E. Urethral catheter

**Answer**: B

**Explanation**: The renal pelvis should be decompressed with a nephrostomy.

---
### 78. Question 78
A 19 year old man has had right-sided chest pain and breathlessness on exertion for 2 days. He smokes cannabis and takes cocaine. His temperature is 36.4°C, pulse 108 bpm, BP 112/80 mmHg, respiratory rate 24 breaths per minute and oxygen saturation 94% breathing air. His trachea is central. He has reduced breath sounds at the right apex

[IMAGE: image_078_MLA2_page30_image_30_2.png]

What is the most likely diagnosis?

A. Acute coronary syndrome
B. Coronary artery spasm
C. Pneumonia
D. Pneumothorax
E. Pulmonary embolism

**Answer**: D

**Explanation**: Pneumothoraces are more commonly encountered in young, tall men who smoke. There is no medical history provided confirming the presence of existing lung disease - this excludes secondary pneumothorax as a diagnosis.

---
### 79. Question 79
An 80 year old woman attends the emergency department after being found collapsed at home. She has central chest pain. Her pulse is 30 bpm, BP 70/40 mmHg and respiratory rate 26 breaths per minute. Her 12-lead ECG shows sinus bradycardia with no evidence of myocardial ischaemia

What is the most appropriate initial treatment?

A. Adrenaline/epinephrine
B. Atropine
C. Dobutamine
D. Normal saline
E. Permanent cardiac pacemaker

**Answer**: B

**Explanation**: Atropine is the first line initial treatment for sinus bradycardia.

---
### 80. Question 80
A 62 year old man develops acute pain, redness, swelling and warmth of his right first metatarsophalangeal joint. He has gout and hypertension. His medications are allopurinol, amlodipine and ramipril. His eGFR is >60 mL/min/1.73 m2(>60)

What is the most appropriate next step in his management?

A. Change allopurinol to febuxostat
B. Start naproxen
C. Stop allopurinol
D. Stop amlodipine
E. Stop ramipril

**Answer**: B

**Explanation**: The patient has acute gout. The immediate management would be to commence an NSAID.

---
### 81. Question 81
A 10 year old boy has deafness of new onset. He has had a recent respiratory tract infection. When the tuning fork is placed in the middle of his forehead he hears the tone loudest in his right ear. When the tuning fork is placed on the bone behind the right ear the sound is louder than when it is held in front of his right external auditory meatus. When the tuning fork is held in front of the left external auditory meatus the sound is louder than when it is placed on the bone behind the same ear

What type of hearing loss is this?

A. Bilateral mixed deafness
B. Left conductive deafness
C. Left sensorineural deafness
D. Right conductive deafness
E. Right sensorineural deafness

**Answer**: D

**Explanation**: The combination of lateralisation of Weber test to the right and a negative Rinne test on the right (i.e. bone conduction louder than air conduction) occurs with right conductive deafness. This also fits with the clinical history of a recent respiratory tract infection.

---
### 82. Question 82
A 55 year old man has had painful red swelling of his left lower leg for 2 days. He has type 2 diabetes mellitus and takes metformin. His temperature is 37.6°C. He has a tender erythematous area extending from the ankle to the proximal calf

What is the most likely causative organism?

A. Bacteroides species
B. Proteus mirabilis
C. Pseudomonas aeruginosa
D. Staphylococcus epidermidis
E. Streptococcus pyogenes

**Answer**: E

**Explanation**: Streptococcus is the most common pathogen in leg cellulitis (including in patients with diabetes).

---
### 83. Question 83
A 64 year old woman is due to undergo an arthroscopy of her knee. She has type 2 diabetes and takes metformin (500 mg twice daily) and gliclazide (80 mg each morning). Her glycated haemoglobin (HbA1c) is 54 mmol/mol (20–42). She is scheduled first on tomorrow morning's day case list and is asked to fast from midnight tonight

What is the most appropriate plan for managing her diabetic medication?

A. Continue both drugs and start a variable-rate insulin infusion
B. No change to usual medication
C. Omit both drugs and start a variable-rate insulin infusion
D. Omit gliclazide and continue metformin
E. Omit metformin and continue gliclazide

**Answer**: D

**Explanation**: Principles are to minimise fasting times (hence first on list) and disruption to usual medication. In this setting where the procedure is fairly minor, patient should be eating again at lunchtime and hence there is no call for insulin in any form. https://www.diabetes.org.uk/node/1730

---
### 84. Question 84
A 67 year old man has difficulty walking. He states that he has to raise his left leg higher in the air than normal to avoid scraping his toes on the ground when he walks. When he raises the left foot from the floor, the ankle assumes a plantar-flexed position with the toes directed towards the floor

Which nerve is most likely to be affected?

A. Common peroneal
B. Medial plantar
C. Saphenous
D. Superficial peroneal
E. Tibial

**Answer**: A

**Explanation**: The patient has foot drop due to loss of active dorsiflexion. The muscles affected are supplied by the common peroneal nerve.

---
### 85. Question 85
A 35 year old woman has 6 months of cyclical pain in both breasts. She has recently noticed a lump in the right breast. There is diffuse nodularity of the axillary tails of both breasts with a discrete 20 mm mass in the upper outer quadrant of the right breast. Fine needle aspiration is performed and 5 mL of brown fluid is removed, with disappearance of the mass. Cytology shows cellular debris with no malignant cells

What is the most likely diagnosis?

A. Breast abscess
B. Breast carcinoma
C. Fat necrosis
D. Fibroadenoma
E. Fibrocystic disease

**Answer**: E

**Explanation**: Fibrocystic disease characteristically causes pain associated with the menstrual cycle. The fine needle aspiration supports this with no malignant cells seen. A fibroadenoma is a solid lump. Pain if present would be localised with fat necrosis. Breast abscess would be a more acute history and again would not be expected to cause bilateral breast pain.

---
### 86. Question 86
A 70 year old man has a brief episode of twitching that starts in his left hand and spreads up the arm over 2 minutes, then stops. His arm feels weak for an hour afterwards. He had an ischaemic stroke affecting his left side 6 months ago with good functional recovery. He has type 2 diabetes mellitus and is taking clopidogrel, metformin, ramipril and atorvastatin. He is anxious about a further stroke. There is no weakness on neurological examination

What is the most likely diagnosis?

A. Dissociative (non-epileptic) seizure
B. Focal seizure
C. Hypoglycaemic episode
D. Migraine
E. Transient ischaemic attack

**Answer**: B

**Explanation**: The description fits with partial seizure affecting his right hemisphere as a result of a previous stroke.

---
### 87. Question 87
A 63 year old woman has 4 months of abdominal bloating, fatigue and nausea. She is found to have ovarian cancer. Staging CT is performed to look for lymphatic spread and metastatic disease

Where is her tumour most likely to spread initially?

A. Deep inguinal nodes
B. External iliac nodes
C. Internal iliac nodes
D. Para-aortic nodes
E. Superficial inguinal nodes

**Answer**: D

**Explanation**: The main lymphatic drainage of the ovary is to the para-aortic nodes. The iliac nodes are less frequently involved.

---
### 88. Question 88
A 52 year old woman has had three episodes of severe epigastric pain associated with vomiting over the past 3 months. The episodes occurred following eating and lasted for about 1 hour. She has type 2 diabetes mellitus and takes metformin. Abdominal examination is normal. Her BMI is 35 kg/m2(18–25)

**Investigations:**
ALT 15 IU/L (10–50) ALP 71 IU/L (25–115) Bilirubin 9 µmol/L (<21) Ultrasound scan of abdomen: single 2 cm gallstone in gallbladder, common bile duct normal, evidence of fatty liver.

What is the most appropriate management?

A. Endoscopic retrograde cholangiopancreatography
B. Laparoscopic cholecystectomy
C. MR cholangiopancreatography
D. Open cholecystectomy
E. Ursodeoxycholic acid

**Answer**: B

**Explanation**: The patient has symptomatic gallstone disease and laparoscopic cholecystectomy is indicated. Percutaneous cholecystostomy may be used in patients who are not fit for surgery. Urosdeoxycholic acid may be used for gallstone dissolution, but is not part of common UK practice.

---
### 89. Question 89
A 56 year old woman develops vertigo, nausea, vomiting and intense occipital headache of sudden onset. She is unable to walk without falling. She has hypertension and takes ramipril. Her temperature is 37.4°C, pulse 94 bpm, BP 146/92 mmHg, respiratory rate 12 breaths per minute and oxygen saturation 96% breathing air. She has multidirectional nystagmus and some clumsiness of her right arm

What is the most likely diagnosis?

A. Acute labyrinthitis
B. Benign paroxysmal positional vertigo
C. Cerebellar stroke
D. Ménière disease
E. Multiple sclerosis

**Answer**: C

**Explanation**: Triad of headache, nausea/vomiting and ataxia. Profound imbalance, sudden onset and prominent headache suggest cerebellar stroke, quite possibly secondary to arterial dissection.

---
### 90. Question 90
A 79 year old woman has 3 months of a left leg venous ulcer that is slowly healing. Ankle–brachial pressure indices are 0.9 on the left side and 1.1 on the right side (0.8–1.2)

What is the most appropriate management?

A. Compression stockings
B. Diagnostic biopsy
C. Full-length graduated compression bandaging
D. No further management required
E. Repeat ankle–brachial pressure indices in 3 months

**Answer**: A

**Explanation**: Despite gradual improvement this venous ulcer would be best managed with stockings, which would also help prevent further lesions.

---
### 91. Question 91
A 26 year old woman sustains a head injury in a motorcycle accident. Her eyes are closed, but she opens them when asked. She is confused about what happened and where she is, but attempts to talk about it. She repeatedly attempts to remove the cannula from her wrist

What is her Glasgow Coma Score?

A. E1, V1, M1, total = 3
B. E2, V2, M3, total = 7
C. E3, V3, M3, total = 9
D. E3, V4, M5, total = 12
E. E4, V5, M5, total = 14

**Answer**: D

**Explanation**: Opens eyes in response to voice = 3 Confused, disoriented = 4 Localizes painful stimuli = 5

---
### 92. Question 92
A 65 year old man has sudden pain and redness in his right eye. He also has a headache and nausea. Visual acuity isﾠ6/60 in the right eye. The eye is congested, with a hazy cornea and mid-dilated pupil

What is the most likely diagnosis?

A. Acute glaucoma
B. Conjunctivitis
C. Corneal ulcer
D. Scleritis
E. Uveitis

**Answer**: A

**Explanation**: All the symptoms and signs described can occur with acute glaucoma. Uveitis whilst causing red eye, headache and visual disturbance is associated with a small pupil. Scleritis, corneal ulcer and conjunctivitis are not generally associated with headache and nausea or a significant drop in visual acuity.

---
### 93. Question 93
A 68 year old man collapses when rising from a chair and is seen in the emergency department 45 minutes later. He has COPD and hypertension. He smokes 10 cigarettes per day. He is conscious but has reduced strength in his left arm (3/5) and leg (4/5) and slurring of speech. He has bilateral scattered wheeze and bilateral carotid bruits on auscultation

Which is the most appropriate initial radiological investigation?

A. Cerebral angiography
B. CT cerebral venogram
C. CT scan of head
D. MR scan of brain
E. Ultrasound scan of carotid arteries

**Answer**: C

**Explanation**: This is a probable CVA (presentation and risk factors). Due to rapid presentation he is a candidate for systemic thrombolysis. Non-contrast CT head is the most rapid investigation to exclude intracranial haemorrhage and allow thrombolysis.

---
### 94. Question 94
A 25 year old man sustains 40% full-thickness burns in a house fire. Despite intensive treatment, he becomes breathless and hypotensive. He develops a petechial rash. His temperature is 38°C, pulse 110 bpm, BP 80/50 mmHg and oxygen saturation 96% breathing 40% oxygen

**Investigations:**
Haemoglobin 110 g/L (130–175) White cell count 4.2 × 109/L (4.0-11.0) Platelets 15 × 109/L (150–400) APTT 75 seconds (22–41) PT 25 seconds (10–12) Fibrinogen 0.7 g/dL (1.5–4.0) Fibrinogen degradation products 137 mg/mL (<8)

What is the most likely diagnosis?

A. Anaphylactic reaction to antibiotics
B. Disseminated intravascular coagulation
C. Fat embolism
D. Immune thrombocytopenic purpura
E. Pulmonary embolism

**Answer**: B

**Explanation**: The history, signs and investigations are all most indicative of DIC.

---
### 95. Question 95
A 65 year old woman with newly diagnosed advanced lung cancer has 1 day of breathlessness and 1 week of progressive headache. Her pulse is 88 bpm, respiratory rate 20 breaths per minute and oxygen saturation 95% breathing 4 L/min oxygen via nasal prongs. She has a swollen face and neck with distended veins on her chest. Her chest is clear. CT scan of chest shows mediastinal lymphadenopathy compressing the superior vena cava

What is the most appropriate initial treatment?

A. Alteplase
B. Dexamethasone
C. Heparin infusion
D. Insert endovascular stent
E. Mannitol

**Answer**: B

**Explanation**: The patient has superior vena cava obstruction. The standard initial treatment is dexamethasone to reduce tumour swelling. There is no evidence of thrombus to justify systemic anticoagulation and systemic thrombolysis has no place. Intravenous mannitol is not used. It is worth noting that although dexamethasone is commonly recommended there is limited controlled data confirming its effectiveness. Insertion of endovenous stent would be considered if there was stridor, but would likely follow intubation and steroids. The following guideline is of use: http://www.palliativecareguidelines.scot.nhs.uk/guidelines/palliative- emergencies/Superior-Vena-Cava-Obstruction.aspx

---
### 96. Question 96
A 65 year old man has 3 weeks of progressive ankle oedema. He has a lifelong history of heavy smoking and drinks 12 units of alcohol per week. His BP is 125/85 mmHg and oxygen saturation 98% breathing air. He has marked bilateral pitting ankle oedema. 

**Investigations:** Creatinine 85 µmol/L (60–120) Urinary protein: creatinine ratio 400 mg/mmol (<30) Fasting glucose 5.7 mmol/L (3.0–6.0) Total cholesterol 9 mmol/L (<5.0) Albumin 20 g/L (35–50) He is treated with furosemide

What investigation is most likely to identify the cause?

A. Chest X-ray
B. Renal arteriography
C. Renal auto-antibody screen
D. Renal biopsy
E. Serum protein electrophoresis

**Answer**: D

**Explanation**: Nephrotic syndrome in adults requires renal biopsy to identify the cause, prior to definitive treatment.

---
### 97. Question 97
A 55 year old woman has a tender, erythematous, swollen hard cord in the long saphenous vein distribution in her calf. The pain persists despite paracetamol. She has longstanding bilateral varicose veins. An ultrasound scan shows superficial thrombophlebitis without deep vein thrombosis

What is the most appropriate treatment?

A. Dipyridamole
B. Flucloxacillin
C. Gabapentin
D. Naproxen
E. Rivaroxaban

**Answer**: D

**Explanation**: An NSAID (such as naproxen in the answers) or paracetamol, or both, would be the most appropriate first-line management for superficial vein thrombosis. Scenario: Management of superficial vein thrombosis Last revised in July 2024 https://cks.nice.org.uk/topics/superficial-vein-thrombosis-superficial- thrombophlebitis/management/management-of-superficial-vein-thrombosis/

---

### 98. Question 98
An 88 year old woman has recurrent falls. She says that she cannot feel where her feet are. There is reduced pinprick sensation up to the level of her mid calf and joint position sense is impaired in the feet. Knee reflexes are brisk, but ankle reflexes are absent

**Investigations:**
Haemoglobin 91 g/L (115–150) White cell count 3.5 × 109/L (3.8–10.0) Platelets 130 × 109/L (150–400) MCV 116 fL (80–96)

What is the most likely deficiency?

A. Folate
B. Iron
C. Pyridoxine
D. Thiamine
E. Vitamin B12

**Answer**: E

**Explanation**: This is a typical presentation of B12 deficiency. The most common neurologic findings are symmetric paraesthesias or numbness and gait problems. This is much less common with folate deficiency.

---
### 99. Question 99
A 55 year old man has had lower back pain and fatigue for 3 months

**Investigations:**
Haemoglobin 110 g/L (130–175) White cell count 5.8 × 109/L (3.8–10.0) Platelets 120 × 109/L (150–400) Corrected calcium 2.90 mmol/L (2.2–2.6) Albumin 29 g/L (35–50) Serum electrophoresis: monoclonal Ig kappa peak Bone marrow biopsy: foci of plasma cells, which account for 18% of all haematopoietic cells

What is the most likely diagnosis?

A. Acute lymphoblastic lymphoma
B. Chronic lymphocytic leukaemia
C. Extramedullary plasmacytoma
D. Multiple myeloma
E. Waldenström macroglobulinaemia

**Answer**: D

**Explanation**: The patient has classical clinical and laboratory features of multiple myeloma.

---
### 100. Question 100
A 54 year old woman has reduced urine output 24 hours after admission with right lower lobe consolidation due to community acquired pneumonia. She has been treated with intravenous amoxicillin and clarithromycin, but remains breathless. Her creatinine was 82 μmol/L (60–120) on admission. Her temperature is 38.0°C, pulse rate 106 bpm, BP 102/50 mmHg and oxygen saturation 95% breathing 4 L/min oxygen via nasal prongs. Her urine output is 250 mL over the past 12 hours. Her urinalysis has protein 1+

**Investigations:**
Haemoglobin 119 g/L (115–150) White cell count 16.9 × 109/L (3.8–10.0) Platelets 95 × 109/L (150–400) Urea 15.5 mmol/L (2.5–7.8) Creatinine 160 μmol/L (60–120)

What is the most likely cause of her acute kidney injury?

A. Drug-induced interstitial nephritis
B. Haemolytic uraemic syndrome
C. Infection-related glomerulonephritis
D. Renal hypoperfusion
E. Systemic vasculitis

**Answer**: D

**Explanation**: The patient has ongoing sepsis with hypotension which is leading to pre-renal AKI. This clinical pattern may ultimately lead to acute tubular necrosis/tubular injury. None of the other diagnoses fit the clinical picture. Interstitial nephritis would normally not appear until 4-7 days of antibiotic exposure and is relatively rare. Infection related glomerulonephritis is uncommon with pneumonia and there is no evidence of non-visible haematuria. The same applies to systemic vasculitis. Haemolytic uraemic syndrome would have a different clinical picture with marked anaemia and a lower platelet count.

---
### 101. Question 101
A 70 year old woman has an ulcer above the left medial malleolus. She has type 2 diabetes mellitus. She smokes 10 cigarettes per day. Her BMI is 34. The ulcer is 10 × 5 cm and superficial. She has brown discolouration of both lower legs. The skin has a thickened, waxy feel

Which ulcer type is the most likely?

A. Arterial
B. Inflammatory
C. Malignant
D. Neuropathic
E. Venous

**Answer**: E

**Explanation**: The site and presence of hyperpigmentation or lipodermatosclerosis are suggestive of venous ulceration. The classic location for these is by medial or lateral malleolus and they are not associated with significant pain.

---
### 102. Question 102
A 67 year old man has 3 weeks of worsening ankle oedema. He has hypertension and takes amlodipine. He is a lifelong heavy smoker and drinks 12 units of alcohol per week. His BP is 125/85 mmHg and oxygen saturation 98% breathing air. His JVP is 4 cm above the sternal angle. He has marked bilateral pitting ankle oedema. He has dull percussion note at both bases with reduced breath sounds

**Investigations:**
Creatinine 85 µmol/L (60–120) Fasting glucose 5.7 mmol/L (3.0–6.0) Total cholesterol 9 mmol/L (<5.0) Albumin 15 g/L (35–50) Urinary protein:creatinine ratio 568 mg/mmol (<30) Urine microscopy no cells, no casts

What is the most likely diagnosis?

A. Cardiac failure
B. Nephritic syndrome
C. Nephrotic syndrome
D. Rapidly progressive glomerulonephritis
E. Renovascular disease

**Answer**: C

**Explanation**: The combination of hypoalbuminaemia, proteinuria, oedema, hypercholesterolaemia etc. is characteristic of nephrotic syndrome. The most likely causes in the age group (without diabetes) would be membranous nephropathy, minimal change or FSGS. Myeloma would also need to be considered. A renal biopsy would be required to confirm the diagnosis.

---
### 103. Question 103
A 68 year old man has eight weeks of back pain. It sometimes wakes him at night, and he is feeling increasingly tired. He has no history of back problems or recent trauma. He has tenderness over L3 and L4 vertebrae

**Investigations:**
Haemoglobin 137 g/L (130–175) Erythrocyte sedimentation rate 55 mm/hr (< 20) Creatinine 72 µmol/L (60–120) Calcium 2.5 mmol/L (2.2–2.6) Serum protein electrophoresis: no paraprotein

What is the most appropriate next investigation?

A. CT scan abdomen and pelvis
B. DEXA scan
C. HLA-B27 antigen
D. Isotope bone scan
E. X-ray lumbar spine

**Answer**: E

**Explanation**: Being woken from sleep is a red flag symptom, as is the duration. At this age and with the persistence of symptoms, spinal tenderness and an elevated ESR it is reasonable to perform imaging. Plain X-rays are appropriate initially, although if negative an MR scan would be indicated.

---
### 104. Question 104
A 17 year old girl has a florid skin rash for 24 hours. She has been feeling unwell for the past week with intermittent abdominal pain. She has a palpable, purpuric rash on her lower limbs and buttocks. Her temperature is 37.2°C, pulse rate 70 bpm and BP 122/80 mmHg. Her urinalysis has blood 3+, protein 2+, nitrites negative, leucocytes negative

**Investigations:**
Haemoglobin 122 g/L (115–150) White cell count 8.9 × 109/L (3.8–10.0) Platelets 320 × 109/L (150–400) Urea 3.2 mmol/L (2.5–7.8) Creatinine 60 µmol/L (60–120)

What is the most likely diagnosis?

A. IgA vasculitis (Henoch–Schönlein purpura)
B. Meningococcal septicaemia
C. Microscopic polyangiitis
D. Postinfectious glomerulonephritis
E. Systemic lupus erythematosus

**Answer**: A

**Explanation**: Classic presentation of HSP with a purpuric (vasculitic) rash and an active urinary sediment. Abdominal and joint pain may also occur. Renal function is usually normal. With meningococcal sepsis the patient would be much more unwell. Postinfectious GN would follow a clear-cut infection, particularly streptococcal sore throat. SLE would normally have a longer history, does not typically give a vasculitis rash and would be associated with other features of SLE e.g. alopecia, arthralgia, skin rash, cytopenias, mouth ulcers. Microscopic polyangiitis (ANCA associated normally) is less common in this age group and usually has a longer history.

---
### 105. Question 105
A 67 year old woman becomes unwell whilst attending the diabetes foot clinic. She is anxious and noticeably tremulous as she drinks from her water bottle. She is sweaty but apyrexial. Her pulse rate is 98 bpm, BP 128/76 mmHg and oxygen saturation 96% breathing air. Her capillary blood glucose is 2.1 mmol/L

What is the most appropriate next step in management?

A. Intramuscular glucagon
B. Intravenous 10% glucose
C. Intravenous 20% glucose
D. Oral glucose gel (GlucoGel®)
E. Oral glucose tablets

**Answer**: E

**Explanation**: She is alert enough to swallow so does not need to be given GlucoGel® but the tablets. JBDS guidelines (Revised Jan 2023).

---
### 106. Question 106
An 82 year old woman has constipation and passes infrequent, hard stools. She has hypertension, overactive bladder symptoms and type 2 diabetes mellitus. She takes amlodipine, doxazosin, gliclazide, metformin and oxybutynin

Which medication is most likely to be worsening her constipation?

A. Amlodipine
B. Doxazosin
C. Gliclazide
D. Metformin
E. Oxybutynin

**Answer**: E

**Explanation**: Oxybutynin is an anticholinergic and a frequent cause of constipation.

---
### 107. Question 107
A 65 year old man reports sudden onset of visual disturbance with flashing lights, floaters and loss of vision in the upper outer quadrant of his right eye. He has hypertension but reports no previous visual disturbances

What is the most likely diagnosis?

A. Acute glaucoma
B. Central retinal artery occlusion
C. Central retinal vein occlusion
D. Retinal detachment
E. Vitreous haemorrhage

**Answer**: D

**Explanation**: Patients with retinal detachment typically complain of an increasing number of floaters in one eye. As detachment progresses the separating vitreous will tug on the surface of the retina and create a mechanical depolarization of the axons running through the nerve fibre layer of the retina. This leads to flashing lights.

---
### 108. Question 108
A 70 year old woman develops pyrexia and reduced oxygen saturation 2 days after an elective subtotal gastrectomy. Her postoperative pain control has been difficult, which has limited her ability to have chest physiotherapy and to mobilise. Her temperature is 37.8°C, pulse rate 84 bpm and oxygen saturation 92% breathing 35% oxygen. Her BMI 36. There is reduced breath sounds at both lung bases. Her abdomen is soft, with tenderness around her wound. Her drain has serous output

What is the most likely postoperative complication?

A. Anastomotic leak
B. Atelectasis
C. Pneumothorax
D. Pulmonary embolism
E. Wound infection

**Answer**: B

**Explanation**: The development of a fever in the early postoperative period, in combination with reduced oxygen saturation, is most likely to be due to the development of bibasal atelectasis, especially in a patient who has undergone an abdominal procedure and is experiencing pain.

---
### 109. Question 109
A 69 year old man has 6 months of intermittent weakness and numbness in both legs. The symptoms comes on during walking, typically after about 100 metres, and settle after a few minutes with rest. He has found that leaning forwards whilst walking can prevent the symptoms. He can ride a bike slowly without provoking the symptoms. He has diet-controlled type 2 diabetes mellitus. He used to smoke and has a 40 pack-year history. His BP is 178/95 mmHg. He has weakness of hip flexion bilaterally. His peripheral pulses are palpable

What is the most likely diagnosis?

A. Diabetic amyotrophy
B. Lumbar disc prolapse
C. Lumbar spinal stenosis
D. Osteoarthritis of hips
E. Peripheral arterial disease

**Answer**: C

**Explanation**: This patient gives a typical history of neurogenic claudication coming on with walking and better leaning forwards (including when riding a bike).

---
### 110. Question 110
A 62 year old man attends the emergency department following a road traffic collision. He has severe bruising of the right upper shoulder from the seat belt, but no other injuries. Chest X-ray (performed to exclude a pneumothorax) shows a 2 cm mass in the right upper zone

What is the most appropriate next investigation?

A. CT scan of chest
B. Lateral chest X-ray
C. MR scan of chest
D. PET scan of chest
E. Technetium bone scan

**Answer**: A

**Explanation**: CT would be the most appropriate next investigation of a mass on chest X-ray given the likely diagnosis of lung cancer.

---
### 111. Question 111
A 28 year old woman returns to the dermatology clinic 2 weeks after surgery to excise a 1.1 cm pigmented lesion on her right lower leg. The histopathological report states that the lesion is a superficial spreading melanoma with a Clark level 3, Breslow depth 0.9 mm, mitotic index of 1/mm2 and no ulceration. It has been completely excised

Which feature provides the most important pathological prognostic indicator?

A. Breslow depth
B. Clark level
C. Diameter of lesion
D. Melanoma subtype
E. Mitotic index

**Answer**: A

**Explanation**: A complete full-thickness excisional biopsy of suspicious lesions with 1 to 3 mm margin of normal skin and part of the subcutaneous fat should be performed. Tumour thickness is the single most important prognostic factor for patients with localised melanoma. This is measured as the Breslow depth or thickness.

---
### 112. Question 112
A 42 year old woman has 12 hours of colicky central abdominal pain, vomiting, abdominal distension and increased bowel sounds. She had a ruptured appendix aged 20 years. Plain abdominal X-ray: see image

[IMAGE: image_112_MLA3_page16_image_16_2.png]

What is the most appropriate initial management?

A. Flatus tube insertion
B. Intravenous antibiotics
C. Laparoscopy
D. Laparotomy
E. Nasogastric tube insertion

**Answer**: E

**Explanation**: The patient has small bowel obstruction due to adhesions from her previous appendicitis. This is treated conservatively with fluid resuscitation and nasogastric decompression of the gut. The stomach contents should be aspirated using a syringe, following which the bag should be placed on free drainage. Further aspiration may be needed if required. Conservative management is successful in 65-80% of cases and surgical intervention is only considered for those patients who do not improve with conservative management. Surgically dividing adhesions creates further raw surfaces on which adhesions may form during the healing process and hence is avoided wherever possible. Intravenous antibiotics are not indicated in cases managed conservatively. Upper GI endoscopy has no role in the management of this case.

---
### 113. Question 113
A 59 year old woman has loin pain and dysuria. Her temperature is 39°C, pulse rate 108 bpm, BP 90/60 mmHg and respiratory rate 18 breaths per minute

**Investigations:**
Haemoglobin 130 g/L (115–150) White cell count 22.0 × 109/L (3.8–10.0) Platelets 40 × 109/L (150–400) PT 20 seconds (10–12) APTT 60 seconds (22–41) Fibrinogen 1.0 g/dL (1.5–4.0)

What is the most likely explanation for her thrombocytopenia?

A. Disseminated intravascular coagulation
B. Haemophilia B
C. Immune thrombocytopenic purpura
D. Vitamin B12 deficiency
E. von Willebrand disease

**Answer**: A

**Explanation**: The clotting abnormalities are consistent with acute DIC due to complicated urosepsis. typically patients have thrombocytopenia, prolonged PT and aPTT, low plasma fibrinogen and an elevated plasma D-dimer. There may also be microangiopathic abnormalities on the blood smear.

---
### 114. Question 114
A 22 year old man attends the emergency department having briefly lost consciousness. He had gone to bed after a party and been woken at 03:00 by the need to pass urine. He remembers feeling faint and nauseated while bearing down to pass urine, lost consciousness and fell to the floor. Examination and ECG are normal

What is the most likely diagnosis?

A. Alcohol related seizure
B. Cardiac dysrhythmia
C. Ecstasy toxicity
D. Hypoglycaemia
E. Micturition syncope

**Answer**: E

**Explanation**: This is a classical history for micturition syncope. There is nothing to suggest seizure activity as the episode was only brief with no suggestion of post ictal confusion. The normal ECG means it is very unlikely to have been a cardiac dysrhythmia in a 22 year old. Hypoglycaemia would not spontaneously resolve without treatment. This is not the presentation of ecstasy toxicity.

---
### 115. Question 115
A 45 year old man with pain caused by cancer has been using opioids to control his pain very successfully. He is taking a regular dose of MST Continus® 60 mg 12-hourly orally. He has been using three breakthrough doses (oral morphine 20 mg) per day for the past week

What is the most appropriate opioid prescription?

A. Diamorphine 60 mg subcutaneously over 24 h by syringe driver
B. Morphine 90 mg subcutaneously over 24 h by syringe driver
C. MST Continus® 60 mg 12-hourly and morphine 30 mg as required (up to 4-hourly) orally
D. MST Continus® 90 mg 12-hourly and morphine 20 mg as required (up to 4-hourly) orally
E. MST Continus® 90 mg 12-hourly and morphine 30 mg as required (up to 4-hourly) orally

**Answer**: E

**Explanation**: The breakthrough dose should be one-sixth of the total daily dose. The current daily morphine dose is 180 mg, hence MST continues at 90 mg 12 hourly and the breakthrough at morphine 30 mg.

---
### 116. Question 116
A 25 year old man has left-sided chest pain that is worsened by lying back and when he takes a deep breath. He has had a recent respiratory tract infection

**Investigations:**
Troponin T 5 ng/L (<12) ECG: see image

[IMAGE: image_116_MLA3_page21_image_21_2.png]

What is the most likely diagnosis?

A. Pericardial effusion
B. Pericarditis
C. Pulmonary embolism
D. ST-elevation myocardial infarction
E. Unstable angina

**Answer**: B

**Explanation**: The history and ECG changes (widespread PR depression and ST elevation) are strongly suggestive of pericarditis. A pericardial effusion would produce low-voltage complexes on the ECG.

---
### 117. Question 117
An 18 year old woman has 6 hours of severe dizziness and nausea. She says that the room is constantly spinning round and she has vomited several times. The dizziness is worse when she opens her eyes. She reports that her hearing has not changed. She has nystagmus with the fast phase to the left, which does not fatigue

What is the most likely diagnosis?

A. Benign positional vertigo
B. Cerebellar tumour
C. Ménière disease
D. Vestibular migraine
E. Vestibular neuronitis

**Answer**: E

**Explanation**: The most likely diagnosis is vestibular neuronitis as this is a single episode in an 18-year-old. The diagnoses of vestibular migraine and benign positional vertigo would not be considered unless the attacks were recurrent.

---
### 118. Question 118
A 60 year old man attends his GP as he wants to start training for a 5 km race for charity. He plans to run 3 to 5 km three times per week. He describes occasional central chest tightness when he walks up hills. He has type 2 diabetes mellitus and COPD, and takes metformin and inhaled salbutamol as- required. His BP is 162/94 mmHg. His BMI is 32

Which aspect of his clinical background is a contra-indication to his training plan?

A. BP >160/90 mmHg
B. COPD
C. Exertional chest tightness
D. Obesity
E. Type 2 diabetes mellitus

**Answer**: C

**Explanation**: The presence of exertional chest pain indicates a high likelihood of undiagnosed ischaemic heart disease. Vigorous exercise runs the risk of a significant ischaemic event including a myocardial infarct or arrhythmia.

---
### 119. Question 119
A 75 year old man attends his GP with one episode of visible haematuria. His temperature is 36.2°C and BP 142/80 mmHg. Urinalysis shows blood 2+, leucocytes negative, protein negative, nitrite negative

**Investigations:**
Midstream urine: red blood cells and epithelial cells, no microbial growth

What is the most appropriate next step?

A. Arrange an ultrasound scan of renal tract
B. Arrange CT urography
C. Check serum prostate specific antigen
D. Refer for urology opinion
E. Repeat midstream urine sample for culture and sensitivity

**Answer**: D

**Explanation**: This is because the patient may have transitional cell carcinoma of the bladder and thorough investigation of haematuria is urgent to rule this out.

---
### 120. Question 120
A 73 year old man has 3 months of increasing weakness of his right hand with reduced sensation of the forearm. There is wasting of all the intrinsic muscles of the right hand. There is weakness of finger abduction and adduction, and thumb adduction. Finger flexion is normal. There is mild altered light touch sensation along the ulnar aspect of the forearm. The biceps, supinator and triceps reflexes are normal. The lower limbs and the left arm are normal

Where is the most likely site of the lesion causing his symptoms?

A. Median nerve in the forearm
B. Median nerve in the wrist
C. Spinal cord C8 level
D. T1 nerve root
E. Ulnar nerve at the elbow

**Answer**: D

**Explanation**: The intrinsic hand muscle wasting suggests T1. The normal reflexes and normal other arm are against a cord lesion. The sensory loss on the forearm excludes median and ulnar nerve lesions. T1 dermatome is often thought to be higher in the arm medially.

---
### 121. Question 121
An 84 year old woman was admitted 24 hours ago following a fall in her home. She has mild dementia and osteoarthritis. She takes donepezil and ibuprofen. Her temperature is 36.2°C, pulse rate 77 bpm and BP 152/88 mmHg. Her abbreviated mini-mental test score is 6/10. She has bruising on her face. A midstream urine culture result 24 hours later shows a mixed growth of organisms with no leucocytes

What is the most likely explanation for the midstream urine culture result?

A. Bladder carcinoma
B. Colovesical fistula
C. Contaminated urine specimen
D. Cystitis
E. Interstitial nephritis

**Answer**: C

**Explanation**: A mixed growth in a urine specimen is usually a result of contamination. There are no features to suggest any other underlying urinary, renal or GI problems or any evidence of infection, especially with the lack of leucocytes.

---
### 122. Question 122
A 70 year old woman has 6 weeks of generalised shoulder and hip pain and stiffness. She feels excessively tired. Her temperature is 37.5°C. She has reduced range of movement at the shoulders, but no muscle tenderness. There is synovial thickening and tenderness at the right wrist

**Investigations:**
Erythrocyte sedimentation rate 85 mm/hr (<20) Creatine kinase 110 U/L (25–175)

What is the most appropriate treatment?

A. Allopurinol
B. Hydroxychloroquine
C. Ibuprofen
D. Prednisolone
E. Sulfasalazine

**Answer**: D

**Explanation**: This is because the clinical scenario is that of a patient with polymyalgia rheumatica based on the age, pattern of muscle weakness and raised ESR. Muscle enzymes are normal in patients with polymyalgia rheumatica. The treatment for polymyalgia rheumatica is corticosteroids.

---
### 123. Question 123
A 53 year old man has increasing abdominal swelling over several weeks, with severe abdominal pain developing over the past 12 hours. He drinks one to two bottles of vodka per day. He has jaundice. His temperature is 37.6°C. He has spider naevi and prominent veins on his abdominal wall. His abdomen is diffusely tender

**Investigations:**
Haemoglobin 136 g/L (130–175) White cell count 9.6 × 109/L (3.8–10.0) Platelets 160 × 109/L (150–400) INR 1.2 (1.0) ALT 350 IU/L (10–50) ALP 140 IU/L (25–115) Bilirubin 78 μmol/L (<17) Ultrasound scan of abdomen shows ascites with mild hepatosplenomegaly.

What is the most appropriate next step?

A. Ascitic tap
B. CT scan of abdomen
C. Hepatitis serology
D. Percutaneous liver biopsy
E. Ultrasound scan of abdomen

**Answer**: A

**Explanation**: Spontaneous bacterial peritonitis (SBP) should be suspected in patients with ascites due to cirrhosis who develop symptoms such as fever, abdominal pain or tenderness, and confusion. The signs and symptoms are more subtle compared with those seen in patients with standard bacterial peritonitis. It is important not to miss SBP as delayed recognition is associated with a high mortality.

---
### 124. Question 124
A 65 year old woman has had a painful, red and watery left eye for 3 days. Visual acuity is 6/24 on the left and 6/12 on the right. Fundoscopy is normal

What is the most appropriate next step in management?

A. Arrange ophthalmology outpatient appointment
B. Prescribe chloramphenicol eye drops
C. Prescribe prednisolone eye drops
D. Prescribe sodium cromoglicate eye drops
E. Refer to the ophthalmology department as an emergency

**Answer**: E

**Explanation**: Painful eye with loss of acuity needs urgent ophthalmology assessment.

---
### 125. Question 125
A 75 year old man with metastatic prostate cancer develops lumbar discomfort, weakness in both legs and urinary incontinence. His strength is 2/5 in all the lower limb muscle groups. He has bilateral extensor plantar reflexes, and sensation to pinprick is reduced below the umbilicus

What is the most appropriate immediate treatment?

A. Dexamethasone
B. Gabapentin
C. Morphine sulfate
D. Spinal decompression
E. Spinal radiotherapy

**Answer**: A

**Explanation**: The patient has likely malignant spinal cord compression. Glucocorticoids are standard initial treatment both to treat pain and reduce neurological deficit. This allows definitive investigation to be performed, and treatment planned. Standard treatment would be a loading dose of dexamethasone (16 mg IV or PO), followed by 8 mg bd.

---
### 126. Question 126
A 45 year old woman notices a painless breast lump while showering. She is seen urgently in the breast clinic for triple assessment

What is the best description of this type of assessment?

A. Clinical examination, breast imaging and bone scan
B. Clinical examination, breast imaging and core biopsy
C. MR scan, bone scan and excision biopsy
D. MR scan, genetic screening and excision biopsy
E. PET scan, genetic screening and core biopsy

**Answer**: B

**Explanation**: Triple assessment involves clinical examination, breast imaging (usually mammography and ultrasound) followed by biopsy to achieve a pathological diagnosis.

---
### 127. Question 127
A 52 year old man attends the hypertension clinic with an average daytime ambulatory BP monitoring reading of 164/105 mmHg. He has been previously well and currently takes no medication. He is of African–Caribbean ethnicity. In clinic, his BP is 158/98 mmHg. His 10-year cardiovascular risk is calculated to be 23%

In addition to atorvastatin, what is the most appropriate medication to prescribe?

A. Amlodipine
B. Bendroflumethiazide
C. Doxazosin
D. Losartan potassium
E. Ramipril

**Answer**: A

**Explanation**: Patients with Stage 2 hypertension and should offered drug treatment. As he is of African–Caribbean descent, the first line treatment is a calcium channel blocker. NICE guideline [NG136] Published: 28 August 2019 Last updated: 21 November 2023 https://www.nice.org.uk/guidance/ng136/chapter/Recommendations

---
### 128. Question 128
The association between low birth weight babies and maternal smoking during pregnancy is studied by obtaining smoking histories from women at the time of their first prenatal visit, then assessing birth weight at delivery and analysing according to the smoking histories

What is the best description of this type of study?

A. Case control
B. Case series
C. Clinical trial
D. Cross-sectional
E. Prospective cohort

**Answer**: E

**Explanation**: A prospective cohort study is a longitudinal cohort study that follows over time a group of similar individuals (i.e. babies) who differ with respect to certain factors under study (i.e. maternal smoking history), to determine how these factors affect rates of a certain outcome (i.e. birth weight).

---
### 129. Question 129
A 60 year old woman is found drowsy and confused. She has been unwell for 2–3 days with diarrhoea and vomiting. She has bipolar disorder. She takes lithium, risperidone and co-codamol. Her temperature is 37.3°C, pulse rate 94 bpm, BP 122/70 mmHg, respiratory rate 14 breaths per minute and oxygen saturation 99% breathing high-flow oxygen. Her GCS score is 12/15. She has coarse tremor in her arms and jerking movements of her legs

What is the most likely diagnosis?

A. Hypernatraemia
B. Lithium toxicity
C. Neuroleptic malignant syndrome
D. Opioid toxicity
E. Subdural haematoma

**Answer**: B

**Explanation**: The patient displays classic features of lithium toxicity (confusion, coarse tremor, jerking leg movements), likely precipitated by dehydration secondary to diarrhoea and vomiting.

---
### 130. Question 130
A 42 year old woman has 3 months of weight loss, insomnia, and palpitations. She has a fine resting tremor and bilateral proptosis

What is the most likely underlying pathological mechanism?

A. Antibody directed against the thyroid stimulating hormone receptor
B. Antibody directed against thyroid peroxidase
C. Autonomous activity of thyroid follicular cells
D. Destruction of thyroid cells by lymphocytes
E. Excess production of thyroid stimulating hormone

**Answer**: A

**Explanation**: The clinical picture fits with Graves disease. It is caused by autoantibodies to the thyroid stimulating hormone receptor (a.k.a thyrotropin receptor antibody, TRAb) that activates the receptor, stimulating thyroid hormone synthesis and secretion and a goitre.

---
### 131. Question 131
A 53 year old woman has 6 months of worsening tiredness. She has jaundice, xanthelasma and 7 cm non-tender hepatomegaly

**Investigations:**
INR 1.2 (1.0) ALT 60 IU/L (10–50) ALP 302 IU/L (25–115) Bilirubin 50 µmol/L (<17) Antinuclear antibodies 1:40 (negative at 1:20) Antimitochondrial antibodies 1:320 (negative at 1:20) Ultrasound scan of abdomen hepatosplenomegaly, no biliary dilatation

What is the most appropriate treatment?

A. Azathioprine
B. Lamivudine
C. Prednisolone
D. Thiamine
E. Ursodeoxycholic acid

**Answer**: E

**Explanation**: The clinical picture fits a diagnosis of primary biliary cholangitis (previously primary biliary cirrhosis) (raised ALP, AMA positive with no evidence of obstruction. There is good evidence that Ursodeoxycholic acid should be prescribed for all patients with this diagnosis. A biopsy is not required to make the diagnosis.

---
### 132. Question 132
A 91 year old woman is admitted from a nursing home with 3 days of vomiting and diarrhoea. Her pulse is 110 bpm. Her BP is 116/66 mmHg lying in bed, with a postural BP drop of 30 mmHg when sitting

**Investigations:**
Sodium 130 mmol/L (135–146) Potassium 4.0 mmol/L (3.5–5.3) Bicarbonate 20 mmol/L (22–29) Urea 25.6 mmol/L (2.5–7.8) Creatinine 177 µmol/L (60–120)

What is the most appropriate initial intravenous fluid?

A. 0.9% sodium chloride
B. 1.4% sodium bicarbonate
C. 1.8% sodium chloride
D. 4% glucose, 0.18% sodium chloride
E. 5% glucose

**Answer**: A

**Explanation**: The patient is hypovolaemic and needs IV fluid resuscitation. guidelines recommend using crystalloids that contain sodium in the range 130–154 mmol/l, with a bolus of 500 ml over less than 15 minutes (NICE guideline CG174).

---
### 133. Question 133
A 30 year old man has 3 months of intermittent but worsening headaches. He takes paracetamol and ibuprofen as required. His BP is 220/130 mmHg

**Investigations:**
Sodium 144 mmol/L (135–146) Potassium 3.0 mmol/L (3.5–5.3) Urea 7.0 mmol/L (2.5–7.8) Creatinine 92 µmol/L (60–120)

Which is the most likely underlying diagnosis?

A. Addison disease
B. Chronic kidney disease
C. Cushing disease
D. Phaeochromocytoma
E. Primary aldosteronism (Conn syndrome)

**Answer**: E

**Explanation**: Conn syndrome is the commonest endocrine cause of hypertension and much more common than Cushing's/Phaeo. The classic presenting signs of primary aldosteronism are hypertension and hypokalemia, although the latter is not present in all cases. The diagnosis should also be considered in those with severe hypertension (>150/100 mmHg), hypertension with sleep apnoea and hypertension with a family history of early onset hypertension.

---
### 134. Question 134
A 24 year old man has acute breathlessness and lightheadedness. He was admitted 24 hours ago following a car accident. He had multiple pelvic fractures and compound fractures of both tibia, requiring surgical fixation. He is on intravenous morphine via a patient-controlled analgesia device, prophylactic low molecular weight heparin, intravenous flucloxacillin and intravenous 0.9% saline at 120 mL/hour. He is confused and disorientated. His temperature is 36.4°C, pulse rate 100 bpm, BP 110/60 mmHg, respiratory rate 30 breaths per minute and oxygen saturation 85% breathing 4 L/min oxygen via nasal prongs. His chest is clear

What is the most likely diagnosis?

A. Cardiac tamponade
B. Fat embolism syndrome
C. Opiate toxicity
D. Pulmonary embolus
E. Subdural haematoma

**Answer**: B

**Explanation**: Classic presentation of fat emboli. Multiple fractures followed by early onset (within 24 hours) of hypoxia, dyspnoea, and tachypnoea are the most frequent findings. Neurologic manifestations range from the development of an acute confusional state and altered level of consciousness to seizures and focal deficits and usually follow respiratory symptoms. A petechial rash is the last component to appear and only appears in about a third of cases. Patients with PE may present in the same time frame (i.e., 24 to 72 hours), but neurologic abnormalities are not explained by this.

---
### 135. Question 135
A 46 year old man has a cardiac arrest in the emergency department after an episode of chest pain. He remains in ventricular fibrillation after three DC shocks, and he is treated with a bolus of intravenous adrenaline/epinephrine

What other drug treatment should be administered at the same time?

A. Alteplase
B. Amiodarone hydrochloride
C. Atropine sulfate
D. Lidocaine
E. Magnesium sulfate

**Answer**: B

**Explanation**: If VF/VT persists after a third shock, resume chest compressions immediately and then give adrenaline 1 mg IV and amiodarone 300 mg IV while performing a further 2 min CPR. 2021 Resuscitation Guidelines https://www.resus.org.uk/library/2021-resuscitation-guidelines/adult-advanced- life-support-guidelines

---
### 136. Question 136
An 18 year old man has 3 weeks of malaise, fever and headaches and 1 week of a sore throat. His temperature is 37.6°C, pulse 84 bpm, BP 120/82 mmHg and respiratory rate 12 breaths per minute. He has large tonsils with exudate, a petechial rash on the palate, and axillary and inguinal lymphadenopathy

**Investigations:**
White cell count 11.2 × 109/L (3.8–10.0) Lymphocytes 5.5 × 109/L (1.1–3.3) ALT 72 IU/L (10–50) AST 45 IU/L (10–40) Alkaline phosphatase 91 IU/L (25–115) Bilirubin 16 µmol/L (<17)

What is the most appropriate investigation to confirm the diagnosis?

A. Anti-streptolysin O titre
B. Blood cultures
C. Epstein–Barr virus serology
D. Hepatitis A serology
E. Throat swab

**Answer**: C

**Explanation**: This is a typical clinical picture of glandular fever in the usual age group. Epstein-Barr virus (EBV)-induced infectious mononucleosis (IM) should be suspected when a young adult complains of sore throat, fever, and malaise and also has lymphadenopathy and pharyngitis. The presence of palatal petechiae is also characteristic. Lymphocytosis is usually seen in the FBC. The diagnosis can be confirmed through EBV specific antibodies.

---
### 137. Question 137
A 74 year old man is brought to the emergency department after falling down the stairs. He has no pain. He has atrial fibrillation and takes apixaban. He has significant bruising to the left side of his face and left arm. His pulse is 80 bpm, irregular, BP 150/95 mmHg and oxygen saturation 96% breathing air. His GCS score is 14

What is the most appropriate next step in management?

A. Cervical spine immobilisation
B. Chest X-ray
C. CT of head
D. Intravenous prothrombin complex
E. Intravenous vitamin K

**Answer**: A

**Explanation**: This is because sequence of care for potential trauma patient is airway and cervical spine. There is no mention of a collar so this should be applied. This would need to be done before any of the other options. A CT scan head will be required and a chest X-ray likely. Vitamin K would not have a role and the use of prothrombin complex or other reversal agents would depend on the results of subsequent investigations.

---
### 138. Question 138
A 17 year old boy has repeated episodes characterised by a funny 'racing' sensation in his abdomen, followed by loss of awareness. His girlfriend describes that he has a vacant stare and waves his left arm around in a writhing manner during these attacks

Which is the most likely site of origin of these episodes?

A. Cerebellum
B. Right frontal lobe
C. Right occipital lobe
D. Right parietal lobe
E. Right temporal lobe

**Answer**: E

**Explanation**: He has focal onset impaired awareness seizures, the aura implicates one of the temporal lobes. In the seizure itself he waves his left arm, suggesting spread to the right frontal lobe (though the origin is elsewhere).

---
### 139. Question 139
A 45 year old woman is feeling unwell with a severe sore throat. She has schizophrenia and started taking clozapine 4 months ago. Her temperature is 39.0°C. She has an ulcerated throat with tonsillar exudate. Blood cultures have been sent

What additional investigation is most likely to establish the underlying cause?

A. Clozapine concentration
B. Creatine kinase
C. Full blood count
D. Lumbar puncture
E. Throat swab

**Answer**: C

**Explanation**: Risk of agranulocytosis on clozapine - potential medical emergency. Clozapine induced agranulocytosis occurs in around 1% of patients and usually occurs between 6-18 weeks of initiation of therapy.

---
### 140. Question 140
A 34 year old man has 3 days of fever, sweats and productive cough, bringing up brown sputum. His temperature is 38.8°C. He has bronchial breathing over the right mid zone. His chest X-ray is shown (see image)

[IMAGE: image_140_MLA3_page45_image_45_2.png]

What is the most likely pathogen?

A. Haemophilus influenzae
B. Legionella pneumophila
C. Mycoplasma sp. 
D. Staphylococcus aureus
E. Streptococcus pneumoniae

**Answer**: E

**Explanation**: The clinical and radiological findings are typical of Streptococcus pneumonia. In this age group with strep pneumonia is the most common. Its incidence in older patients may be reduced by increasing use of pneumococcal vaccination in patients with underlying respiratory disease or immunoconpromise.

---
### 141. Question 141
A 38 year old man has 3 months of cough with bloodstained sputum. A sputum analysis is positive for Mycobacterium tuberculosis. He is treated with quadruple antituberculous therapy. Two weeks later he reports that he is passing orange urine

Which is the medication most likely to be responsible for his orange urine?

A. Ethambutol
B. Isoniazid
C. Pyrazinamide
D. Pyridoxine
E. Rifampicin

**Answer**: E

**Explanation**: Rifampicin typically causes an orange or red-orange discolouration of body fluids (including urine, sweat, saliva, and tears). The patient should be warned of this possibility.

---
### 142. Question 142
A 46 year old woman attends the emergency department with fever, headache and confusion, which developed over several hours. She finds it impossible to lift her head from the pillow and resists the doctor's attempts to feel her neck. Her temperature is 38.1°C, pulse 105 bpm and BP 110/60 mmHg. Her GCS score is 14. A CT scan of her head is normal. A lumbar puncture is performed

What are the most likely observations in the cerebrospinal fluid?

A. High pressure, normal protein, excess red cells
B. High pressure, raised protein, excess neutrophils
C. Normal pressure, normal protein, excess lymphocytes
D. Normal pressure, raised protein, excess neutrophils
E. Normal pressure, normal protein, no cells

**Answer**: B

**Explanation**: This is because she has typical bacterial meningitis- fever, neck pain, confusion. A high pressure acute inflammatory exudate is typical.

---
### 143. Question 143
A 51 year old woman attends her GP with 6 months of dry mouth and gritty eyes. She has had vitiligo for 10 years. Both parotid glands are mildly enlarged

What is the most likely diagnosis?

A. Graves disease
B. Pleomorphic adenoma
C. Sarcoidosis
D. Sialolithiasis (salivary gland calculi)
E. Sjögren syndrome

**Answer**: E

**Explanation**: Sjögren syndrome can be associated with other autoimmune conditions (e.g. vitiligo) and typically affects tear ducts and salivary glands. The length of the clinical history is too long for acute infection. Sarcoidosis is associated with widespread lymphadenopathy, including parotid involvement, but is not typically associated with sicca symptoms.

---
### 144. Question 144
A 62 year old man has 1 year of intermittent heartburn and difficulty in swallowing. An endoscopic biopsy of the oesophagus 5 cm above the anatomical gastro oesophageal junction is reported as showing 'columnar epithelium containing goblet cells and Paneth cells'

What is the most appropriate pathological description of the features noted?

A. Hyperplasia
B. Hypertrophy
C. Intestinal metaplasia
D. Intraepithelial neoplasia
E. Squamous metaplasia

**Answer**: C

**Explanation**: This is because the combination of goblet cells and Paneth cells is characteristic of (small) intestinal metaplasia.

---
### 145. Question 145
A 64 year old man is admitted to the emergency department with acute dyspnoea. His exercise tolerance has been limited by breathlessness for several years

**Investigations:**
Arterial blood gas breathing air: pH 7.20 (7.35–7.45) PO2 8 kPa (11–15) PCO2 8.1 kPa (4.6–6.4) Bicarbonate 23 mmol/L (22–30) Base excess –4 mmol/L (–2 to +2)

What is the best interpretation of the arterial blood result?

A. Acute type 1 respiratory failure
B. Acute type 2 respiratory failure
C. Chronic type 1 respiratory failure
D. Chronic type 2 respiratory failure
E. Metabolic acidosis

**Answer**: B

**Explanation**: This is because the hypoxaemia and retention of CO2 resulting in a low pH is typical of an acute on chronic hypoxia of COPD. The normal [HCO(3)-] excludes a primary metabolic cause.

---

### 146. Question 146
A 48 year old man has 1 day of severe right upper quadrant pain. He has vomited five times. He smokes 10 cigarettes per day and drinks 31 units of alcohol per week. His temperature is 37.8°C, pulse 90 bpm and BP 140/84 mmHg. He is tender in the epigastrium and right upper quadrant, and there is voluntary guarding

**Investigations:**
White cell count 15 × 109/L (3.8–10.0) ALT 41 IU/L (10–50) Alkaline phosphatase 125 IU/L (25–115) Bilirubin 14 µmol/L (<17) Amylase 222U/L (<220) CRP 42 mg/L (<5)

What is the most likely diagnosis?

A. Acute cholangitis
B. Acute cholecystitis
C. Acute hepatitis
D. Acute pancreatitis
E. Biliary colic

**Answer**: B

**Explanation**: History and investigations fit with acute cholecystitis. Amylase is not high enough for acute pancreatitis, and one would expect higher bilirubin with cholangitis. Biliary colic would not have inflammatory response. LFTs do not fit with hepatitis.

---
### 147. Question 147
A 65 year old woman has had disorientation and dizziness for one week. She has headaches that are worse when bending over and associated with vomiting. She had a non-small cell lung cancer that was treated with radical radiotherapy two years ago. BP is 178/95 mmHg. She has no focal neurological signs

What is the most likely diagnosis?

A. Cerebral metastases
B. Hypercalcaemia
C. Hyponatraemia
D. Paraneoplastic encephalitis
E. Severe hypertension

**Answer**: A

**Explanation**: These are typical observations due to intracranial hypertension secondary to cerebral metastases.

---
### 148. Question 148
An 66 year old woman with advanced bowel cancer is taking morphine sulfate modified release, 30 mg twice daily for abdominal pain. She is in the last days of life and is now unable to swallow oral medications. She has not needed any doses for breakthrough pain

**Investigations:**
eGFR 51 mL/min/1.73 m2 (>60) A continuous subcutaneous infusion of morphine sulfate is required, as a direct conversion from oral morphine sulfate.

Which is the correct dose of morphine sulfate to prescribe over 24 hours?

A. 15 mg
B. 30 mg
C. 60 mg
D. 90 mg
E. 120 mg

**Answer**: B

**Explanation**: Dose of morphine sulfate SC in 24 hours = 0.5 x Total Morphine sulfate oral dose in 24 hours.

---
### 149. Question 149
A 24 year old man develops low back pain the day after falling while playing tennis. He is usually well and takes no regular medication. He is a laboratory technician

What is the most appropriate advice?

A. Avoid work until the pain has completely settled
B. Back strengthening exercises
C. Bed rest until pain improves, then gradual mobilisation
D. Continue usual activity
E. Self referral for physiotherapy

**Answer**: D

**Explanation**: Short duration acute low back pain in fit person. Therefore most appropriate response would be to continue usual activity and to provide appropriate safety netting advice. Back pain - low (without radiculopathy): Scenario: Management Last revised in October 2024 https://cks.nice.org.uk/topics/back-pain-low-without- radiculopathy/management/management/

---
### 150. Question 150
A 44 year old woman has shooting pain in her left leg. She has an advanced rectal cancer compressing the sciatic nerve. She is taking morphine sulfate modified release 20 mg twice daily. This is providing some benefit but not fully controlling her pain

Which is the most appropriate additional medication?

A. Oral amitriptyline
B. Oral diclofenac
C. Oral tramadol
D. Oral venlafaxine
E. Topical ibuprofen

**Answer**: A

**Explanation**: Amitriptyline first line for nerve compression pain / neuropathic pain. Pregabalin, gabapentin and duloxetine are also first line options for treating neuropathic pain. Clinical guideline [CG173] Published: 20 November 2013Last updated: 22 September 2020 https://www.nice.org.uk/guidance/cg173/chapter/Recommendations

---
### 151. Question 151
A 67 year old man attends the emergency department feeling generally unwell with no specific symptoms. He is being treated with neoadjuvant chemotherapy for bowel cancer. He underwent the third cycle 8 days ago. His temperature is 38.6°C, pulse 97 bpm, BP 132/68 mmHg, respiratory rate 12 breaths per minute and oxygen saturation 95% breathing air. Examination is otherwise unremarkable. Blood tests have been taken, but results are not yet available

What is the most appropriate next step in management?

A. Admit to medical receiving unit
B. Await blood results before taking further action
C. Discuss with local oncology team for advice
D. Give intravenous broad-spectrum antibiotics
E. Give intravenous fluid therapy

**Answer**: D

**Explanation**: This patient is at high risk of neutropenic sepsis: 8 days post- chemotherapy, (even though agent is unknown). As such, prompt antibiotic administration is a priority before any other action.

---
### 152. Question 152
A 67 year old woman has right-sided pleuritic chest pain and breathlessness of sudden onset. She had a bleeding peptic ulcer secondary to NSAID use 4 weeks ago requiring a 2-unit blood transfusion. She has osteoarthritis. She takes lansoprazole and co-codamol. Her pulse is 112 bpm, BP 114/74 mmHg, respiratory rate 26 breaths per minute and oxygen saturation 94% breathing 40% oxygen. Her chest is clear

**Investigations:**
Haemoglobin 93 g/L (115–150) Creatinine 81 µmol/L (60–120) CT pulmonary angiogram: thrombus in both pulmonary arteries

What is the most appropriate initial treatment?

A. Insertion of vena cava filter
B. Intravenous alteplase
C. Intravenous heparin
D. Oral apixaban
E. Subcutaneous dalteparin sodium

**Answer**: C

**Explanation**: The patient has a sub-massive pulmonary embolus but is also at risk of haemorrhage. In this setting IV unfractionated heparin is best option as it can be stopped and reversed in event of recurrent bleeding.

---
### 153. Question 153
A 88 year old woman has 30 hours of severe abdominal pain. She was discharged from hospital 4 weeks ago following an aortobifemoral bypass graft. She has diffuse tenderness of the abdomen with absent bowel sounds. Plain X-ray of the abdomen is unremarkable

**Investigations:**
Haemoglobin 114 g/L (115-160) White cell count 18 × 109/L (3.8–10.0) Urea 16.4 mmol/L (2.5–7.8) Creatinine 158 µmol/L (60–120) CRP 110 mg/L (<5) Arterial blood gas breathing air pH 7.28 (7.35–7.45) PO2 13 kPa (11–15) PCO2 4.6 kPa (4.6–6.4) Bicarbonate 16 mmol/L (22–30) Lactate 4.5 mmol/L (1–2)

What is the most likely diagnosis?

A. Acute diverticulitis
B. Acute pancreatitis
C. Incarcerated paraumbilical hernia
D. Mesenteric ischaemia
E. Ruptured aortic aneurysm

**Answer**: D

**Explanation**: History of vascular disease and lactic acidosis make mesenteric ischaemia most likely diagnosis.

---
### 154. Question 154
A 59 year old woman has 4 days of sharp central chest pain that radiates into her back and is worse on lying flat. Her temperature is 37.7°C, pulse 105 bpm, BP 100/72 mmHg, respiratory rate 18 breaths per minute and oxygen saturation 96% breathing air. Heart sounds are normal, brachial pulses in both arms are synchronous

**Investigations:**
Haemoglobin 152 g/L (115–160) White cell count 11 × 109/L (3.8–10.0) Platelets 390 × 109/L (150–400) Neutrophils 7.5 × 109/L (2.0–7.5) D dimers 0.5 mg/L (<0.5) Troponin T 0.5 µg/L (<0.01) CRP 30 mg/L (<5) ECG: see image

[IMAGE: image_154_MLA4_page10_image_10_2.png]

What is the most likely diagnosis?

A. Acute coronary syndrome
B. Aortic dissection
C. Musculoskeletal chest pain
D. Pericarditis
E. Pneumonia

**Answer**: D

**Explanation**: History most consistent with infective cause and pericarditis from ECG as saddle shape changes.

---
### 155. Question 155
The surgical registrar is running late due to a fault with their car . She asks the surgical Foundation Year 1 doctor (FY1) to obtain written consent from the patients on the afternoon list to avoid a delayed start and possible cancellations. The list is three dupuytren's contracture releases. The FY1 has not assisted with this operation on this rotation

What is the most appropriate action for the FY1 to take?

A. Ask the consultant to consent the patients
B. Consent all of the patients
C. Consent all of the patients and ask the registrar to countersign the forms
D. Only consent the patients without significant medical conditions
E. Refuse to consent the patients

**Answer**: A

**Explanation**: An FY1 does not have the experience to provide informed consent for a surgical procedure.

---
### 156. Question 156
A 33 year old man has 12 hours of severe, constant pain of sudden onset radiating from the right flank to the groin. He has no significant past medical history. Urinalysis shows blood 2+, protein negative and leucocytes 1+

Which is the most appropriate initial investigation?

A. Contrast CT of abdomen and pelvis
B. Intravenous urography
C. Non-contrast CT of renal tract
D. Plain X-ray of renal tract
E. Ultrasonography of renal tract

**Answer**: C

**Explanation**: An unenhanced CT KUB is the recommended first investigation of renal stones. NICE guideline NG118- 8/1/19.

---
### 157. Question 157
A 63 year old man attends his GP for review following addition of chlortalidone to maximal-dose ramipril for BP control. He also has type 2 diabetes mellitus and chronic kidney disease, and takes metformin. His creatinine 1 month ago was 115 μmol/L (60–120). His BP is 133/85 mmHg

**Investigations:**
Sodium 135 mmol/L (135–146) Potassium 4.6 mmol/L (3.5–5.3) Urea 9.0 mmol/L (2.5–7.8) Creatinine 140 µmol/L (60-120) eGFR 44 mL/min/1.73 m2 (>60)

Which is the most appropriate management?

A. Stop metformin
B. Repeat urea and electrolytes in 2 weeks
C. Stop chlortalidone
D. Stop ramipril
E. Switch chlortalidone to amlodipine

**Answer**: B

**Explanation**: The patient has had a <30% increase in serum creatinine. At this level there is no indication to change treatment, repeat of renal function in 2-4 weeks is reasonable.

---
### 158. Question 158
A 40 year old woman has 1 day of a painful, swollen left elbow and fever. She has rheumatoid arthritis and takes methotrexate and infliximab. Her temperature is 38.2°C, pulse 100 bpm and BP 119/83 mmHg. The left elbow is swollen and erythematous

**Investigations:**
White cell count 16.4 × 109/L (3.8–10.0) Urea 6.7 mmol/L (2.5–7.8) Creatinine 98 µmol/L (60–120) CRP 171 mg/L (<5) Joint aspiration: no organisms on Gram stain, white cell count 2043/µL (<200), mostly neutrophils, no crystals. She is advised to take oral paracetamol.

What is the most appropriate additional management?

A. Inject methylprednisolone into the joint
B. Intravenous flucloxacillin
C. No further treatment pending culture results
D. Oral colchicine
E. Oral prednisolone

**Answer**: B

**Explanation**: This gives every impression of being a septic arthritis, to the priority is to treat the infection, which should not wait for culture results. Steroids could be very harmful in this situation.

---
### 159. Question 159
A 33 year old man is found collapsed on the medical ward. He was admitted 3 days ago with urosepsis and is being treated with intravenous antibiotics. He has type 1 diabetes and has been taking his usual doses of subcutaneous insulin. He is unrousable and is clammy. His capillary blood glucose is 2.1 mmol/L

What is the most appropriate immediate treatment?

A. 20 mL of 50% glucose by slow intravenous injection
B. 75 mL of 20% glucose by intravenous infusion
C. 150 mL of 5% glucose by intravenous infusion
D. Glucagon 1 mg by intramuscular injection
E. Glucose gel 25 g (contains 10 g glucose) applied to buccal mucosa

**Answer**: B

**Explanation**: 20% glucose is first choice treatment. 50% glucose too hyperosmolar with risk of local tissue necrosis. Glucagon has unpleasant effects (nausea and flushing) but is reasonable second choice if no venous access available. 5% glucose will not reverse hypo effectively. Risk of aspiration with glucose gel in unconscious patient. Joint British Diabetes Society Guidelines: Hospital management of hypoglycaemia in adults with diabetes mellitus (updated 2023)

---
### 160. Question 160
A 67 year old woman with type 2 diabetes mellitus attends the clinic for review. Her metformin treatment was stopped during a recent hospital admission with a hip fracture, in view of worsening chronic kidney disease (eGFR 28 mL/min/1.73 m2 (>60)). She has diverticular disease. She takes the maximum dose of gliclazide

**Investigations:**
Glycated haemoglobin 79 mmol/mol (20–42) She is keen to avoid giving herself injections.

What is the most appropriate additional treatment?

A. Acarbose (α-glucosidase inhibitor)
B. Dulaglutide (GLP-1 agonist)
C. Empagliflozin (SGLT2 inhibitor)
D. Pioglitazone (thiazolidinedione)
E. Sitagliptin (DPP4 inhibitor)

**Answer**: E

**Explanation**: Sitagliptin approved for use in CKD. Dulaglutide is sc injection. Empagliflozin unlikely to exert significant glycaemic effect at this GFR. Pioglitazone is contra-indicated in heart failure, bladder cancer and can cause fractures. Acarbose unlikely to be tolerated due to GI adverse effects.

---
### 161. Question 161
A 62 year old Indian woman attends her GP for an NHS health check. Her BMI is 34 kg/m2. Her BP is 110/84 mmHg. Urinalysis is normal

**Investigations:**
Glycated haemoglobin 45 mmol/mol (20–42)

What is the most appropriate next step in management?

A. Advise a low sugar diet
B. Prescribe metformin
C. Prescribe ramipril
D. Refer her to the Diabetes Prevention Programme
E. Send off a fasting plasma glucose

**Answer**: D

**Explanation**: This patient has pre-diabetes and is at risk of developing type 2 diabetes. This patient should have education on diet and lifestyle measures through a national prevention programme.

---
### 162. Question 162
A 53 year old woman has 6 days of worsening abdominal pain. She has also had recent constipation. There is no rectal bleeding. Her temperature is 37.8°C, pulse 105 bpm and BP 140/85 mmHg. She has tenderness in the left iliac fossa with some guarding. Bowel sounds are normal. Rectal examination shows hard stools only

What is the most likely diagnosis?

A. Ischaemic colitis
B. Meckel diverticulitis
C. Proctocolitis
D. Rectal carcinoma
E. Sigmoid diverticulitis

**Answer**: E

**Explanation**: The classical presentation of diverticulitis includes change in bowel habit, left iliac fosa pain and features of infection (i.e. pyrexia).

---
### 163. Question 163
A 76 year old man has nausea, fever and rigors. He also has foul smelling urine. He was discharged 3 days ago after being treated for a PE. He has been having low molecular weight heparin injections twice daily since the diagnosis. He had a cholecystectomy 12 years ago. His temperature is 39.7°C, pulse 100 bpm and BP 92/41 mmHg

**Investigations:**
APTT 43 seconds (22–41) PT 18 seconds (10–12)

What is the most likely cause of the prolonged prothrombin time?

A. Disseminated intravascular coagulation
B. Liver disease
C. Low molecular weight heparin
D. Lupus anticoagulant
E. Vitamin K deficiency

**Answer**: A

**Explanation**: Diagnosis of DIC is based on presence of ≥1 known underlying condition causing DIC plus abnormal global coagulation tests: decreased platelet count, increased prothrombin time, elevated fibrin-related marker (D- dimer/fibrin degradation products) and decreased fibrinogen level. In this patient the underlying condition triggering DIC is sepsis and it is likely that further blood tests would show abnormalities in the above markers.

---
### 164. Question 164
A 62 year old man has a right-sided hearing loss. There has been slow deterioration over the previous two years, and he is now also troubled by non- pulsatile, right-sided tinnitus that prevents him from sleeping. A pure-tone audiogram shows a right-sided high-frequency hearing loss. He has normal tympanometry bilaterally

Which is the most appropriate diagnostic investigation?

A. Cerebral angiography
B. CT of head
C. CT of petrous temporal bones
D. MR imaging of internal acoustic meatus
E. PET–CT of brain

**Answer**: D

**Explanation**: Where there is a unilateral sensorineural hearing loss, it is vital to exclude the presence of a vestibular schwannoma or other neoplasm of VIII nerve or brainstem. This is done via an MRI scan.

---
### 165. Question 165
A 65 year old woman has had bloody diarrhoea six times each day for the past 4 weeks and is feeling unwell. She has noticed urgency to pass stool and has to get up in the night to pass stool. Her left eye has been red, but not painful. Her temperature is 38.5°C, pulse 109 bpm, BP 110/70 mmHg and respiratory rate 22 breaths per minute

**Investigations:**
Stool culture: negative

What is the most likely diagnosis?

A. Adenocarcinoma of the colon
B. Crohn disease
C. Irritable bowel syndrome
D. Microscopic colitis
E. Ulcerative colitis

**Answer**: E

**Explanation**: Typical IBD history, including bloody diarrhoea and eye symptoms. These symptoms are far more common in UC than Crohn disease.

---
### 166. Question 166
A 28 year old man attends his GP with 7 weeks of right iliac fossa pain, weight loss of 3 kg and diarrhoea five times a day. He previously opened his bowels once daily. He has not travelled abroad. He lives with his partner, who is well. Rectal examination is normal.

**Investigations:**
Haemoglobin 129 g/L (135-180 g/l) White cell count 11.4 × 109/L (3.8–10.0) Platelets 450 × 109/L (150–400) Erythrocyte sedimentation rate 60 mm/hr (<20) ALT 10 IU/L (10–50) ALP 110 IU/L (25–115) Bilirubin 15 µmol/L (<17) Albumin 32 g/L (35–50)

Which is the most appropriate next investigation?

A. Antimitochondrial antibodies
B. Anti-tissue transglutaminase antibodies
C. Faecal calprotectin
D. Faecal occult blood testing
E. Stool cultures

**Answer**: E

**Explanation**: Most likely diagnosis is Inflammatory Bowel Disease, but stool cultures should form part of work up in primary care before referral. Ulcerative colitis: How should I investigate a person with suspected ulcerative colitis? Last revised in March 2024 https://cks.nice.org.uk/topics/ulcerative-colitis/diagnosis/investigations/

---
### 167. Question 167
A 49 year old woman is undergoing investigation for headaches. She has no visual symptoms. Her visual acuity is 6/5 bilaterally. There is a visual field defect

**Investigations:**
MR scan of brain: pituitary adenoma indenting the optic chiasm

Which is the most likely visual field defect?

A. Bilateral concentric visual loss
B. Bilaterally enlarged blind spots
C. Bitemporal hemianopia
D. Left-sided homonymous hemianopia
E. Right-sided homonymous hemianopia

**Answer**: C

**Explanation**: In a patient with an intracranial tumour who has no visual symptoms and normal visual acuity, the earliest visual field deficit will be red desaturation in the bitemporal lower visual fields. Patients with complete bitemporal hemianopia would likely have visual symptoms. The blind spots are normal in chiasmal compression unless there is associated papilloedema from raised intracranial pressure (Foster Kennedy syndrome).

---
### 168. Question 168
A 36 year old man has recurrent episodes of collapse over 4 months. When laughing, his muscles feel limp and he falls to the floor, but remains conscious. He has anxiety and depression and takes citalopram. His father died from an ischaemic stroke aged 59 years

Which is the most likely diagnosis?

A. Cardiogenic syncope
B. Cataplexy
C. Cough syncope
D. Dissociative (non-epileptic) seizures
E. Epilepsy

**Answer**: B

**Explanation**: Cataplexy classically presents with loss of skeletal muscle tone with strong (usually positive) emotions.

---
### 169. Question 169
A 37 year old man has 4 weeks of pain on the radial side of his left wrist. The pain is worse when he plays the piano. He has no history of trauma. He has swelling and tenderness over the distal end of the left radial styloid. The pain is exacerbated by ulnar deviation of the wrist when the thumb is clasped in the palm

What is the most likely diagnosis?

A. De Quervain tendinopathy
B. Ganglion cyst
C. Intersection syndrome
D. Osteoarthritis of the trapeziometacarpal joint
E. Scaphoid fracture

**Answer**: A

**Explanation**: The diagnosis of de Quervain tendinopathy usually has a history of atraumatic radial wrist pain with tenderness and enlargement at the first dorsal compartment over the radial styloid and pain at the radial styloid with active or passive stretch the thumb tendons over the radial styloid in thumb flexion (the Finkelstein test).

---
### 170. Question 170
A 41 year old woman is admitted following a significant overdose of amitriptyline and propranolol taken 30 minutes ago. Her GCS is 15. Her pulse is 80 bpm, BP 134/90 mmHg, respiratory rate 14 breaths per minute and oxygen saturation 98% breathing air

**Investigations:**
Arterial blood gas breathing air pH 7.42 (7.35–7.45) PO2 11.7 kPa (11–15) PCO2 4.9 kPa (4.6–6.4) Bicarbonate 24 mmol/L (22–30) ECG: sinus rhythm, QRS duration 100 ms (80–120)

What is the most appropriate next step in management?

A. Arrange gastric lavage
B. Give oral activated charcoal
C. Give oral ipecacuanha
D. Start IV 1.26% sodium bicarbonate
E. Start IV acetylcysteine

**Answer**: B

**Explanation**: Activated charcoal should be considered for people who have self harmed by poisoning, who present early (within one hour of ingestion), are fully conscious with a protected airway, and are at risk of significant harm as a result of poisoning.

---
### 171. Question 171
A 48 year old man has 8 months of a painful, stiff left shoulder. The pain is dull and worse at night. There is no history of trauma. He has type 1 diabetes mellitus. He has reduced passive and active range of movement in the left shoulder with pain at extremes of range of motion. Neck movements are normal. Power and sensation are normal

**Investigations:**
CRP 6mg/L (<5)

What is the most likely diagnosis?

A. Adhesive capsulitis
B. Glenohumeral osteoarthritis
C. Polymyalgia rheumatica
D. Rotator cuff tear
E. Subacromial bursitis

**Answer**: A

**Explanation**: Adhesive capsulitis (frozen shoulder) presents with dull shoulder pain, that often disturbs sleep, followed by stiffness and loss of shoulder mobility. Adhesive capsulitis is unlikely in patients younger than 40 years of age, and patients older than 70 are more likely to have rotator cuff tears or glenohumeral osteoarthritis. Patients with subacromial pathology often give an occupational or athletic history of heavy lifting or repetitive movements, especially above shoulder level. Patients with rotator cuff tendinopathy and subacromial bursitis often complain of activity-related pain and problems performing usual activities. Adhesive capsulitis is more common is diabetics.

---
### 172. Question 172
A 57 year old woman is reviewed following a bone densitometry scan (DXA). She was recently found to have polymyalgia rheumatica, and treatment with oral prednisolone was started. The T-score for the bone mineral density in her femoral neck is –3.9. She is advised to take colecalciferol with calcium carbonate

What is the most appropriate additional treatment?

A. Alendronic acid
B. Denosumab
C. No additional treatment
D. Raloxifene hydrochloride
E. Teriparatide

**Answer**: A

**Explanation**: Alendronic acid first line; the other options are all used to treat osteoporosis but are not used first line. Clinical Guideline: NOGG 2024 Updated December 2024 https://www.nogg.org.uk/full-guideline

---
### 173. Question 173
A 66 year old woman attends the GP with 7 weeks of intermittent dizziness that she describes as 'the room spinning'. The episodes start suddenly, are usually triggered by looking upwards, and last less than a minute before resolving completely. She reports nausea during these episodes. She is otherwise well. Otoscopic and neurological examinations are normal

What is the most likely diagnosis?

A. Acoustic neuroma
B. Benign paroxysmal positional vertigo
C. Cerebellar lesion
D. Ménière disease
E. Vestibular neuritis

**Answer**: B

**Explanation**: The signs and symptoms are typical of benign paroxysmal positional vertigo (BPPV). All of the answer options can cause “dizziness”, but the description of the dizziness, along with the absence of other accompanying signs/symptoms, the timing (recurrence with periods of being asymptomatic), trigger (of turning head quickly) and normal neurological exam indicate BPPV rather than any of the other options.

---
### 174. Question 174
A 62 year old man becomes increasingly breathless 3 hours after the removal of a chest drain. The chest drain was inserted for a right-sided pleural effusion secondary to lymphoma . Three litres of bloodstained fluid were drained before removal

What is the most likely diagnosis?

A. Aspiration pneumonia
B. Pneumothorax
C. Pulmonary embolism
D. Pulmonary oedema
E. Recurrence of effusion

**Answer**: B

**Explanation**: This patient has suffered an iatrogenic pneumothorax secondary to insertion of a chest drain.

---
### 175. Question 175
A 38 year old woman has abdominal pain 7 days after a laparoscopic sleeve gastrectomy for weight loss. Her temperature is 36.5°C, pulse 110 bpm, BP 120/72 mmHg and oxygen saturation 96% breathing oxygen 4 L/min via nasal prongs. She has reduced breath sounds in both bases. She has abdominal tenderness with guarding and reduced bowel sounds

What is the most appropriate diagnostic investigation?

A. Abdominal X-ray
B. Barium enema
C. CT of abdomen
D. Erect chest X-ray
E. Point-of-care FAST scan

**Answer**: C

**Explanation**: A CT scan (usually with intravenous contrast) is most likely to provide diagnostic information to plan further management in a post-op situation like this. No other investigations are indicated.

---
### 176. Question 176
A 25 year old woman is short of breath 12 hours after abdominal surgery for adhesions. Her pulse is 119 bpm, BP 92/54 mmHg, respiratory rate 24 breaths per minute and oxygen saturation 96% breathing oxygen 4 L/minute via nasal cannulae. She has a large volume of blood in her abdominal drains. She is treated with an IV fluid bolus, and the surgical registrar is informed

What is the most appropriate next management step?

A. Activate major haemorrhage protocol
B. Give IV noradrenaline/norepinephrine
C. Give IV tranexamic acid
D. Give prothrombin complex concentrate
E. Increase oxygen to 15 L/min via a non-rebreather mask

**Answer**: A

**Explanation**: This patient is in a critical condition and blood products will be required quickly. This is achieved by activation of major haemorrhage protocol.

---
### 177. Question 177
A 59 year old man attends the GP for review. He has type 1 diabetes mellitus, hypertension, ischaemic heart disease and CKD stage 4 (recent eGFR 25 mL/min/1.73 m2 (> 60)). He takes insulin, lisinopril, metoprolol tartrate and aspirin. His BP is 160/96 mmHg. He has pitting oedema to the mid shin. Urinalysis shows protein 2+

**Investigations:**
Sodium 144 mmol/L (135–146) Potassium 5.4 mmol/L (3.5–5.3) Urea 19.2 mmol/L (2.5–7.8) Creatinine 237 µmol/L (60–120) eGFR 26 mL/min/1.73 m2 (>60)

What is the most appropriate therapeutic change?

A. Add indapamide
B. Add furosemide
C. Add spironolactone
D. Stop lisinopril
E. Switch lisinopril to losartan

**Answer**: B

**Explanation**: The patient has hypertension outside of target (130/80 mmHg), with evidence of peripheral oedema. Furosemide will reduce peripheral oedema, lower BP and help with hyperkalaemia. Bendroflumethiazide is less effective when compared to furosemide when the creatinine clearance is below

---
### 178. Question 178
A 30 year old woman is brought to the resuscitation room of the emergency department after being kicked by a horse . She is 28 weeks pregnant. Her cervical spine is immobilised. She is conscious and asks about her baby. Her temperature is 37°C, pulse 100 bpm, BP 78/56 mmHg and oxygen saturation 99% breathing 40% oxygen. Fluid resuscitation has been started and bloods have been sent

What is the most appropriate next step?

A. Image the long bones and pelvis, and orthopaedic review
B. Perform a full primary survey
C. Scan the baby and arrange fetal monitoring
D. Transfer to theatre for immediate delivery of baby
E. X-ray cervical spine

**Answer**: B

**Explanation**: The patient is tachycardic and hypotensive. It is likely that they are bleeding. They need a full primary survey to identify any potential life threatening injuries and commence treatment. The resuscitation efforts are mainly focused on the mother not the fetus. Delivery of the fetus at this point would only be indicated to aid resuscitation of the mother.

---
### 179. Question 179
A 55 year old man is brought to the emergency department with 2 hours of severe left sided chest pain. A pre-hospital ECG shows left bundle branch block, for which paramedics gave aspirin and glyceryl trinitrate spray. He is sweating and distressed. His pulse is 85 bpm, BP 99/54 mmHg, respiratory rate 22 breaths per minute and oxygen saturation 96% breathing air. His GCS score is 15/15

What is the most appropriate management?

A. Continue breathing air
B. Start 28% oxygen via a Venturi mask
C. Start 40% oxygen via a Venturi mask
D. Start oxygen 2 L/min via nasal cannulae
E. Start oxygen 15 L/min via a non-rebreathe mask

**Answer**: A

**Explanation**: Airway is patent and does not require intervention. Oxygen will increase mortality for STEMI with sats of >94% (BMJ Nov 2018), so is no longer routinely offered - https://cks.nice.org.uk/topics/chest- pain/management/management/ August 2022.

---
### 180. Question 180
A 25 year old man has taken an overdose of 16 paracetamol tablets. He became very sad earlier that day after an argument with a friend. His mood changes between being happy and sad several times per week. He struggles with concentration and gets angry easily. He has frequently been excessively drunk on nights out. He has never experienced psychotic symptoms

What is the most likely diagnosis?

A. Adjustment disorder
B. Bipolar disorder
C. Borderline personality disorder
D. Dissocial personality disorder
E. Unipolar depressive episode

**Answer**: C

**Explanation**: Frequent changes in mood suggests borderline PD, not pervasive depression. Mood changes too rapid for bipolar disorder. Also impulsive self-destructive behaviours and unstable relationships are classical symptoms.

---
### 181. Question 181
A 52 year old woman has a brief episode of dizziness on standing. She has had 4 days of dysuria, loin pain and fever. She has been feeling tired for 4 months and has lost 3 kg in weight. Her temperature is 37.4°C, pulse 90 bpm, BP 100/55 mmHg lying and 90/50 mmHg sitting, respiratory rate 18 breaths per minute and oxygen saturation 95% breathing air. Her JVP is not visible

**Investigations:**
Haemoglobin 106 g/L (115–150) White cell count 14 × 109/L (3.8–10.0) Platelets 201 × 109/L (150–400) Sodium 130 mmol/L (135–146) Potassium 5.6 mmol/L (3.5–5.3) Urea 9.5 mmol/L (2.5–7.8) Creatinine 98 µmol/L (60–120) Random plasma glucose 3.2 mmol/L 12-lead ECG: sinus rhythm

What is the most appropriate additional investigation?

A. CT of head
B. CT pulmonary angiography
C. Echocardiography
D. Plasma cortisol and adrenocorticotropic hormone
E. Urinary and serum osmolality

**Answer**: D

**Explanation**: Classic presentation of adrenal crisis. Nearly all patients have a history of lethargy and weight loss. Plasma cortisol and ACTH should be sent immediately so that definitive treatment can be initiated. Hypotension more likely to be due to adrenal insufficiency than cardiac disease. Urine and plasma osmolality is not required as there is more likely cause for hyponatraemia.

---
### 182. Question 182
A 39 year old woman with metastatic lung cancer has 24 hours of back pain at the L1 level. She has also developed leg weakness and urinary retention

What is the most appropriate investigation?

A. CT of spine
B. Isotope bone scan
C. MR imaging of spine
D. PET–CT
E. X-ray of thoracic and lumbar spine

**Answer**: C

**Explanation**: Clinical cord compression needs MR. Malignant cord compression is often multifocal so whole spine required.

---
### 183. Question 183
A 75 year old woman has breathlessness on exertion and a cough productive of white sputum throughout the day. She has never had haemoptysis. She has lost 2kg in weight . She has had two chest infections in the past year treated with a short course of steroids and antibiotics. She has a 15 pack-year smoking history. Her heart rate is 82bpm

**Investigations:**
Chest X-ray is normal.

What is the most appropriate diagnostic investigation?

A. Cardiopulmonary exercise test
B. Echocardiography
C. High resolution CT scan of thorax
D. Spirometry
E. Sputum cytology

**Answer**: D

**Explanation**: COPD is the most likely diagnosis and basic spirometry most appropriate.

---
### 184. Question 184
A 32 year old man has 60 minutes of palpitations that started during a night out dancing with friends. This is associated with chest pain and shortness of breath

**Investigations:**
ECG (see image)

[IMAGE: image_184_MLA4_page40_image_40_2.png]

Which diagnosis is shown on the ECG?

A. Atrial fibrillation
B. First degree heart block
C. Sinus tachycardia
D. Supraventricular tachycardia
E. Ventricular tachycardia

**Answer**: D

**Explanation**: The ECG shows a narrow complex tachycardia at 190/minute consistent with a supraventricular tachycardia.

---
### 185. Question 185
A 82 year old woman is oliguric 8 hours after an emergency sigmoid colectomy for a perforated diverticulum. She has chronic kidney disease stage 3, peripheral vascular disease and type 2 diabetes mellitus. She takes metformin and ramipril. Her pulse is 110 bpm, BP 94/60 mmHg and JVP not visible. Her urine output has been 10 mL per hour for the past 4 hours. She has been given 2 L of Hartmann's solution since returning from theatre

**Investigations:**
Urea 14.9 mmol/L (2.5–7.8) Creatinine 188 µmol/L (60–120)

What is the most likely cause of her oliguria?

A. Acute tubular necrosis
B. Catheter obstruction
C. Intraoperative ureteric injury
D. Prerenal hypovolaemia
E. Renal artery occlusion

**Answer**: D

**Explanation**: The patient continues to show signs of hypovolaemia so a pre- renal cause for the oliguria is most likely. ATN usually takes longer to develop and would need to ensure adequate fluid resuscitation. Ureteric injury is unlikely and would need to be bilateral to cause AKI. Catheter blockage would cause anuria. Renal artery occlusion is rare and would cause loin pain and more severe clinical picture.

---
### 186. Question 186
A 39 year old man is brought to the emergency department having hit his head on a tree trunk when he lost control of his bicycle. He has a minor scalp abrasion. His GCS is 15/15 and there are no focal neurological signs. Seven hours later he collapses, at which point his GCS is 6/15. A CT scan of brain reveals a lens-shaped haemorrhage in the right parietal region

What is the most likely vessel to be injured?

A. Anterior communicating artery
B. Basilar artery
C. Bridging veins
D. Middle meningeal artery
E. Vertebral artery

**Answer**: D

**Explanation**: The middle meningeal sits beneath temporal bone and is fragile.

---
### 187. Question 187
A 68 year old woman has worsening chest discomfort over 11 days. She has a dry cough and has lost 3 kg in weight over the last 2 months. She is a non- smoker. She retired as a builder 15 years ago. She has a temperature of 37.1°C. Both lung fields sound clear. Her chest X-ray is shown (see image)

[IMAGE: image_187_MLA4_page43_image_43_2.png]

What is the most likely underlying diagnosis?

A. Mesothelioma
B. Metastatic cancer
C. Pulmonary fibrosis
D. Pulmonary tuberculosis
E. Sarcoidosis

**Answer**: B

**Explanation**: Chest X-ray shows multiple nodules, making metastatic cancer most likely, even in a retired builder.

---
### 188. Question 188
Researchers compare the diagnostic accuracy of a new serological test for SARS-Cov-2 against the nose and throat swab currently being used for clinical diagnosis in the UK. The new test detects all 23 confirmed cases of the disease that were positive by the current test. 92% (230/250) of patients who tested negative with the current test are also negative by the new rapid diagnostic test

Which statement is correct?

A. The false negative rate of the new test is 0%
B. The false positive rate of the new test is 92%
C. The sensitivity of the new test is 92%
D. The specificity of the new test is 8%
E. The specificity of the new test is 100%

**Answer**: A

**Explanation**: All those who had the condition according to the old (gold standard) test, so there were no false negatives. There were 20 people who tested positive with the new test who didn't test positive in the old one - they would be considered false positives, which is not relevant for this question, and doesn't need to be calculated.

---
### 189. Question 189
A 24 year old man has 12 hours of a severe headache of sudden onset. When the headache started, he lost consciousness briefly and vomited; he also reports photophobia. He has severe hypertension. Neurological examination is normal. A non-contrast CT scan of brain is normal

What is the most appropriate next step in management?

A. Carotid Doppler studies
B. Lumbar puncture
C. MR scan of brain
D. MR imaging of brain with MR venography
E. No future investigations required

**Answer**: B

**Explanation**: This is a case of a possible subarachnoid haemorrhage. A normal CT brain scan does not rule out haemorrhage although the earlier it is done the more likely it is that haemorrhage will be detected on the scan. When the CT is unhelpful a lumbar puncture should be performed to look for presence of xanthochromia (haem breakdown products).

---
### 190. Question 190
A 33 year old man has 6 months of an itchy, well demarcated rash that has partially responded to topical moisturiser. There are lesions symmetrically distributed over the extensor surface of his elbows, scalp and back, which are 2–10 cm in diameter (see image)

[IMAGE: image_190_MLA4_page46_image_46_2.png]

What is the most likely diagnosis?

A. Atopic dermatitis
B. Pityriasis versicolor
C. Plaque psoriasis
D. Seborrhoeic dermatitis
E. Tinea corporis infection

**Answer**: C

**Explanation**: The image shows typical well demarcated red, scaly patches on the back of the patient. This is typical of plaque psoriasis which is characterised by well demarcated red, scaly patches classically affecting the extensor surfaces, sacrum and scalp.

---
### 191. Question 191
A 21 year old woman has recurrent pulsating frontal headaches lasting up to 2 days, associated with nausea. The headache is usually preceded by numbness that starts in the hand, travels up the arm and then involves the face, lips and tongue. These headaches cause her to take time off work up to four times each month

What is the most appropriate treatment to reduce the frequency of these episodes?

A. Acupuncture
B. Gabapentin
C. Propranolol
D. Sumatriptan
E. Venlafaxine

**Answer**: C

**Explanation**: These are migraine headaches, and standard treatment for prophylaxis is a beta blocker, such as propanolol. Sumatriptan is only useful during a migraine. Gabapentin should not be prescribed for migraine prophylaxis. Acupuncture does not have a sufficient evidence base to have a role in prophylaxis. Clinical guideline [CG150] June 2025 https://www.nice.org.uk/guidance/cg150/chapter/Recommendations

---
### 192. Question 192
A 60 year old man has increasing fatigue. He has noticed intermittent difficulty swallowing, usually in the evening. He has hypothyroidism and takes levothyroxine. He smokes. There is bilateral mild ptosis. Neurological examination is otherwise normal

What is the most likely diagnosis?

A. Guillain–Barré syndrome
B. Migraine
C. Multiple sclerosis
D. Myasthenia gravis
E. Stroke

**Answer**: D

**Explanation**: he symptoms of increasing fatigue, intermittent difficulty swallowing (especially in the evening), and bilateral mild ptosis are classic presentations of myasthenia gravis.

---
### 193. Question 193
Six students living in the same hall of residence have developed diarrhoea and vomiting within 48 hours of each other. There is no blood in the stool, they have not eaten similar foods and have no history of foreign travel. A doctor requests stool samples from each to confirm the likely diagnosis

What test is most likely to confirm the diagnosis?

A. Clostridium difficile enzyme assay and toxin detection
B. Faecal elastase test
C. Stool for culture and sensitivity
D. Stool for viral PCR
E. Stool microscopy for ova, cysts and parasites

**Answer**: D

**Explanation**: This sounds most likely to be norovirus, for which PCR is the current method for testing.

---
### 194. Question 194
A 58 year old woman has 6 months of worsening right-sided hip pain caused by osteoarthritis. Her pain is partially controlled by regular ibuprofen gel. She remains active. She has peptic ulcer disease and heart failure. She takes bisoprolol fumarate, aspirin and simvastatin. She has crepitus on active and passive movements of both hips. Her BMI is 30 kg/m2

What is the most appropriate management?

A. Add paracetamol as required
B. Add regular celecoxib
C. Add regular oral ibuprofen and lansoprazole
D. Refer for acupuncture
E. Refer for hip replacement surgery

**Answer**: A

**Explanation**: Due to risk factors this patient, paracetamol or weak opioids can be considered for the management of osteoarthritis given it is only used infrequently for short-term pain relief and other pharmacological treatments are contraindicated, not tolerated or ineffective. NICE guideline [NG226] Published: 19 October 2022 https://www.nice.org.uk/guidance/ng226/chapter/Recommendations

---

### 195. Question 195
A 52 year old woman has a right-sided wide local excision and sentinel lymph node biopsy for a 25-mm invasive oestrogen-receptor-positive breast cancer. There are clear surgical margins. Three sentinel lymph nodes are removed and all contain metastatic cancer

What is the most appropriate next management step?

A. Adjuvant chemotherapy
B. Axillary node clearance
C. CT scan of chest, abdomen and pelvis
D. Mastectomy
E. Tamoxifen

**Answer**: B

**Explanation**: Seeking the awareness that SNB is diagnostic not therapeutic if 3 nodes are involved. Therefore more surgery is needed.

---
### 196. Question 196
A 53 year old woman has had a non-productive cough for 3 months. She has felt fatigued and has gained weight around her face and abdomen. She is an ex-smoker with a 30 pack year smoking history. She has multiple purple, wide striae on her abdomen. She has bruising on her arms. Her BP is 179/100 mmHg

**Investigations:**
CT scan of chest: 3 cm lesion in the left lung apex

What is the most likely histological diagnosis?

A. Adenocarcinoma
B. Sarcoidosis
C. Small cell carcinoma
D. Squamous cell carcinoma
E. Tuberculosis

**Answer**: C

**Explanation**: The patient’s presentation is consistent with Cushing’s syndrome, given the symptoms of weight gain around the face and abdomen, the purple and wide striae, bruising, and hypertension. When Cushing’ s syndrome is caused by a lung tumour, it is usually due to the ectopic production of adrenocorticotropic hormone (ACTH) by the tumour. Given the combination of a 30 pack year smoking history, a small lesion in the left lung on the CT scan, and a presentation consistent with ectopic ACTH production (Cushing’s syndrome), the most likely histological diagnosis is small cell carcinoma

---
### 197. Question 197
A 65 year old man has left leg claudication at 100 metres due to left superficial femoral artery stenosis. His ankle brachial pressure index (ABPI) is 0.84. He has been given lifestyle advice

What is the most appropriate additional initial management?

A. Above knee femoral-popliteal reversed vein bypass graft
B. Balloon angioplasty
C. Below knee femoral-popliteal bypass graft
D. Commence vasodilator medication
E. Supervised exercise programme

**Answer**: E

**Explanation**: All patients with claudication should be offered a structured exercise programme before considering angioplasty, surgical intervention or vasodilator therapy. Intervention by surgery or angioplasty would only be considered if the patient has followed a structured exercise programme without a satisfactory improvement in their symptoms. Vasodilator therapy is only considered if the exercise programme has failed to improve the symptoms satisfactorily and the patient prefers not to be considered for angioplasty or bypass surgery. https://www.nice.org.uk/guidance/cg147/chapter/recommendations#managem ent-of-intermittent-claudication

---
### 198. Question 198
A 41 year old man is admitted with an acute myocardial infarction. His father died of a myocardial infarction aged 52 years

**Investigations:**
Fasting glucose 8.2 mmol/L (3.0–6.0) Cholesterol (fasting) 9.2 mmol/L (3.5–6.5) Triglycerides (fasting) 1.9 mmol/L (<2.3) HDL cholesterol 1.0 mmol/L (>1.2)

What is the most likely cause of his hyperlipidaemia?

A. Chylomicronaemia
B. Diabetes mellitus
C. Familial combined hyperlipidaemia
D. Heterozygous familial hypercholesterolaemia
E. Polygenic hypercholesterolaemia

**Answer**: D

**Explanation**: This is because the commonest genetic lipid disorder listed which would give this profile.

---
### 199. Question 199
A 6 year old boy has mild abdominal pain, a non blanching rash on his lower extremities (see image) and arthralgia. He had an upper respiratory tract infection two weeks ago and has now recovered. His temperature is 36.8ºC, pulse 95 (80–120) bpm, BP 110/72 (97–115/57– 76) mmHg, respiratory rate 23 (20–25) breaths per minute and oxygen saturation 96% breathing air

**Investigations:**
Urinalysis: protein 2+

[IMAGE: image_199_MLA5_page6_image_6_2.png]

What is the most likely diagnosis?

A. Acute lymphoblastic leukaemia
B. IgA vasculitis
C. Immune thrombocytopenic purpura
D. Meningococcal septicaemia
E. Post streptococcal glomerulonephritis

**Answer**: B

**Explanation**: The most likely diagnosis is IgA vasculitis, also known as Henoch-Schönlein purpura (HSP). IgA vasculitis is a systemic vasculitis characterized by IgA immune complex deposition in small blood vessels, resulting in inflammation and damage primarily affecting the skin, joints, gastrointestinal tract, and kidneys. The non-blanching rash (palpable purpura), arthralgia, abdominal pain and recent upper respiratory tract infection, is classic for IgA vasculitis. Additionally, the presence of proteinuria on urinalysis suggests renal involvement, which is common in HSP. He is well and apyrexial, reducing the likelihood of meningococcal septicaemia. Post streptococcal glomerulonephritis does not present with a rash. Immune thrombocytopenic purpura does not present with abdominal pain and proteinuria. This would be a very rare presentation of ALL

---
### 200. Question 200
A 2 year old girl has four weeks of a smelly discharge from her left nostril, sometimes tinged with blood. More recently, she has had a persistent sneeze. She is normally fit and well. She has mucoid discharge in her left nostril

What is the most likely diagnosis?

A. Allergic rhinitis
B. Foreign body
C. Sinusitis
D. Unilateral choanal atresia
E. Unilateral nasal polyp

**Answer**: B

**Explanation**: The most likely diagnosis is foreign body. Children, especially toddlers, are prone to inserting foreign objects into their nostrils out of curiosity, which can lead to chronic nasal discharge and irritation. The presence of mucoid discharge suggests an inflammatory response to the foreign body. Unilateral choanal atresia is rare and normally discharge is odourless. Nasal polyps are rare in children. Sinusitis might be accompanied by symptoms such as headache and facial pain. The most likely reason for a unilateral smelly discharge is a foreign body even in the absence of history of foreign body insertion.

---
### 201. Question 201
A 2 day old boy with trisomy 21 develops recurrent vomiting. The vomit is green in colour. He feeds eagerly but vomits forcefully soon after every feed. His abdomen is slightly distended, but soft. His anus is patent

What is the most likely cause of the vomiting?

A. Duodenal atresia
B. Gastro-oesophageal reflux
C. Hirschsprung disease
D. Midgut volvulus
E. Pyloric stenosis

**Answer**: A

**Explanation**: The most likely cause is duodenal atresia. Duodenal atresia is the commonest cause of upper GI obstruction in children with trisomy 21/Down syndrome and involves a complete obstruction or narrowing of the duodenal lumen. This leads to the accumulation of gastric contents and bile, which are then forcefully expelled through vomiting. The characteristic green colour of the vomit is due to the presence of bile and implies obstruction beyond ampulla of Vater.

---
### 202. Question 202
A 34 year old woman has a recurrent itchy rash which lasts for several hours before resolving (see image). She has not identified any triggers. She is systemically well. She is a firefighter and says that she does not want any treatments that may affect her level of alertness

[IMAGE: image_202_MLA5_page9_image_9_2.png]

What is the most appropriate treatment to control her symptoms?

A. Oral chlorphenamine maleate
B. Oral loratadine
C. Oral prednisolone
D. Topical aqueous cream
E. Topical hydrocortisone

**Answer**: B

**Explanation**: The image shows urticarial weals. Initial treatment for this should be a non-sedating H1-antihistamine. The correct answer is thus B (oral loratadine). Chlorphenamine maleate is a sedating antihistamine, which is more likely to cause adverse effects; this patient also specifically requested treatment that would not affect her level of alertness. Prednisolone is effective for severe, acute urticaria but should not be used first-line. Aqueous cream is a soap substitute and has no role in the management of urticaria. Topical corticosteroids are ineffective for urticaria so hydrocortisone is not indicated here. Urticaria | Health topics A to Z | CKS | NICE

---
### 203. Question 203
A 33 year old man has 1 month of bilateral ankle pain and a rash on his shins. He feels generally lethargic and has lost 1 kg in weight. His temperature is 37.2°C. He has swelling in both ankles and several tender round lesions on both shins. His chest is clear.

**Investigations:**
Calcium 2.75 mmol/L (2.2–26) CRP 28 mg/L (<5)

What additional investigation is most likely to help confirm the diagnosis?

A. Chest X-ray
B. CT scan of abdomen and pelvis
C. Serum ACE
D. Serum parathyroid hormone
E. Serum protein electrophoresis

**Answer**: A

**Explanation**: There is no definitive diagnostic investigation for probable sarcoid. The clinical picture fits and the next step would be to obtain radiological evidence of hilar adenopathy which will be present is ~50% of cases. Serum ACE may be elevated but has a high false negative and false positive rates. CT scan abdomen and pelvis is not indicated. Serum PTH will be suppressed but this will not help identify the cause. The serum protein electrophoresis would exclude myeloma but patient is too young for this to be probable.

---
### 204. Question 204
A 55 year old woman has had a left parotid swelling for 30 years. Over the past 3 months the swelling has increased in size from 3 cm to 5 cm. She had fine needle aspiration of the lump 6 years ago but she declined surgery at that time. She has no pain, but there is slight facial weakness. There are no other abnormalities on examination of the head and neck

What is the most likely explanation of the recent enlargement?

A. Parotid adenoma
B. Parotid carcinoma
C. Parotid lymphoma
D. Reactive lymphadenopathy
E. Stone in the parotid duct

**Answer**: B

**Explanation**: This is because this is a classic history of malignant transformation in a pleomorphic salivary adenoma.

---
### 205. Question 205
A 63 year old man has 9 weeks of hoarse voice and 2 months of cough. He smokes 20 cigarettes per day and drinks 25 units of alcohol per week. His symptoms have not responded to oral amoxicillin. His temperature is 37.2°C, pulse 80 bpm, respiratory rate 16 breaths per minute and oxygen saturation 95% breathing air. His chest is clear. There are no palpable neck lumps. Oral cavity appearance is normal

**Investigations:**
Chest X-ray (4 weeks ago): normal

What is the most appropriate next step in management?

A. CT scan of chest
B. MR imaging of head and neck
C. Repeat chest X-ray
D. Spirometry
E. Urgent ENT referral

**Answer**: E

**Explanation**: NICE guidance suggests that a suspected cancer pathway referral for laryngeal cancer (appointment within 2 weeks) should be considered in people aged 45 and over with persistent unexplained hoarseness or an unexplained lump in the neck. This patient fits the criteria, and the most likely diagnosis is laryngeal cancer given presentation, age and risk factors (smoking, alcohol consumption). Source: NICE Clinical Knowledge Summaries: Head and neck cancers - recognition and referral (2015)

---
### 206. Question 206
A 48 year old woman develops nausea and abdominal pain 2 days after a total abdominal hysterectomy. Her pulse is 110 bpm and BP 80/40mmHg. Her abdomen is distended and tender. Her urine output for the past 6 hours has been 100 mL. The on-call surgical doctor has been contacted

What is the most appropriate immediate management?

A. Blood transfusion
B. Intravenous 0.9% sodium chloride
C. Intravenous adrenaline / epinephrine
D. Intravenous morphine
E. Urethral catheterisation

**Answer**: B

**Explanation**: This is a post-operative bleed. IV fluids should be commenced and the surgeon should be called immediately. A-E assessment and treatment.

---
### 207. Question 207
A 28 year old man has sudden onset right-sided chest pain and dyspnoea. His oxygen saturation is 98% breathing air

**Investigations:**
Chest X-ray: Right pneumothorax with a 4 cm rim of air measured at the hilum. There is no mediastinal shift.

What is the most appropriate initial management?

A. Admit for observation
B. Arrange CT scan of chest
C. Insert a chest drain with underwater seal and suction
D. Perform aspiration
E. Refer to thoracic surgeons for urgent pleurodesis

**Answer**: D

**Explanation**: Primary pneumothorax >2cm or with symptoms can be treated with aspiration or an ambulatory device if available. Secondary pneumothorax would require chest drain for pneumothorax greater than 2cm.

---
### 208. Question 208
A 45 year old woman has 3 months of weight loss, dizziness, nausea and lethargy. She has a BP of 100/70 mmHg lying and 75/50 mmHg standing

**Investigations:**
Sodium 125 mmol/L (135–146) Potassium 6.1 mmol/L (3.5–5.3) Urea 8.5 mmol/L (2.5–7.8) Creatinine 100 µmol/L (60–120)

What is the most likely diagnosis?

A. Addison disease
B. Congenital adrenal hyperplasia
C. Conn syndrome
D. Cushing syndrome
E. Hypopituitarism

**Answer**: A

---
### 209. Question 209
A 59 year old man has had 6 months of difficulty getting an erection. He has had numbness in his feet and intermittent dizziness when he stands up for the last year. He has type 2 diabetes mellitus and had a thyroidectomy 2 years ago for thyrotoxicosis. He takes aspirin, atorvastatin, insulin and levothyroxine. His BP is 140/90 mmHg lying and 110/80 mmHg standing. His peripheral pulses are all palpable

What is the most likely cause of his erectile dysfunction?

A. Autonomic neuropathy
B. Benign prostatic enlargement
C. Drug side effects
D. Hypothyroidism
E. Vascular disease

**Answer**: A

**Explanation**: Diabetes mellitus causing an autonomic neuropathy is the most likely cause of erectile dysfunction.

---
### 210. Question 210
A 60 year old man has had persistent dull lower back pain for 3 months. He was previously a keen hill walker, but is now breathless walking on the flat. His BP is 152/82 mmHg. He is tender over his lumbar vertebrae. His urinalysis is normal.

**Investigations:**
Haemoglobin 90 g/L (130-175) White cell count 3.2 x 109/L (3.0-10.0) Platelets 70 x 109/L (150-400) Creatinine 190 µmol/L (60-120) Adjusted calcium 2.8 mmol/L (2.2-26) Albumin 35 g/L (35-50) Total protein 92 g/L (60-80) Chest X-ray: normal X-ray of lumbar spine: generalised osteopenia, multi-level vertebral collapse

What initial investigation is most likely to help establish the diagnosis?

A. Plasma parathyroid hormone
B. Serum prostate specific antigen
C. Serum protein electrophoresis
D. Serum vitamin D
E. Thyroid function tests

**Answer**: C

**Explanation**: The clinical presentation strongly suggests multiple myeloma. One of the key diagnostic tests for multiple myeloma is the serum protein electrophoresis, which is used to detect the presence of abnormal proteins (monoclonal proteins or M proteins) in the blood. These abnormal proteins are produced by the malignant plasma cells in the bone marrow.

---
### 211. Question 211
A 91 year old woman has a small skin lesion on her left cheek that has been gradually increasing in size over the past year (see image). She has advanced vascular dementia and ischaemic heart disease. She lives in a nursing home and no longer recognises her daughter, who visits regularly and is her next-of-kin. She is unable to hold a conversation about her health. The nursing manager of the nursing home requests an opinion from the GP

[IMAGE: image_211_MLA5_page18_image_18_2.png]

What is the most appropriate next step in management?

A. Discuss the diagnosis with the patient's daughter
B. No further action
C. Prescribe a topical steroid
D. Refer urgently to dermatology clinic
E. Removal of lesion by GP under local anaesthetic

**Answer**: A

**Explanation**: This is a basal cell carcinoma. At the age of 91 years there is a reasonable case for no further action (slow-growing non-metastasising lesion) or for excision under local anaesthetic. The decision-making should involve the daughter.

---
### 212. Question 212
A 70 year old man has felt tired for 6 months. He has hypertension and open angle glaucoma. He takes amlodipine, latanoprost eye drops, ramipril, simvastatin and timolol eye drops. His pulse rate is 46 bpm and regular. Examination is otherwise normal

Which drug is the most likely cause of the clinical findings?

A. Amlodipine
B. Latanoprost
C. Ramipril
D. Simvastatin
E. Timolol

**Answer**: E

**Explanation**: Timolol maleate, as a Beta blocker, may cause bradycardia and tiredness. The other options are not likely to have these adverse effects.

---
### 213. Question 213
A 45 year old man thinks that he is dead and that he does not exist. He says that he feels miserable most of the time. His wife left him for another man 5 months ago. He has increased his alcohol intake over 4 months to three pints of lager every day. He also occasionally smokes cannabis. He has lost 7 kg in weight over 3 months

What is the most likely psychiatric diagnosis?

A. Alcohol-induced psychosis
B. Delusional disorder
C. Depressive episode with psychotic symptoms
D. Psychosis secondary to illicit drug use
E. Schizophrenia

**Answer**: C

**Explanation**: The most likely psychiatric diagnosis is depressive episode with psychotic symptoms. His belief that he is dead and non-existent, coupled with feeling miserable most of the time, suggests distorted perception, characteristic of psychotic symptoms. Moreover, his recent stressful life event - his wife leaving him - could contribute to the development of depressive symptoms. While substance use may exacerbate psychotic symptoms, the primary presentation aligns more closely with depressive episodes, evidenced by significant weight loss and persistent low mood.

---
### 214. Question 214
A 23 year old man attends his GP with 2 months of low mood, lack of pleasure, persistent tiredness, poor sleep, poor appetite and low self-esteem. He sometimes has thoughts of taking his life, with no specific plans. There is no past psychiatric history. The GP diagnoses depression and starts an antidepressant

What is the most appropriate follow-up?

A. Admit to psychiatric unit
B. GP review in 1 month
C. GP review in 1 week
D. Referral to a community psychiatric nurse
E. Referral to a psychiatrist

**Answer**: C

**Explanation**: Depression is not severe/treatment-resistant enough for psychiatry teams to take this case. If antidepressants are started in a patient who is suicidal, they should be followed up in a week. (NICE guidance) https://cks.nice.org.uk/topics/depression/management/initial- management/#:~:text=The%20NICE%20guideline%20advises%20early,early%2 0stages%20of%20antidepressant%20treatment.

---
### 215. Question 215
A 25 year old woman has recurrent episodes of sudden onset of excessive sweating, dry mouth, 'butterflies' in her stomach, difficulty breathing and a fear that she is going to die. These symptoms have been occurring twice weekly for the past two years

What is the most likely diagnosis?

A. Dissociative disorder
B. Generalised anxiety disorder
C. Hypochondriasis
D. Panic disorder
E. Somatisation disorder

**Answer**: D

**Explanation**: The most likely diagnosis is Panic Disorder. Panic Disorder is characterised by the presence of recurrent panic attacks, which are sudden and intense periods of fear or discomfort that reach a peak within minutes. Her symptoms, including palpitations, sweating, and difficulty breathing, are typical features of panic attacks. The duration and frequency of her episodes occurring twice weekly for the past two years, are consistent with the diagnostic criteria for Panic Disorder.

---
### 216. Question 216
A 75 year old woman has low back and pelvic pain made worse by walking. She has weakness of hip flexion bilaterally

**Investigations:**
Haemoglobin 137 g/L (115–150) Calcium 2.0 mmol/L (2.2–2.6) Phosphate 0.75 mmol/L (0.8–1.5) Alkaline phosphatase 250 IU/L (25–115) CRP <5 mg/L (<5)

What is the most likely diagnosis?

A. Fibromyalgia
B. Osteomalacia
C. Paget's disease of the bone
D. Polymyositis
E. Spinal stenosis

**Answer**: B

**Explanation**: Back and pelvic pain is a common presenting symptom of osteomalacia. The changes in calcium, phosphate and Alkaline phosphatase are classical of osteomalacia and no changes would be seen in fibromyalgia or spinal stenosis. The CRP would be elevated in polymyositis. Paget’s disease of the bone would give an elevated alkaline but would not explain hypocalcaemia or proximal muscle weakness.

---
### 217. Question 217
A 75 year old woman has 6 weeks of painless muscle weakness affecting her shoulders and thighs. She has a pale mauve discolouration of her eyelids, diffuse erythema over the metacarpophalangeal joints dorsally, and reduced power (3/5) in arm abduction and hip flexion

**Investigations:**
CRP 70 mg/L (<5) Rheumatoid factor negative Antinuclear antibody 1:320 (<1:20)

What is the most appropriate blood test to help establish the diagnosis?

A. Anti-acetylcholine receptor antibodies
B. Anti-neutrophil cytoplasmic antibodies
C. Anti-smooth muscle antibodies
D. Creatine kinase
E. Erythrocyte sedimentation rate

**Answer**: D

**Explanation**: The presentation of the 75-year-old woman with painless muscle weakness affecting her shoulders and thighs, the described skin findings (mauve discoloration of the eyelids, which is characteristic of heliotrope rash, and erythema over the metacarpophalangeal joints dorsally, known as Gottron’s papules or sign), and the clinical findings of muscle weakness are consistent with dermatomyositis. Creatine kinase (CK) is a muscle enzyme that is often elevated in inflammatory myopathies, including dermatomyositis. An elevation in CK can help confirm muscle inflammation and damage.

---
### 218. Question 218
A 69 year old man has 3 months of stiffness in both knees at the end of the day. He also has intermittent, sharp pain in his left knee that occurs when he is walking or playing tennis. The pain resolves with rest. He has hypertension and takes lisinopril. There is reduced range of movement in both knees. His left knee has crepitus, a small effusion and tenderness to palpation along the joint line. His BMI is 28 kg/m2

**Investigations:**
Creatinine 77 µmol/L (60–120) He is given advice on weight loss and exercise.

What is the most appropriate additional treatment?

A. Oral chondroitin sulfate
B. Oral co-codamol
C. Oral hydroxychloroquine sulfate
D. Topical capsaicin
E. Topical ibuprofen

**Answer**: E

**Explanation**: These are typical clinical features of OA. If pharmacological treatments are needed to manage osteoarthritis, it should be used alongside non-pharmacological treatments and to support therapeutic exercise. For patients with knee osteoarthritis a topical non-steroidal anti-inflammatory drug (NSAID) should be offered first line. NICE guideline [NG226] Published: 19 October 2022 https://www.nice.org.uk/guidance/ng226/chapter/Recommendations

---
### 219. Question 219
A 70 year old man has a sharp stabbing pain in his jaw and cheek that lasts for seconds. He reports that the pain is triggered when brushing his teeth, cold wind and touching his face

What is the most appropriate treatment?

A. Carbamazepine
B. Indometacin
C. Morphine
D. Prednisolone
E. Pregabalin

**Answer**: A

**Explanation**: The symptoms described suggest the diagnosis of trigeminal neuralgia. Carbamazepine is the first-line treatment for this condition and is therefore the most appropriate option among the choices givhttps://cks.nice.org.uk/topics/trigeminal-neuralgia/en Clinical guideline [CG173] Published: 20 November 2013 Last updated: 22 September 2020 https://www.nice.org.uk/guidance/cg173/chapter/Recommendations

---
### 220. Question 220
A 79 year old man has difficulty breathing. He had a carotid endarterectomy 2 hours ago. His pulse is 120 bpm, BP 92/52 mmHg and oxygen saturation 97% breathing high-flow oxygen by mask. His neck is swollen and he appears anxious and distressed, with loud stridor

What is the most likely explanation for his deterioration?

A. Acute superior vena caval obstruction
B. Anaphylactic reaction
C. False aneurysm between carotid artery and jugular vein
D. Haemorrhage compressing the airway
E. Surgical emphysema

**Answer**: D

**Explanation**: This is a known complication of carotid endarterectomy. Primary haemorrhage causes airway obstruction.

---
### 221. Question 221
A 53 year old woman has 4 months of lower abdominal pain and bloating. She has no urinary or bowel symptoms. She has normal periods with a regular cycle. Her abdomen is distended, but there is no tenderness or masses on palpation

**Investigations:**
CA125 50 U/mL (<35).

What is the most appropriate initial radiological investigation to perform?

A. CT scan of abdomen and pelvis
B. Hysterosalpingogram
C. MR scan of abdomen and pelvis
D. Ultrasound scan of abdomen and pelvis
E. X-ray of abdomen

**Explanation**: The most appropriate initial radiological investigation for a woman presenting with lower abdominal pain and bloating, especially when there's a raised CA125, is an ultrasound scan of the abdomen and pelvis. Ultrasound scan of the abdomen and pelvis (Option D) is an initial investigation to look for ovarian cysts, tumors, fibroids, and other pelvic pathologies. It's non-invasive and does not use ionizing radiation, making it a safe first-line modality for assessing pelvic pathology. If the ultrasound findings are inconclusive or suggest a malignant pathology, further imaging like CT or MRI may be warranted. Clinical guideline [CG122] Published: 27 April 2011 Last updated: 02 October 2023 https://www.nice.org.uk/guidance/cg122/chapter/Recommendations

---
### 222. Question 222
A 17 year old girl has delayed menarche and short stature. She has had recurrent ear infections as a child. Her height is below the 5th centile for her age. She has a broad chest and widely spaced nipples

**Investigations:**
FSH 70 U/L (2–8) LH 40 U/L (1–11)

What investigation is most likely to confirm the underlying diagnosis?

A. Karyotyping
B. MR scan of pituitary fossa
C. Serum oestradiol
D. Thyroid function tests
E. Ultrasound scan of pelvis

**Answer**: A

**Explanation**: The clinical picture provided suggests Turner syndrome. The characteristic findings include delayed menarche, short stature, recurrent ear infections, broad chest with widely spaced nipples, and elevated FSH and LH levels due to gonadal dysgenesis. The definitive diagnostic test for Turner syndrome is a chromosomal analysis by karyotyping.

---
### 223. Question 223
A 32 year old woman has had amenorrhoea for 6 months. Before this, she had a normal menstrual cycle. Her menarche was at age 14 years. Her BMI is 18.5 kg/m2

**Investigations:**
FSH 30 U/L (2-8) LH 20 U/L (1-11) These results were confirmed 1 month later.

What is the most likely explanation for these findings?

A. Anorexia nervosa
B. Hypogonadotrophic hypogonadism
C. Polycystic ovarian syndrome
D. Pregnancy
E. Premature ovarian failure

**Answer**: E

**Explanation**: The most likely explanation is premature ovarian failure (POF). POF refers to the cessation of ovarian function before the age of 40, leading to amenorrhoea and infertility. Elevated FSH and LH levels indicate indicates loss of negative feedback from ovarian steroids, and therefore decreased ovarian reserve and diminished ovarian function. The woman’s age, history of normal menstrual cycles, and BMI within normal range are consistent with the diagnosis of premature ovarian failure.

---
### 224. Question 224
A 28 year old man has had a painful red eye for five days. He has redness around the border of the sclera and cornea and the eye is watery. Fluorescein staining is normal. The pupil is irregular

What is the most likely diagnosis?

A. Acute closed angle glaucoma
B. Acute conjunctivitis
C. Anterior uveitis
D. Corneal abrasion
E. Dendritic ulcer

**Answer**: C

**Explanation**: None of the others cause an irregular pupil, the cornea is clear unlike glaucoma, abrasion and dendritic ulcer https://cks.nice.org.uk/topics/uveitis/diagnosis/assessment/

---
### 225. Question 225
A 72 year old man has three episodes of painless visual loss in his right eye over a two week period. Each episode lasts 20–30 minutes. The symptoms affect his right eye only. He has hypertension, hyperlipidaemia and ischaemic heart disease

Which artery is most likely to be affected causing his presentation?

A. Basilar artery
B. Left internal carotid artery
C. Left posterior cerebral artery
D. Right internal carotid artery
E. Right posterior cerebral artery

**Answer**: D

**Explanation**: The patient’s symptoms of transient painless visual loss in one eye, lasting 20-30 minutes, are suggestive of transient monocular blindness, also known as amaurosis fugax. Amaurosis fugax is often due to emboli from atherosclerotic plaques in the carotid artery. These emboli typically originate from the ipsilateral internal carotid artery. Since the symptoms are in the right eye, it is likely due to a lesion in the right internal carotid artery.

---
### 226. Question 226
An 80 year man has worsening nausea and occasional vomiting. He has advanced Parkinson's disease and takes levodopa. He also takes codeine for muscle pain along with lactulose. His BP is 140/85 mmHg. His abdomen is soft with normal bowel sounds

What is the most appropriate treatment of his nausea and vomiting?

A. Add domperidone
B. Add oral haloperidol
C. Add oral metoclopramide
D. Increase dose of levodopa
E. Switch codeine to tramadol

**Answer**: A

**Explanation**: Nausea and vomiting is a common symptom in PD patients requiring palliation. It is a result of levodopa and exacerbated by opiates in this case. Haloperidol and metoclopramide should be avoided due to their anti- dopaminergic activity. Domperidone is a safe anti-emetic which works on peripheral dopamine receptors. There is no indication to change the levodopa dose. Changing to a weaker opiate is likely to make pain worse without any benefit on nausea symptoms. https://cks.nice.org.uk/topics/parkinsons-disease/management/confirmed- parkinsons-disease/

---
### 227. Question 227
A 30 year old woman has 3 weeks of bilateral loin pain and dark urine. This was preceded by a sore throat. She had a similar less severe episode 2 years ago. Her temperature is 37.1°C, pulse 80 bpm, BP 153/90 mmHg and JVP + 3 cm above the sternal angle. She has ankle oedema. Heart sounds are normal and chest is clear. Urinalysis shows blood 3+, protein 3+

**Investigations:**
Sodium 136 mmol/L (135–146) Potassium 4.8 mmol/L (3.5–5.3) Urea 18 mmol/L (2.5–7.8) Creatinine 250 µmol/L (60–120) Anti-neutrophil cytoplasmic antibody is negative Urinary albumin:creatinine ratio 192.2 mg/mmol (<3.5) Midstream urine: no growth Ultrasound scan of kidneys: normal sized unobstructed kidneys

What is the most appropriate diagnostic investigation?

A. CT scan of kidneys, ureters and bladder
B. Cystoscopy
C. MR renal angiography
D. Renal biopsy
E. Serum protein electrophoresis

**Answer**: D

**Explanation**: Renal biopsy is required for diagnosis and appropriate treatment. Although the patient has haematuria the picture is not one of bladder pathology. This is unlikely to be stones so a helical CT scan is not indicated. Renal artery stenosis would be uncommon in this age group and would not explain symptoms and signs. Although serum protein electrophoresis would be done this presentation does not fit with myeloma.

---
### 228. Question 228
A 61 year old woman is admitted with acute kidney injury. She has cervical carcinoma, which has recently been treated with radiotherapy. She takes tramadol and paracetamol. Her temperature is 37.2°C, pulse 84 bpm, BP 124/80 mmHg and JVP is +2 cm from the sternal angle

**Investigations:**
Haemoglobin 98 g/L (115–150) White cell count 12 x 109/L (3.8–10.0) Platelets 188 x 109/L (150–400) Sodium 132 mmol/L (135–146) Potassium 5.6 mmol/L (3.5–5.3) Urea 36 mmol/L (2.5–7.8) Creatinine 592 µmol/L (60–120) Ultrasound scan of renal tract: bilateral hydronephrosis with good cortical thickness. A urinary catheter is inserted that drains 50 mL of urine. Urinalysis shows blood 1+.

What is the most appropriate next management step?

A. CT scan of kidney, ureter and bladder
B. Intravenous 0.9% sodium chloride 500 mL
C. Intravenous co-amoxiclav
D. Intravenous insulin and glucose
E. Nephrostomy insertion

**Answer**: E

**Explanation**: The patient’s presentation and investigations indicate acute kidney injury (AKI) with raised creatinine, urea, and hyperkalemia (elevated potassium). The ultrasound shows bilateral hydronephrosis, suggesting an obstructive cause for the AKI. Given her history of cervical carcinoma and radiotherapy, one likely cause for this obstruction could be related to the treatment causing ureteric obstruction. This might have led to post-renal AKI. In this situation, the most appropriate management is to relieve the obstruction. Inserting a nephrostomy (percutaneous renal drainage) will help to bypass the obstruction and allow urine to drain externally. Once the obstruction is relieved, renal function can start to improve.

---
### 229. Question 229
A 58 year old man has had 8 months of fatigue. He often has a brief sleep at work due to tiredness. His pulse is 83 bpm and BP is 159/68 mmHg. His heart sounds are normal and his chest is clear. His BMI is 34 kg/m2.

**Investigations:**
Haemoglobin 182 g/L (130-180) MCV 87 fL (80-96) White cell count 9.1 x 109/L (4.0-11.0) Thyroid stimulating hormone 3.0 pmol/L (0.4-50)

What investigation is most likely to establish the diagnosis?

A. 24 hour urinary cortisol
B. Bone marrow aspiration
C. Echocardiography
D. Polysomnography
E. Serum free T4 and T3

**Answer**: D

**Explanation**: The clinical features of daytime somnolence and obesity suggest obstructive sleep apnoea. Hypertension commonly occurs. There are no other features to suggest he has Cushing’s. The normal TSH excludes hypothyroidism. The polycythaemia is likely a result of nocturnal hypoxia rather than PRV. https://www.nice.org.uk/guidance/ng202

---
### 230. Question 230
In 2019, a study was started in which two groups of women (N = 1000 in total) who had surgery for breast cancer were followed up. The women were treated at two different oncology centres. One centre treated women with drug A, and the other with drug B. All women were assessed for recurrence in 2023

What study design is described here?

A. Case control
B. Cross-sectional
C. Prospective cohort
D. Randomised control trial
E. Retrospective cohort

**Answer**: C

**Explanation**: Given that the study started before the outcome (recurrence) occurred and followed the groups forward in time, it is a cohort study. The study isn't randomized, as the treatment seems to be based on the unit where they were treated and not by random allocation. Given that they started the study in 2019 (prospectively) and followed the participants to 2023 to assess for the outcome, the correct answer is a prospective cohort.

---
### 231. Question 231
In a randomised controlled trial of a new influenza vaccine, 100 patients were randomly allocated to receive the vaccine and 100 to receive placebo. During follow up, 20 patients who had received the vaccine contracted influenza, compared with 30 patients who had received placebo

What effect did the vaccine have on the relative risk of contracting influenza?

A. Decreased by 10%
B. Decreased by 33%
C. Decreased by 67%
D. Increased by 10%
E. Increased by 50%

**Answer**: B

**Explanation**: RR = (20/100)/(30/100) = 0.67, which implies a 33% reduction in risk.

---
### 232. Question 232
A 50 year old man has had 2 months of abdominal and mid-thoracic back pain, diarrhoea and occasional nausea and vomiting. He has lost 5 kg in weight during that time

**Investigations:**
Haemoglobin 135 g/L (130–175) White cell count 4.2 × 109/L (3.8–10.0) Alkaline phosphatase 254 IU/L (25–115) Bilirubin 28 µmol/L (<17) Ultrasound scan of abdomen: no abnormality

What is the most appropriate next diagnostic imaging?

A. Colonoscopy
B. CT scan of abdomen
C. Endoscopic retrograde cholangiopancreatography
D. Upper gastrointestinal endoscopy
E. X-ray of abdomen

**Answer**: B

**Explanation**: This patient presents with mid-thoracic back pain, abdominal pain, gastrointestinal symptoms (diarrhoea, nausea, and vomiting), weight loss, elevated alkaline phosphatase, and elevated bilirubin. The combination of elevated alkaline phosphatase and bilirubin often suggests a hepatobiliary pathology. A CT scan of the abdomen would be the next most appropriate diagnostic imaging in this setting. This test can evaluate the liver, pancreas, and biliary tree in greater detail than an ultrasound. It can identify masses, stones, or other obstructions that may not have been evident on ultrasound. Furthermore, CT can visualize the entire abdomen and retroperitoneal structures, which may help explain the patient's back pain and identify any other potential pathologies. Scenario: Referral for suspected gastrointestinal tract (upper) cancer Last revised in February 2021 https://cks.nice.org.uk/topics/gastrointestinal-tract-upper-cancers-recognition- referral/management/referral-for-suspected-gastrointestinal-tract-upper- cancer/

---
### 233. Question 233
A 40 year old man has a temperature of 38.5ºC. He is receiving cytotoxic chemotherapy for the treatment of acute myeloid leukaemia. His Hickman (central venous) line site is red and tender

**Investigations:**
White cell count of 0.1 x 109/L (3.0–10.0) Blood cultures from both the Hickman line and peripheral blood yield clumps of Gram positive cocci.

What is the most likely causative organism?

A. Enterococcus faecalis
B. Escherichia coli
C. Micrococcus species
D. Staphylococcus aureus
E. Streptococcus pyogenes

**Answer**: D

**Explanation**: This is because streptococcus pyogenes and enterococcus faecalis are gram positive cocci but in chains. Staphylococcus aureus causes line infections. E. coli is gram negative. Micrococcus species is much less likely.

---
### 234. Question 234
A 72 year old man has a persistent limp 6 weeks after a hip replacement. He has a positive Trendelenburg test

Which hip muscle group is most likely to be affected?

A. Abductors
B. Adductors
C. Extensors
D. External rotators
E. Flexors

**Answer**: A

**Explanation**: The purpose of the Trendelenburg Test is to identify the weakness of the hip abductors. A positive Trendelenburg sign usually indicates weakness in the hip abductor muscles: gluteus medius and gluteus minimus.

---
### 235. Question 235
A 24 year old woman has 1 week of watery diarrhoea and abdominal cramping. She is a keen swimmer and there has been a recent outbreak of diarrhoeal disease amongst her swimming club. She is otherwise well. A stool sample shows oocysts of cryptosporidium

What is the most appropriate management?

A. Arrange for flexible sigmoidoscopy
B. Lactose-free diet
C. No therapy required
D. Oral ciprofloxacin
E. Oral clarithromycin

**Answer**: C

**Explanation**: Self limiting illness typically and no treatment is needed. https://www.cdc.gov/cryptosporidium/treatment/index.html#:~:text=Cryptospor idiosis%20can%20be%20managed%20by,recover%20from%20cryptosporidiosi s%20without%20treatment.

---
### 236. Question 236
A 59 year old woman attends her GP for a monitoring blood test. She has type 2 diabetes mellitus and hypertension. She takes bendroflumethiazide, metformin, nifedipine, ramipril and simvastatin.

**Investigations:**
Sodium 139 mmol/L (135–146) Potassium 3.9 mmol/L (3.5–5.3) Urea 6.2 mmol/L (2.5–7.8) Creatinine 109 µmol/L (60–120) Calcium 2.73 mmol/L (2.2–2.6)

Which of her medications is most likely to contribute to these results?

A. Bendroflumethiazide
B. Metformin
C. Nifedipine
D. Ramipril
E. Simvastatin

**Answer**: A

**Explanation**: Bendroflumethiazide increases renal calcium absorption which may lead to low level hypercalcaemia. The first action would be stop it and repeat the calcium.

---
### 237. Question 237
A 72 year old woman is admitted after collapsing at home and falling down several stairs. Her pulse is 55 bpm and irregular, and her BP is 165/88 mmHg. Her ECG is shown (see image)

[IMAGE: image_237_MLA5_page44_image_44_2.png]

What is the best interpretation of the ECG?

A. Atrial fibrillation
B. Complete heart block
C. First degree heart block
D. Second degree heart block
E. Sinus arrhythmia

**Answer**: D

**Explanation**: ECG shows second degree heart block (Wenkebach / Mobitz type 1). While not always a sign of pathological heart disease, in an older person with symptoms, this is most likely. It is generally asymptomatic but if patient bradycardic, dizziness and syncope can occur.

---
### 238. Question 238
A 54 year old man attends his GP after he was found to have high BP at a routine medical examination at work. He is well and is not on any regular medication. His friend checked his BP at home and said it was normal. His BP is checked twice and found to be 146/102 mmHg and 148/98 mmHg

What is the most appropriate next step?

A. Arrange ambulatory BP monitoring
B. Arrange repeat BP measurement in 2 weeks
C. Prescribe a calcium-channel blocker
D. Prescribe an ACE inhibitor
E. Reassure patient that if his BP was normal when his friend measured it, no

**Answer**: A

**Explanation**: If clinic blood pressure is between 140/90 mmHg and 180/120 mmHg, ambulatory blood pressure monitoring (ABPM) to confirm the diagnosis of hypertension should be offered. NICE guideline [NG136] Published: 28 August 2019 Last updated: 21 November 2023 https://www.nice.org.uk/guidance/ng136/chapter/Recommendations

---
### 239. Question 239
A 78 year old woman has a chest infection which is slow to clear despite several courses of broad spectrum oral antibiotics

**Investigations:**
Haemoglobin 126 g/L (115 – 150) White cell count 38 x 109/L (3.8–10.0) Lymphocytes 32 x 109/L (1.1–3.3) Platelets 124 x 109/L (150 – 400) A large cervical lymph node is biopsied and shows a sheet of mainly small lymphoid cells with 5% larger cells.

What is the most likely diagnosis?

A. Chronic lymphocytic leukaemia
B. Myeloma
C. Non-Hodgkin lymphoma
D. Small cell lung carcinoma
E. Tuberculosis

**Answer**: A

**Explanation**: Patient has CLL with accumulation of non-functioning monoclonal with typical findings of lymphocytosis and lymphadenopathy. CLL diagnosed as high lymphocyte count in peripheral blood count. small lymphocytic lymphoma is considered to be the same disease but with different manifestation but is nodal and by definition has a peripheral lymphocyte count <5 x 109/L.

---
### 240. Question 240
A 30 year old woman is admitted with 10 days of fever, rigors, breathlessness and back pain. She has a history of intravenous drug use. She is known to be hepatitis C IgG positive. Her temperature is 40.1°C, pulse rate 114 bpm, BP 111/65 mmHg and oxygen saturation 96% breathing air. She has a systolic murmur at the left sternal edge. Her chest is clear. She has tenderness over the L1 to L3 vertebrae

**Investigations:**
Haemoglobin 96 g/L (115–150) White cell count 10.9 × 109/L (3.8–10.0) Platelets 406 × 109/L (150–400) Urea 10.5 mmol/L (2.5–7.8) Creatinine 71 μmol/L (60–120) Aspartate aminotransferase 42 IU/L (10–40) Alkaline phosphatase 310 IU/L (25–115) Urinalysis: blood 1+, protein 3+

What is the most likely diagnosis?

A. Acute exacerbation of hepatitis C infection
B. Infective endocarditis
C. Opioid withdrawal
D. Pneumocystis jirovecii pneumonia
E. Pyelonephritis

**Answer**: B

---
### 241. Question 241
A 68 year old man has worsening breathlessness on exertion. He takes a salbutamol inhaler as required. He has a 40 pack-year smoking history and stopped smoking completely 3 months ago. His oxygen saturation breathing air is 96%

**Investigations:**
Spirometry: Pre-bronchodilator FEV1/FVC ratio: 0.63 Post-bronchodilator FEV1/FVC ratio: 0.64 Chest X-Ray: mild hyperinflation, heart-size normal, no focal lesion

What is the most appropriate next step in the management?

A. Add beclometasone with formoterol and glycopyrronium (Trimbow) inhaler
B. Add budesonide with formoterol (Symbicort) inhaler
C. Add fluticasone inhaler
D. Add ipratropium nebuliser
E. Add umeclidinium with vilanterol (Anoro Ellipta) inhaler

**Answer**: E

**Explanation**: This patient has confirmed COPD based on spirometry with no asthmatic features or steroid responsiveness. The most appropriate next step is to add a combination long-acting muscarinic antagonist (LAMA) and long- acting beta-agonist (LABA) inhaler, such as umeclidinium with vilanterol (Anoro Ellipta). Symbicort (ICS + LABA) is preferred for patients with asthmatic features and steroid responsiveness. Trimbow (ICS + LABA + LAMA) is generally recommended for patients who experience frequent exacerbations despite dual therapy with a LAMA and LABA. No indication for a nebuliser rather than an inhaler. NICE guideline [NG115] Published: 05 December 2018 Last updated: 26 July 2019 https://www.nice.org.uk/guidance/ng115/chapter/Recommendations Consistent with NICE CKS May 2025

---
### 242. Question 242
A 68 year old man had an angioplasty of his left femoral artery 3 days ago. He has hypertension, chronic kidney disease, type 2 diabetes mellitus and peripheral arterial disease. He takes aspirin, metformin and ramipril. Metformin and ramipril were stopped before the procedure. His temperature is 37.4ºC, pulse is 80 bpm and BP is 146/80 mmHg. His urine output for the past 24 hours is 900 mL

**Investigations:**
Pre-angiogram 3 days post angiogram Sodium 137 mmol/L 134 mmol/L (135–146) Potassium 5.2 mmol/L 5.6 mmol/l (3.5–5.3) Urea 8.2 mmol/L 14.5 mmol/L (2.5–7.8) Creatinine 134 µmol/L 210 µmol/L (60–120)

What is the most likely cause for the decline in his renal function?

A. Cholesterol emboli
B. Contrast associated acute kidney injury
C. Diabetic nephropathy
D. Renal artery stenosis
E. Urinary tract infection

**Answer**: B

**Explanation**: In this scenario the timing suggests contrast associated acute kidney injury. This is more common is patients with pre-existing CKD. Cholesterol emboli would not enter the kidneys from femoral angiography. Diabetic nephropathy would not cause an acute decline in function.

---

### 243. Question 243
A 52 year old woman has been experiencing hot flushes and vaginal dryness. She has not had a menstrual period for the past 6 months. There is no relevant family history and she has had no other medical problems. She had a cone biopsy for early cervical intra-epithelial neoplasia 10 years ago. Her symptoms are intolerable to her and she would like to have hormone replacement therapy (HRT)

What is the most appropriate management?

A. Continuous combined oestrogen and progestogen HRT
B. Cyclical combined oestrogen and progestogen HRT
C. HRT is contra-indicated
D. Oestrogen only HRT
E. Topical oestrogen (vaginal)

**Answer**: B

**Explanation**: The most appropriate management is cyclical combined oestrogen and progestogen hormone replacement therapy (HRT). Cyclical combined HRT involves the sequential administration of both oestrogen and progestogen, which helps prevent endometrial hyperplasia and reduces the risk of uterine cancer in women with an intact uterus. By combining oestrogen and progestogen, cyclical HRT manages menopausal symptoms while minimising potential risks associated with unopposed oestrogen therapy. NICE guideline [NG23] Published: 12 November 2015 Last updated: 07 November 2024 https://www.nice.org.uk/guidance/ng23/chapter/Recommendations

---
### 244. Question 244
A 72 year old man is confused. His wife reports that on several occasions in recent weeks he has forgotten to meet friends with whom he has made arrangements. He has also not passed on messages that have been given to him. He recently went for a walk and phoned his wife in an agitated state to say that he was lost. She reports the confusion has gradually worsened over several months. He takes simvastatin for primary heart disease prevention. He has no symptoms of an acute illness. There are no focal neurological findings

What is the most appropriate class of drug therapy to slow the progression of his symptoms?

A. 5-Hydroxytryptamine (5-HT) antagonist
B. Acetylcholinesterase inhibitor
C. Dopamine agonist
D. Gamma aminobutyric acid (GABA) inhibitor
E. Serotonin reuptake inhibitor

**Answer**: B

**Explanation**: The most appropriate class of drug therapy to recommend is acetylcholinesterase inhibitors. Given the progressive nature of his symptoms and the absence of focal neurological findings, the most likely diagnosis is Alzheimer's disease. Acetylcholinesterase inhibitors work by increasing the availability of acetylcholine in the brain and are commonly used in the management of Alzheimer disease and other types of dementia. While they do not cure dementia, they may help improve cognitive function and slow the progression of symptoms in some patients. NICE guideline [NG97] Published: 20 June 2018 https://www.nice.org.uk/guidance/ng97/chapter/Recommendations

---
### 245. Question 245
A 17 year old girl has had heavy periods for the last year. They typically last 5–7 days and occur every 29 days. She passes clots as well as fresh blood. During a period she has to change her tampon eight times a day and sometimes requires a sanitary towel as well. Menarche occurred aged 13 years. She is sexually active and does not bleed after sex, or in between periods. Abdominal examination is normal

What is the most appropriate next investigation?

A. Endocervical and high vaginal swabs
B. Full blood count
C. Serum prolactin level
D. Thyroid function tests
E. Transvaginal and pelvic ultrasound scan

**Answer**: B

**Explanation**: The most appropriate next investigation is a full blood count (FBC). Heavy menstrual bleeding, or menorrhagia can cause anaemia due to chronic blood loss. A full blood count helps assess her haemoglobin levels and MCV. TFTs should only be checked if there are symptoms of a thyroid disorder. Imaging is only required if the uterus is palpable on abdominal examination.

---
### 246. Question 246
A 2 year old girl has four weeks of a smelly discharge from her left nostril, sometimes tinged with blood. More recently, she has had a persistent sneeze. She is normally fit and well. She has mucoid discharge in her left nostril

What is the most likely diagnosis?

A. Allergic rhinitis
B. Foreign body
C. Sinusitis
D. Unilateral choanal atresia
E. Unilateral nasal polyp

**Answer**: B

**Explanation**: The most likely diagnosis is foreign body. Children, especially toddlers, are prone to inserting foreign objects into their nostrils out of curiosity, which can lead to chronic nasal discharge and irritation. The presence of mucoid discharge suggests an inflammatory response to the foreign body. Unilateral choanal atresia is rare and normally discharge is odourless. Nasal polyps are rare in children. Sinusitis might be accompanied by symptoms such as headache and facial pain. The most likely reason for a unilateral smelly discharge is a foreign body even in the absence of history of foreign body insertion.

---
### 247. Question 247
A full term newborn boy is discharged home 48 hours after birth. The next day, his 2 year old sibling develops a florid chickenpox rash. His mother has detectable varicella antibodies. The newborn remains clinically well

What is the most appropriate management decision?

A. Admit for observation
B. Check the newborn's antibody status for varicella antibodies
C. No action is necessary
D. Treat with Aciclovir
E. Treat with zoster immune globulin

**Answer**: C

**Explanation**: The most appropriate management decision is no action is necessary. The newborn remains clinically well, and the mother has detectable varicella antibodies, indicating likely passive immunity transfer to the newborn. The fact that the newborn is clinically well also supports a conservative approach with no specific treatment or observation required.

---
### 248. Question 248
A 37 year old woman who is 10 weeks pregnant has experienced excessive vomiting for 1 week. The fundal height is consistent with 16 weeks' gestation. Her temperature is 37.2°C, pulse 100 bpm and BP 180/110 mmHg

What is the most likely diagnosis underlying the clinical presentation?

A. Gastroenteritis
B. Missed abortion
C. Molar pregnancy
D. Pre-eclampsia
E. Pregnancy-induced hypertension

**Answer**: C

**Explanation**: The most likely diagnosis is molar pregnancy. This is the classic presentation of molar pregnancy as the underlying diagnosis with large for gestation uterus and severe early onset pre-eclampsia as a secondary phenomenon. Molar pregnancy can present with exaggerated symptoms of pregnancy such as excessive vomiting and rapidly increasing uterine size due to the proliferation of abnormal trophoblastic tissue. Additionally, elevated blood pressure can occur as a result of gestational trophoblastic disease- induced hypertension. Missed abortion must be diagnosed with an ultrasound and Pregnancy Induced Hypertension occurs after 20/40. Gastroenteritis would have normal-low BP, not raised.

---
### 249. Question 249
A 38 year old woman notices fresh vaginal bleeding. She is 10 weeks pregnant, having conceived following in vitro fertilisation. She has been otherwise well. Her BP is 120/75 mmHg and pulse 70 bpm. She has mild suprapubic tenderness and her uterus is palpable in her abdomen. Vaginal examination reveals that the cervical os admits a finger

What is the most likely diagnosis?

A. Complete miscarriage
B. Ectopic pregnancy
C. Inevitable miscarriage
D. Missed miscarriage
E. Molar pregnancy

**Answer**: C

**Explanation**: The most likely diagnosis is inevitable miscarriage. Cervix is wide open, this suggests impending miscarriage of a multiple gestation. Miscarriages are more common with multiple pregnancy, and in vitro- fertilisation increases the likelihood of multiple pregnancy. The uterus is palpable even at 10 weeks suggests this may be the case. Inevitable miscarriage refers to an ongoing miscarriage where cervical dilation has already occurred, and vaginal bleeding is present. The combination of vaginal bleeding, cervical dilation, and palpable uterus suggests that the process of miscarriage is underway and cannot be prevented.

---
### 250. Question 250
A 35 year old woman has started to bleed heavily following a normal vaginal delivery and delivery of the placenta. She had gestational hypertension and was induced at 40 weeks' gestation

What is the most appropriate initial management?

A. Carboprost
B. Ergometrine
C. Oxytocin
D. Misoprostol
E. Tranexamic acid

**Answer**: C

**Explanation**: The most appropriate management for postpartum haemorrhage following delivery of the placenta in a woman with gestational hypertension is oxytocin, as it can help to contract the uterus and reduce bleeding. Carboprost, and misoprostol may also be used if oxytocin is ineffective, but they can cause adverse effects and should be used with caution. Ergometrine can exacerbate hypertension and is essentially contra-indicated in hypertension. Tranexamic acid may also be used as an adjunct therapy to help control bleeding, but it should not be used as the sole treatment. However, the specific management will depend on the severity of the bleeding and other clinical factors, and close monitoring of the patient is essential.

---
### 251. Question 251
A 69 year old woman attends her GP with constant dribbling of urine. She has had to wear pads continuously for the last 12 months. She had radiotherapy for carcinoma of the cervix when she was 48 years old. Her temperature is normal. Her bladder is not palpable or tender and neurological examination is normal

What is the most likely cause of her symptoms?

A. Detrusor overactivity
B. Neurogenic bladder
C. Stress incontinence
D. Urinary infection
E. Vesicovaginal fistula

**Answer**: E

**Explanation**: The most likely diagnosis is vesicovaginal fistula. Vesicovaginal fistula occurs when an abnormal connection forms between the bladder and the vagina, allowing urine to leak continuously into the vaginal vault. The history of radiotherapy increases the risk of tissue damage and subsequent fistula formation. The absence of fever, palpable or tender bladder, and normal neurological examination findings make other causes less likely.

---
### 252. Question 252
A 40 year old woman is admitted with a seizure. She is a primigravid woman, at 28 weeks' gestation. She had epigastric pain and blurred vision preceding the seizure. Her BP is 155/105 mmHg. Reflexes are brisk with two beats of ankle clonus. Her urinalysis shows protein 2+

What intravenous drug is the most appropriate immediate treatment?

A. Diazepam
B. Hydralazine
C. Levetiracetam
D. Magnesium sulfate
E. Phenytoin

**Answer**: D

**Explanation**: The most appropriate immediate treatment for this patient is magnesium sulfate. She is presenting with features of severe pre-eclampsia and eclampsia, which require urgent management to prevent maternal and foetal complications. Magnesium sulfate is the first-line treatment for preventing seizures in women with severe pre-eclampsia and eclampsia. Diazepam and phenytoin are not recommended for the prevention of seizures in pre-eclampsia/eclampsia. Hydralazine is a second-line agent for the control of hypertension, and levetiracetam is an antiepileptic drug that is not routinely used in the management of pre-eclampsia/eclampsia.

---
### 253. Question 253
A 3 year old girl has had a fever and a runny nose for 2 days. She is alert but miserable. Her temperature is 39.6°C, pulse 150 bpm (95 140), BP 105/62 mmHg (90/50-120/80), respiratory rate 36 breaths per minute (20-30) and oxygen saturation 97% in air. She has a red throat and looks flushed with a flat, erythematous rash across her trunk and face that feels rough. There is no rash around her mouth

What is the most likely diagnosis?

A. Kawasaki disease
B. Measles
C. Parvovirus infection
D. Rhinovirus infection
E. Scarlet fever

**Answer**: E

**Explanation**: The most likely diagnosis is scarlet fever. Scarlet fever is a bacterial infection caused by Group A Streptococcus. It typically presents with a high fever, sore throat, and a characteristic sandpaper-like rash that starts on the trunk and spreads to the extremities. The cheeks may look flushed with often a pale area around the mouth. Measles can cause fever and rash, but typically presents with a cough, runny nose, and red, watery eyes. Parvovirus infection can cause a rash, but it is typically milder and not associated with a fever. Kawasaki disease can also cause a fever and rash, but it usually presents with conjunctivitis, swollen lymph nodes, and redness and later peeling of the hands and feet. Rhinovirus infection can cause a runny nose, but is not typically associated with fever or rash.

---
### 254. Question 254
An 80 year old man has been shouting in the middle of the night for 5 days. He lives alone and has been telling his neighbours that he has seen people trying to steal from him, but there is no evidence for this. He has no past psychiatric history. He is partially sighted and deaf. He cannot sustain a conversation and there is disorganisation to his thoughts with distractibility

What is the most likely diagnosis?

A. Alzheimer dementia
B. Anxiety disorder
C. Delirium
D. Lewy body dementia
E. Schizophrenia

**Answer**: C

**Explanation**: The most likely diagnosis is delirium. Delirium is a common acute confusional state characterised by disturbances in attention, awareness, and cognition. The sudden onset of symptoms, including perceptual disturbances and disorganised thinking, coupled with the absence of prior psychiatric history, suggests an underlying medical or physiological cause. In this case, his age, sensory impairments, and acute onset of symptoms make delirium the most likely diagnosis.

---
### 255. Question 255
A 20 year old woman seeks contraceptive advice. She had unprotected sexual intercourse 4 days ago. Her last menstrual period was 16 days ago. She has a 28 day cycle. She has been using condoms reliably as her method of contraception until this incident

What is the most appropriate method of contraception?

A. Copper-containing intrauterine device
B. Ella-One® (ulipristal acetate postcoital contraception)
C. Intrauterine progestogen system (Mirena coil)
D. Levonelle® (levonorgestrel) postcoital contraception
E. Postcoital contraception not appropriate

**Answer**: A

**Explanation**: The most appropriate method of contraception after unprotected sexual intercourse is emergency contraception. The options for emergency contraception include the copper-containing intrauterine device (IUD) and emergency contraceptive pills. The copper containing IUD is highly effective up to 5 days post UPSI (nearly 100% effective) and is therefore the most appropriate option at this stage. COCP and high dose progestogens can also be used but are less effective. Depot and Mirena are not licenced for emergency contraception.

---
### 256. Question 256
A 6 month old baby vomited and developed an erythematous rash over her lips and chin, within minutes of being given formula milk for the first time. The rash took 1 hour to subside. The following week, the mother dripped a couple of drops of formula milk onto the baby's arm. The baby develops an erythematous rash over the arm within 1 minute of this. The mother is returning to work and does not wish to continue breastfeeding or expressing milk

What is the best management option?

A. Goat's milk formula
B. Hydrolysed formula
C. Lactose free formula
D. Latex free teat
E. Soya milk formula

**Answer**: B

**Explanation**: The best management option is hydrolysed formula. These symptoms suggest a potential allergic reaction to cow's milk protein, prompting the need for an alternative formula that is less allergenic. Hydrolysed formula contains proteins that are broken down into smaller fragments, making them less likely to trigger an allergic response compared to intact cow's milk protein. Goat's milk is not recommended for infants as it has similar protein structures to cow's milk and can cause similar allergic reactions. Lactose-free formula is not necessary unless the infant has a diagnosed lactose intolerance, which is rare in infants. A latex-free teat may be needed if the infant has a latex allergy, but this is not relevant in this case. Soya milk is not recommended for infants under 6 months of age, as it may also cause an allergic reaction and may contain phyto-oestrogens.

---
### 257. Question 257
A 28 year old woman is elated in mood. She has not slept for 7 days and has been attending all-night parties. She is sexually disinhibited and believes that she is a member of the royal family. She was previously fit and well and has no past psychiatric history. A urine drug screen is negative

What is the most appropriate medication to prescribe?

A. Diazepam
B. Lithium carbonate
C. Olanzapine
D. Sodium valproate
E. Zuclopenthixol decanoate

**Answer**: C

**Explanation**: In this context olanzapine would be appropriate as it would act as both antipsychotic and sedative medication. Diazepam and zuclopenthixol decanoate are not the treatments of choice for mania. Lithium carbonate is a standard treatment for bipolar disorder, but it may take several days to become effective and is not appropriate for the acute management of severe mania. Sodium valproate is not prescribed to women of child-bearing age. Valproate is highly teratogenic and evidence supports that use in pregnancy leads to neurodevelopmental disorders (approx. 30–40% risk) and congenital malformations (approx. 10% risk). Valproate must not be used in women and girls of childbearing potential unless the conditions of the Pregnancy Prevention Programme are met and only if other treatments are ineffective or not tolerated, as judged by an experienced specialist. Clinical guideline [CG185] Published: 24 September 2014 Last updated: 21 December 2023 https://www.nice.org.uk/guidance/cg185/chapter/Recommendations

---
### 258. Question 258
A 19 year old man develops painful muscle spasms in his neck. He has been an inpatient for 3 days on the psychiatric ward for treatment of psychosis. He has been taking haloperidol 5 mg orally twice daily since yesterday

What is the most appropriate immediate treatment?

A. Baclofen
B. Diazepam
C. L-dopa
D. Olanzapine
E. Procyclidine

**Answer**: E

**Explanation**: Dystonic reactions are common side effects of antipsychotic medications like haloperidol and typically manifest as involuntary muscle contractions, particularly in the neck region. These reactions are due to an imbalance between dopamine and acetylcholine levels in the substantia nigra caused by dopamine blockade. Anticholinergic agents, such as Procyclidine, help alleviate dystonic symptoms by blocking the excessive cholinergic activity thought to contribute to the muscle spasms.

---
### 259. Question 259
A 60 year old man believes that the government has been monitoring him for 10 years, despite him repeatedly writing to the Prime Minister to ask for this to stop. His beliefs are present whatever his mood. He has never heard voices when nobody else is around

What is the most likely diagnosis?

A. Anankastic personality disorder
B. Delusional disorder
C. Depression with psychosis
D. Paranoid schizophrenia
E. Schizoid personality disorder

**Answer**: B

**Explanation**: The most likely diagnosis is delusional disorder. The delusions have not escalated or changed for significant period and are considered to be "non-bizarre" i.e. situations that are not real but also not impossible. These beliefs began 10 years old so this is not a personality disorder as symptoms were not present since late adolescence. There are no other symptoms commonly seen in schizophrenia, such as hearing voices or experiencing disorganised speech and behaviour.

---
### 260. Question 260
A 32 year old woman has had amenorrhoea for 6 months. Before this, she had a normal menstrual cycle. Her menarche was at age 14 years. Her BMI is 18.5 kg/m2

**Investigations:**
FSH 30 U/L (2-8) LH 20 U/L (1-11) These results were confirmed 1 month later.

What is the most likely explanation for these findings?

A. Anorexia nervosa
B. Hypogonadotrophic hypogonadism
C. Polycystic ovarian syndrome
D. Pregnancy
E. Premature ovarian failure

**Answer**: E

**Explanation**: The most likely explanation is premature ovarian failure (POF). POF refers to the cessation of ovarian function before the age of 40, leading to amenorrhoea and infertility. Elevated FSH and LH levels indicate indicates loss of negative feedback from ovarian steroids, and therefore decreased ovarian reserve and diminished ovarian function. The woman's age, history of normal menstrual cycles, and BMI within normal range are consistent with the diagnosis of premature ovarian failure.

---
### 261. Question 261
A 2 day old boy with trisomy 21 develops recurrent vomiting. The vomit is green in colour. He feeds eagerly but vomits forcefully soon after every feed. His abdomen is slightly distended, but soft. His anus is patent

What is the most likely cause of the vomiting?

A. Duodenal atresia
B. Gastro-oesophageal reflux
C. Hirschsprung disease
D. Midgut volvulus
E. Pyloric stenosis

**Answer**: A

**Explanation**: The most likely cause is duodenal atresia. Duodenal atresia is the commonest cause of upper GI obstruction in children with trisomy 21/Down syndrome and involves a complete obstruction or narrowing of the duodenal lumen. This leads to the accumulation of gastric contents and bile, which are then forcefully expelled through vomiting. The characteristic green colour of the vomit is due to the presence of bile and implies obstruction beyond ampulla of Vater.

---
### 262. Question 262
The father of an 18 year old woman reports that she is socially isolated and anxious. She has recently dropped out of college. She has never been very sociable, has few friends and struggles to understand other people's feelings. She has always had difficulties expressing herself and often speaks to herself when alone. She has always struggled with changes in routine

What is the most likely diagnosis?

A. Anxious (avoidant) personality disorder
B. Autism spectrum disorder
C. Generalised anxiety disorder
D. Prodromal phase of schizophrenia
E. Social phobia

**Answer**: B

**Explanation**: The most likely diagnosis is Autism Spectrum Disorder (ASD). Her history of social isolation, anxiety, difficulty understanding others' feelings, limited social interactions, struggles with self-expression, and difficulty with changes in routines are characteristic features of ASD. The presence of repetitive behaviours, such as talking to herself when alone, further supports this diagnosis. Individuals with ASD often have challenges in social communication and interaction, as well as restricted and repetitive patterns of behaviour, interests, or activities.

---
### 263. Question 263
A 5 year old girl has a rash over her arms that has been gradually worsening over the past month. Her mother reports that she seems more tired than usual. She has a petechial rash over both forearms with some petechiae over her left anterior chest wall. She is pale and has hepatosplenomegaly

What is the most appropriate management option?

A. Full blood count and blood film and review within 48 hours
B. Intramuscular benzylpenicillin sodium and immediate ambulance
C. Oral prednisolone and review in 3 days
D. Routine general paediatrics outpatient appointment
E. Urgently referral to paediatric assessment unit

**Answer**: E

**Explanation**: The most appropriate management option is to refer her urgently to the paediatric assessment unit. The presence of a petechial rash, hepatosplenomegaly, and tiredness in a child should raise suspicion of a serious underlying condition, such as leukaemia or other haematological disorders. Urgent referral to the paediatric assessment unit is necessary to ensure prompt diagnosis and treatment. Intramuscular benzylpenicillin sodium is not appropriate in this case, as it is unlikely to address the underlying condition. Prednisolone is also not appropriate, as it is not indicated for the management of petechial rash and hepatosplenomegaly. Referral to a general paediatric clinic is not urgent enough, given the severity of the symptoms, and a full blood count and blood film should be taken urgently, but this should be done in the context of urgent referral to the paediatric assessment unit.

---
### 264. Question 264
A 6 hour old boy, born at term, is grunting and cyanosed. He has been struggling to feed. His temperature is 36.8°C, pulse 190 bpm (120-160), respiratory rate 60 breaths per minute (30-60) and oxygen saturation 82% breathing air. His oxygen saturation does not improve significantly breathing high flow oxygen. He has a loud single second heart sound and a systolic murmur. He is treated with intravenous fluids and antibiotics

What is the most appropriate next medication?

A. Alprostadil
B. Ibuprofen
C. Indomethacin
D. Sildenafil
E. Surfactant

**Answer**: A

**Explanation**: The most appropriate next medication is Alprostadil. These clinical findings are consistent with congenital heart disease. The loud single second heart sound and systolic murmur suggest a possible ventricular septal defect (VSD) or patent ductus arteriosus (PDA). The grunting and cyanosis, along with the low oxygen saturation that does not improve with high flow oxygen, suggest that the baby is experiencing significant respiratory distress. Alprostadil, a prostaglandin E1 analogue, helps maintain ductal patency and allows adequate systemic perfusion until definitive management, such as surgical correction or catheter-based intervention, can be undertaken. Ibuprofen and indomethacin are both nonsteroidal anti-inflammatory drugs that are used to treat patent ductus arteriosus, but they are not appropriate in this case as they would cause closure of the ductus arteriosus, exacerbating the baby's symptoms. Sildenafil is a medication used to treat pulmonary hypertension, which can occur in neonates with congenital heart defects, but it is not the most appropriate initial medication in this case. Surfactant is a medication used to treat respiratory distress syndrome, which is not the primary diagnosis in this case.

---
### 265. Question 265
A 3 year old boy has had diarrhoea for 6 months. He has 4-5 watery stools per day that contain visible pieces of sweetcorn and other vegetables. He is thriving and developing well

What is the most likely diagnosis?

A. Coeliac disease
B. Gastroenteritis
C. Inflammatory bowel disease
D. Lactose intolerance
E. Toddler diarrhoea

**Answer**: E

**Explanation**: The most likely diagnosis is toddler diarrhoea. Toddler diarrhoea is a common condition in children between 6 months and 5 years of age, characterised by chronic, non-bloody, watery diarrhoea with no signs of malabsorption or growth failure. It typically occurs during the daytime and is associated with the intake of large amounts of fruit juice, high-fibre foods, and other carbohydrates. It is usually self-limiting and resolves by the age of 5 years.

---
### 266. Question 266
A 28 year old primigravida attends the antenatal clinic at 35 weeks' gestation. She has 2 weeks of persistent itching of her palms, soles and abdomen. Her pregnancy has been uncomplicated to date, and she is feeling good foetal movements. She has red scratch marks on her abdomen with no rash

What is the most appropriate diagnostic investigation?

A. Anti-mitochondrial antibody
B. Iron studies
C. Liver function tests
D. Thyroid function tests
E. Urea and electrolytes

**Answer**: C

**Explanation**: The most appropriate investigation in this case is liver function tests. The persistent itching and scratch marks suggest obstetric cholestasis, a liver disorder that occurs in pregnancy. Liver function tests are important to assess the degree of hepatic dysfunction, and elevated serum bile acids would confirm the diagnosis. Other investigations such as anti-mitochondrial antibody, iron studies, thyroid function tests, and urea and electrolytes would not be helpful in diagnosing obstetric cholestasis.

---
### 267. Question 267
A 28 year old woman is admitted with a sudden onset of abdominal pain and vaginal bleeding. She is 38 weeks pregnant. Her pulse is 120 bpm and BP 110/80 mmHg. She has a tender abdomen. The fetal heart rate is 170 bpm

What is the most likely diagnosis?

A. Necrosis of a fibroid
B. Placenta praevia
C. Placental abruption
D. Pre-term labour
E. Uterine rupture

**Answer**: C

**Explanation**: The most likely diagnosis is placental abruption. Placental abruption occurs when the placenta separates prematurely from the uterine wall before delivery, leading to maternal and fetal complications including abdominal pain, vaginal bleeding, and fetal distress. The sudden onset of abdominal pain and vaginal bleeding along with the tender abdomen and tachycardia are suggestive of this diagnosis. The high fetal heart rate may indicate fetal distress. Prompt evaluation and management are necessary to optimise the chances of a successful outcome for both the mother and the baby.

---
### 268. Question 268
A 2 year old boy has had diarrhoea and vomiting, decreased food and fluid intake and fewer wet nappies for 3 days. He is unable to tolerate oral or nasogastric fluids. He is estimated clinically to be 5% dehydrated

**Investigations:**
Sodium 136 mmol/L (133–146) Potassium 4.5 mmol/L (3.5–5.0) Chloride 104 mmol/L (95–106) Bicarbonate 25 mmol/L (22–29) Urea 6.0 mmol/L (2.5–6.5) Creatinine 30 µmol/L (21–36) Blood glucose 4 mmol/L

What is the most appropriate intravenous fluid for maintenance of hydration?

A. 0.18% sodium chloride + 4% glucose
B. 0.45% sodium chloride + 5% glucose
C. 0.9% sodium chloride
D. 0.9% sodium chloride + 5% glucose
E. PlasmaLyte

**Answer**: D

**Explanation**: The most appropriate intravenous fluid is 0.9% sodium chloride + 5% glucose. This solution provides both electrolytes and glucose to replace ongoing losses and meet metabolic needs. The combination of sodium chloride and glucose helps maintain intravascular volume while providing energy substrate. Given the child's dehydration status and the need for both hydration and glucose supplementation, 0.9% sodium chloride + 5% glucose is the optimal choice for restoring and maintaining fluid balance. 0.18% sodium chloride + 4% glucose and 0.45% sodium chloride + 5% glucose solutions have lower sodium concentrations and may not adequately address the electrolyte needs for rehydration, especially in a child with ongoing losses and dehydration. While 0.9% sodium chloride is isotonic and suitable for replacing sodium and chloride losses, it lacks glucose, which is essential for providing energy substrate, especially in a child unable to tolerate oral intake. While PlasmaLyte is a balanced crystalloid solution containing electrolytes such as sodium, potassium, chloride, magnesium, and acetate, it also lacks glucose.

---
### 269. Question 269
A 23 year old woman has barricaded herself with her baby in the bathroom, shouting that it is unsafe to come out because the house is infected. She thinks that someone is trying to kill her and her baby. Her mood has not been low at any stage. She is four days post-caesarean section, and her physical recovery has been uncomplicated. She was not on any medication during her pregnancy. She drinks 20 units of alcohol a week. She is orientated in time and place

What is the most likely diagnosis?

A. Alcohol withdrawal
B. Delirium
C. Obsessive-compulsive disorder
D. Post-natal depression
E. Puerperal psychosis

**Answer**: E

**Explanation**: Puerperal psychosis is the most likely diagnosis in this case. Puerperal psychosis is a rare but serious mental illness that affects women in the days or weeks following childbirth. It typically presents with symptoms such as delusions, hallucinations, confusion, agitation, and a lack of insight into the illness. Risk factors include a personal or family history of mental illness, a difficult or traumatic childbirth, and lack of social support. Treatment often involves hospitalisation, medication, and support from mental health professionals. It is important to seek help quickly in order to provide the best possible outcome for both the mother and baby.

---
### 270. Question 270
A 25 year old woman has recurrent episodes of sudden onset of excessive sweating, dry mouth, 'butterflies' in her stomach, difficulty breathing and a fear that she is going to die. These symptoms have been occurring twice weekly for the past two years

What is the most likely diagnosis?

A. Dissociative disorder
B. Generalised anxiety disorder
C. Hypochondriasis
D. Panic disorder
E. Somatisation disorder

**Answer**: D

**Explanation**: The most likely diagnosis is Panic Disorder. Panic Disorder is characterised by the presence of recurrent panic attacks, which are sudden and intense periods of fear or discomfort that reach a peak within minutes. Her symptoms, including palpitations, sweating, and difficulty breathing, are typical features of panic attacks. The duration and frequency of her episodes occurring twice weekly for the past two years, are consistent with the diagnostic criteria for Panic Disorder.

---
### 271. Question 271
A 30 year old man says that he has never really felt happy. He has no friends and he prefers solitary activities. He has never wanted a sexual relationship. He describes feeling as if he has ‘always lived in a shell’. He works as an information technology specialist

What is the most likely diagnosis?

A. Anxious [avoidant] personality disorder
B. Dissocial personality disorder
C. Dysthymia
D. Schizoid personality disorder
E. Schizotypal disorder

**Answer**: D

**Explanation**: The most likely diagnosis is Schizoid Personality Disorder. Individuals with Schizoid Personality Disorder typically exhibit a pattern of detachment from social relationships and limited emotional expression. They often prefer solitary activities and have little interest in forming close interpersonal connections, which aligns with the man's description. His occupation as an information technology specialist also reflects a preference for tasks that involve minimal social interaction.

---
### 272. Question 272
A 29 year old woman has had intermittent vaginal bleeding since a levonorgestrel-releasing intrauterine system (Mirena® coil) was inserted 6 weeks ago

What is the most appropriate investigation?

A. Cervical smear
B. Colposcopy
C. High vaginal swab
D. No investigation required
E. Transvaginal pelvic ultrasonography

**Answer**: D

**Explanation**: Some bleeding is common after IUS insertion for up to six months. The levonorgestrel hormone in the device can cause changes to the uterine lining, leading to irregular bleeding patterns as the body adjusts to the new contraceptive method. Reassurance and patient education regarding the expected side effects are most appropriate in this case.

---
### 273. Question 273
A 28 year old woman has back pain. She is in the third trimester of pregnancy. She is advised that ibuprofen is contra-indicated

What potential complication can occur in the fetus with this medication?

A. Acute kidney injury
B. Liver failure
C. Premature closure of ductus arteriosus
D. Preterm labour
E. Reye syndrome

**Answer**: C

**Explanation**: In the third trimester of pregnancy, the use of ibuprofen is contraindicated due to its association with premature closure of the fetal ductus arteriosus. The ductus arteriosus is a blood vessel in the fetal heart that normally closes shortly after birth. However, during pregnancy, it allows blood to bypass the lungs since the fetus receives oxygen from the mother's blood. If ibuprofen is used in the third trimester, it can prematurely close the ductus arteriosus, leading to fetal complications such as pulmonary hypertension and heart failure.

---
### 274. Question 274
A 15 month old girl has been able to sit unsupported for 1 month. She has a vocabulary of 4 separate words and can build a tower of 2 blocks using a pincer grip. She was born at 30 weeks' gestation

What is the best description of her current developmental progress?

A. Fine motor delay
B. General developmental delay
C. Gross motor delay
D. Mild developmental delay
E. Normal development

**Answer**: C

**Explanation**: The best description of the development is gross motor delay. A child should be able to sit unsupported by 7 months of age; speak at least 2 words and feed themselves using fingers or build a tower of 2 bricks using a pincer grip by 12 months of age. The fact that she was born at 30 weeks' gestation i.e. 10 weeks premature, should be taken into consideration when assessing her development. Development may be delayed by approximately 10 weeks, but this does not explain the delay seen here. The delay is only in the sitting unsupported, which makes it gross motor delay.

---
### 275. Question 275
A 53 year old man has had 2 years of low mood, poor concentration and sleep. It is now affecting his job and interactions with family, and he has become socially reclusive. He had a myocardial infarction 2 years ago and has type 2 diabetes. He is referred for cognitive behavioural therapy, but also wishes to start medication

What is the most appropriate medication to prescribe?

A. Citalopram
B. Fluoxetine
C. Mirtazapine
D. Sertraline
E. Venlafaxine

**Answer**: D

**Explanation**: The most appropriate medication to prescribe is Sertraline. SSRIs are the first-line pharmacological treatment for depression due to their efficacy, safety profile, and tolerability. Sertraline is the recommended SSRI of choice in patients with established cardiac disease due to lack of effect on the QT interval and reduced drug interactions. Other non-pharmacological therapies should be trialled as well, depending on depression severity. NICE guideline [NG222] Published: 29 June 2022 https://www.nice.org.uk/guidance/ng222/chapter/Recommendations

---
### 276. Question 276
A 15 year old boy has had severe anorexia nervosa for one year. He is not acutely physically unwell. His weight is 75% of the expected weight for his height, age and sex

What is the most appropriate therapy?

A. Cognitive-analytic therapy
B. Cognitive-behaviour therapy
C. Family therapy
D. Non-directive counselling
E. Psychodynamic psychotherapy

**Answer**: C

**Explanation**: Family therapy is the first-line treatment for children and adolescents with anorexia nervosa, as it focusses on the family as a whole rather than just the individual with the disorder. It aims to improve family communication and functioning, and to help family members understand and support the individual's recovery. Other types of therapy, such as cognitive- behaviour therapy or psychodynamic psychotherapy, may be used in conjunction with family therapy to address specific symptoms or issues. https://cks.nice.org.uk/topics/eating-disorders/management/confirmed-eating- disorder/ (updated 2024)

---
### 277. Question 277
A 51 year old man with Down syndrome has 6 months of poor self-care, increased aggression and personality change. Recently, he has occasionally got lost on the way back from the local shop. His temperature is 36.5°C, pulse 85 bpm and BP 127/89 mmHg. Urinalysis is negative

What is the most likely diagnosis?

A. Alzheimer disease
B. Delirium
C. Depression
D. Hypothyroidism
E. Psychosis

**Answer**: A

**Explanation**: The most likely diagnosis is Alzheimer disease. Individuals with Down syndrome are at a significantly higher risk of developing Alzheimer disease at an earlier age compared to the general population. Cognitive decline, personality changes, and disorientation, are characteristic of the early stages of Alzheimer disease. The normal observations and negative urinalysis suggest that the symptoms are more likely due to a neurological disorder rather than an acute medical condition.

---
### 278. Question 278
A 45 year old man thinks that he is dead and that he does not exist. He says that he feels miserable most of the time. His wife left him for another man 5 months ago. He has increased his alcohol intake over 4 months to three pints of lager every day. He also occasionally smokes cannabis. He has lost 7 kg in weight over 3 months

What is the most likely psychiatric diagnosis?

A. Alcohol-induced psychosis
B. Delusional disorder
C. Depressive episode with psychotic symptoms
D. Psychosis secondary to illicit drug use
E. Schizophrenia

**Answer**: C

**Explanation**: The most likely psychiatric diagnosis is depressive episode with psychotic symptoms. His belief that he is dead and non-existent, coupled with feeling miserable most of the time, suggests distorted perception, characteristic of psychotic symptoms. Moreover, his recent stressful life event - his wife leaving him - could contribute to the development of depressive symptoms. While substance use may exacerbate psychotic symptoms, the primary presentation aligns more closely with depressive episodes, evidenced by significant weight loss and persistent low mood.

---
### 279. Question 279
A 35 year old man has a fear of spiders. He is a pub landlord and this interferes with his ability to work in the cellar. He recalls having been bitten by a spider aged 6 years when on holiday in Africa. He has no previous psychiatric history and is otherwise well

What is the most appropriate treatment?

A. Benzodiazepine
B. Cognitive behaviour therapy
C. Eye movement desensitisation and reprocessing
D. Psychoanalytic psychotherapy
E. Serotonin specific reuptake inhibitor

**Answer**: B

**Explanation**: The most appropriate treatment is Cognitive Behavioural Therapy (CBT). Arachnophobia, like other specific phobias, can significantly impact daily functioning and quality of life. CBT, particularly exposure therapy, involves gradual and controlled exposure to the feared stimulus in a safe environment. Through repeated exposure, the individual learns to confront and manage their fear reactions effectively. Given his otherwise well health and lack of prior psychiatric history, CBT offers a targeted and evidence-based approach to address his phobia and improve his ability to work in the cellar without undue distress. Prescription of potentially addictive benzodiazepines should be avoided. There is no evidence for the effectiveness of exploratory analytic therapy for phobias, even if the problem arose in childhood.

---
### 280. Question 280
A boy is born at 40 weeks' gestation with a male phenotype. At the newborn physical examination neither testis is palpable

What is the most likely diagnosis?

A. Androgen insensitivity syndrome
B. Excess in utero oestrogen exposure
C. Klinefelter syndrome
D. Physiological delay in descent
E. Retractile testes

**Answer**: D

**Explanation**: The most likely diagnosis is physiological delay in descent. In newborns, the testes may not be palpable at birth due to physiological delay in descent, which is a normal variation. During foetal development, the testes descend from the abdomen into the scrotum, but this process may take several weeks to months after birth to complete. Physiological delay in descent does not necessarily indicate an abnormality and typically resolves spontaneously as the baby grows. However, if neither testis is palpable, urgent investigation is indicated to exclude less common but significant alternative diagnoses.

---
### 281. Question 281
A 17 year old girl attends her GP with her mother. She has had severe headaches, stomach aches and has vomited four times over 2 days. She was invited to a close friend's birthday party but refused to attend. She is extremely shy and isolated, and has very few friends. She is always worried that others criticise her and is extremely sensitive to any rejection. She is also very attached to her mother

What personality disorder is most likely?

A. Avoidant
B. Dependent
C. Paranoid
D. Schizoid
E. Schizotypal

**Answer**: A

**Explanation**: The features described are consistent with avoidant personality disorder, which is characterised by social inhibition, feelings of inadequacy and hypersensitivity to criticism, and a strong desire for affection and acceptance. People with this disorder tend to avoid social situations and have few close relationships, often relying heavily on a single attachment figure. They may also experience physical symptoms such as headaches and stomach aches when faced with stress or anxiety-provoking situations.

---
### 282. Question 282
A 7 year old boy has been limping for the past 6 weeks but cannot remember any injury. His left leg is slightly painful when he runs but not at rest. He has not had any recent infection and is currently well. On examination, there is a decreased range of movement at the left hip but no other abnormal findings. He is Trendelenburg test positive and there is some gluteal wasting

What is the most likely diagnosis?

A. Osteomyelitis
B. Osteosarcoma
C. Perthes disease
D. Slipped upper femoral epiphysis
E. Transient synovitis

**Answer**: C

**Explanation**: The most likely diagnosis is Perthes disease. Perthes disease is a condition characterised by avascular necrosis of the femoral head, leading to hip joint pain, stiffness, and limited range of motion, especially during activity. Positive Trendelenburg test and gluteal wasting are common findings in Perthes disease due to weakness and dysfunction of the hip abductor muscles.

---
### 283. Question 283
A term newborn boy develops jaundice within 24 hours of birth. The total serum bilirubin is 130 mg/ dL, which requires phototherapy but not exchange transfusion. The baby's blood group is A positive

What test result would suggest early haemolytic jaundice?

A. Conjugated serum Bilirubin 9.7 mg/dL
B. Direct Coombs test negative
C. Glucose 6 phospate dehydrogenase (G6PD) enzyme normal
D. Maternal blood group O positive
E. Polycythaemia

**Answer**: D

**Explanation**: The test result that suggests early haemolytic jaundice, as maternal blood group is O positive. Maternal blood group O positive can lead to early haemolytic jaundice in newborns in the presence of anti-A and/or anti- B antibodies in the maternal circulation. Incompatibility between the maternal antibodies and the newborn's blood group antigens can result in haemolysis of the newborn's red blood cells, leading to an increase in serum bilirubin levels and the development of jaundice.

---
### 284. Question 284
A 6 year old boy has mild abdominal pain, a non blanching rash on his lower extremities (see image) and arthralgia. He had an upper respiratory tract infection two weeks ago and has now recovered. His temperature is 36.8ºC, pulse 95 (80–120) bpm, BP 110/72 (97–115/57 76) mmHg, respiratory rate 23 (20–25) breaths per minute and oxygen saturation 96% breathing air

**Investigations:**
Urinalysis: protein 2+

[IMAGE: image_284_MLA6_page43_image_43_2.png]

What is the most likely diagnosis?

A. Acute lymphoblastic leukaemia
B. IgA vasculitis
C. Immune thrombocytopenic purpura
D. Meningococcal septicaemia
E. Post streptococcal glomerulonephritis

**Answer**: B

**Explanation**: The most likely diagnosis is IgA vasculitis, also known as Henoch-Schönlein purpura (HSP). IgA vasculitis is a systemic vasculitis characterized by IgA immune complex deposition in small blood vessels, resulting in inflammation and damage primarily affecting the skin, joints, gastrointestinal tract, and kidneys. The non-blanching rash (palpable purpura), arthralgia, abdominal pain and recent upper respiratory tract infection, is classic for IgA vasculitis. Additionally, the presence of proteinuria on urinalysis suggests renal involvement, which is common in HSP. He is well and apyrexial, reducing the likelihood of meningococcal septicaemia. Post streptococcal glomerulonephritis does not present with a rash. Immune thrombocytopenic purpura does not present with abdominal pain and proteinuria. This would be a very rare presentation of ALL.

---
### 285. Question 285
A 6 year old boy's parents have noticed long-standing hearing difficulties. His teachers have commented on poor school performance and behaviour. His speech is normal and there is no otalgia. The ear canals are narrow with non-occluding wax

What is the most appropriate next step in management?

A. Aural olive oil drops
B. Grommet insertion
C. Pure tone audiometry
D. Referral for hearing aids
E. Review in 3 months

**Answer**: C

**Explanation**: Pure tone audiometry is recommended for children presenting with hearing difficulties, especially when these issues are impacting their school performance and behaviour.

---

### 286. Question 286
A 24 year old man has poor urine flow and takes a very long time to empty his bladder. He has no other urinary symptoms. He has been well previously apart from one episode of non-gonococcal urethritis 1 year ago

What is the most likely diagnosis?

A. Overactive bladder
B. Neurogenic bladder
C. Phimosis
D. Prostatic hypertrophy
E. Urethral stricture

**Answer**: E

**Explanation**: Based on the symptoms described, the most likely diagnosis for the 24 year old man is urethral stricture. Urethral stricture is a condition that occurs when the urethra narrows, which can cause difficulty in passing urine and a slow urinary stream. This can lead to a feeling of incomplete emptying of the bladder and a need to strain to empty the bladder completely. Urethral stricture follows previous urethral inflammation due to infection. Other possible causes of these symptoms include prostatic hypertrophy, but this condition is more common in older men, usually over the age of 50. Overactive bladder and neurogenic bladder can also cause urinary symptoms, but they typically present with other symptoms such as urgency, frequency, and incontinence. Phimosis refers to the condition where the foreskin cannot be retracted from the tip of the penis, and is unlikely to cause the urinary symptoms described.

---
### 287. Question 287
A 67 year old man is found to have an ejection systolic murmur. He is otherwise well. His pulse is 72 bpm and BP 128/84 mmHg. His chest is clear

**Investigations:**
ECG shows sinus rhythm. Echocardiography shows aortic stenosis, valve gradient 50 mmHg. Left ventricular (LV) diastolic dysfunction, LV ejection fraction 45% (>55).

What is the most appropriate management?

A. Clinical review and echocardiography in 6 months
B. Reassure and discharge
C. Refer for aortic valve replacement
D. Start bisoprolol fumarate and advise review if symptomatic
E. Start lisinopril and advise review if symptomatic

**Answer**: C

**Explanation**: Aortic stenosis with left ventricular ejection fraction (LVEF) less than 55% should be referred for consideration of an aortic valve replacement (AVR). Medications should not be started as these have no effect on the valve disease progression and may even cause side effects. The patient needs to start the process of definitive treatment with valve replacement so it is not good practice or safe to either discharge or review in 6 months. NICE guideline [NG208] Published: 17 November 2021 https://www.nice.org.uk/guidance/ng208/chapter/recommendations

---
### 288. Question 288
A 27 year old woman has muscle weakness which is worse on exercise. When asked to count from one to 100 her voice progressively becomes weaker. She has bilateral ptosis

Which pathophysiological process is most likely to be responsible for this disorder?

A. Autoimmunity
B. Genetic disorder
C. Infarction
D. Malignancy
E. Meningeal infection

**Answer**: A

**Explanation**: Autoimmunity is the most likely pathophysiological process responsible for this disorder. The symptoms described are consistent with myasthenia gravis, an autoimmune disorder that affects neuromuscular transmission. The muscle weakness worsens with exercise or prolonged use, and the patient also has bilateral ptosis, which is a common feature of myasthenia gravis. The progressive weakness of voice during counting is a characteristic finding known as the "fatigue test." Autoimmune antibodies target the acetylcholine receptors at the neuromuscular junction, resulting in impaired transmission of nerve impulses to the muscle.

---
### 289. Question 289
A 46 year old man has pain in his left leg and tingling in his left big toe. He developed severe lower back pain 1 week ago and he is unable to walk on his left heel. There is loss of pinprick perception over the left great toe

Which nerve root is the most likely to have been affected?

A. L1
B. L3
C. L5
D. S1
E. S2

**Answer**: C

**Explanation**: L5 is the most likely nerve root to have been affected. The patient has a combination of lower back pain, pain in the left leg, and tingling in the left big toe, which are consistent with the dermatomal distribution of the L5 nerve root. The inability to walk on the left heel suggests a left-sided foot drop, and so is also consistent with L5 nerve root dysfunction. The loss of pinprick perception over the left great toe also suggests involvement of the L5 dermatome.

---
### 290. Question 290
A 52 year old man has three days of severe epigastric pain, radiating to his back, but no chest pain. He has vomited several times. He was previously well. He drinks approximately 60 units of alcohol a week and smokes 20 cigarettes per day. There is epigastric tenderness but his abdomen is not distended, and bowel sounds are present

Which test would confirm the most likely diagnosis?

A. Abdominal X-ray
B. Gastroduodenoscopy
C. Serum alkaline phosphatase concentration
D. Serum amylase concentration
E. Ultrasound scan of abdomen

**Answer**: D

**Explanation**: Serum amylase concentration would confirm the most likely diagnosis in this case. The patient presents with severe epigastric pain, radiating to his back, and vomiting, which are suggestive of acute pancreatitis. The presence of epigastric tenderness but not distended abdomen and normal bowel sounds are also consistent with this diagnosis. Serum amylase concentration is an important diagnostic test for acute pancreatitis. Elevated serum amylase levels occur early in the course of the disease and can be measured within hours of symptom onset. Abdominal X-ray, gastroduodenoscopy, serum alkaline phosphatase concentration, and ultrasound scan of the abdomen may be useful in certain cases, but they are not as specific for diagnosing acute pancreatitis as serum amylase concentration.

---
### 291. Question 291
A 24 year old man attends the emergency department after 2 days of vomiting. He has type 1 diabetes. He is drowsy but maintaining his airway. His pulse is 100 bpm, BP 90/60 mmHg, respiratory rate 30 breaths per minute and oxygen saturation 96% breathing air

**Investigations:**
Blood capillary glucose 32 mmol/L Blood capillary ketones 6.2 mmol/L (<0.6) Venous pH 7.15 (7.35–7.45)

What is the most appropriate initial treatment?

A. Intravenous 0.9% sodium chloride
B. Intravenous 1.26% sodium bicarbonate
C. Intravenous antibiotics
D. Intravenous insulin
E. Subcutaneous insulin

**Answer**: A

**Explanation**: This patient has diabetic ketoacidosis (DKA). The first step in treatment is intravenous 0.9% sodium chloride to correct dehydration and hyperosmolality. IV insulin will be required but follows initial fluid prescription.

---
### 292. Question 292
A 24 year old woman has diarrhoea. She is HIV positive and has been working in Namibia

**Investigations:**
Faeces microscopy (following modified Ziehl–Neelsen stain): protozoa

What is the most likely causative organism?

A. Acanthamoeba
B. Cryptosporidium parvum
C. Entamoeba coli
D. Plasmodium falciparum
E. Schistosoma mansoni

**Answer**: B

**Explanation**: Cryptosporidium parvum is the most likely causative organism for diarrhoea in an HIV positive patient working in Namibia. Cryptosporidium is a protozoan parasite that can cause diarrhoea in immunocompromised patients, including those with HIV. It is commonly found in contaminated water sources and is a significant cause of diarrhoeal disease in developing countries. Acanthamoeba, Entamoeba coli, Plasmodium falciparum, and Schistosoma mansoni can also cause various diseases, but are less likely to be the cause of diarrhoea in this patient given the clinical context.

---
### 293. Question 293
A 67 year old man has difficulty chewing and speaking. He underwent carotid surgery 2 days ago. His tongue deviates to the right when he is asked to protrude it

Which nerve has been damaged?

A. Left glossopharyngeal nerve
B. Left hypoglossal nerve
C. Left vagus nerve
D. Right glossopharyngeal nerve
E. Right hypoglossal nerve

**Answer**: E

**Explanation**: The hypoglossal nerve is responsible for motor function of the tongue, including protrusion and side-to-side movements. Damage to the hypoglossal nerve on one side will cause the tongue to deviate towards the affected side (the stronger left side will push it to the right). In this case, the patient had carotid surgery on the left side, so the right hypoglossal nerve is likely to have been damaged.

---
### 294. Question 294
An 18 year old woman has had 3 years of intermittent zig-zagging and flashing lights in both eyes associated with headache. These episodes occur 2-3 times per month and last approximately half an hour. The symptoms are associated with nausea and vomiting. Her vision is affected at the time of each episode but returns to normal afterwards

What is the most likely diagnosis?

A. Acute glaucoma
B. Migraine
C. Occipital lobe epilepsy
D. Retinal detachment
E. Tension-type headache

**Answer**: B

**Explanation**: The most likely diagnosis is B. Migraine. The classic visual symptoms of zig-zagging and flashing lights, headache, nausea, and vomiting are typical features of migraine with aura. The fact that the patient's vision returns to normal after each episode is also consistent with migraine. Acute glaucoma and retinal detachment may present with sudden onset of symptoms, but these are a ‘one off’ and persist, and require urgent ophthalmologic assessment. Occipital lobe epilepsy is a possibility but less likely since zig-zags almost always point to migraine rather than epilepsy. Tension-type headache does not typically have visual symptoms.

---
### 295. Question 295
A 75 year old man has had 3 days of intermittent headaches, blurred vision and vomiting. For the past 24 hours he has had a severe left sided headache and eye pain, accompanied by blurred vision and vomiting. His left eye is red and the left pupil is dilated

What investigation is most likely to confirm the diagnosis?

A. CT scan of head
B. Erythrocyte sedimentation rate
C. Fluorescein staining of the cornea
D. Measurement of intraocular pressure
E. MR scan of head

**Answer**: D

**Explanation**: Based on the symptoms and signs described, the most likely diagnosis is acute angle-closure glaucoma, which is a medical emergency that requires prompt diagnosis and treatment to prevent vision loss. Therefore, the investigation that is most likely to confirm the diagnosis is measurement of intraocular pressure. A high intraocular pressure is characteristic of acute angle-closure glaucoma, although other investigations such as a CT or MR scan of the head may be performed to rule out other causes of the symptoms.

---
### 296. Question 296
A 72 year old woman has had 4 months of progressive difficulty walking. She describes numbness and tingling in her feet and has fallen on several occasions. She has normal tone of her lower limbs, moderate weakness of ankle dorsiflexion and plantar flexion, normal knee jerks, but absent ankle jerks and extensor plantars. Romberg test is positive. She has reduced vibration sense, and joint position sense is impaired up to the ankle joints. Temperature and pinprick sensations are normal

What investigation is most likely to confirm the diagnosis?

A. HbA1C
B. Serum folate
C. Serum protein electrophoresis
D. Serum vitamin B12
E. Serum vitamin D

**Answer**: D

**Explanation**: The clinical picture is consistent with subacute combined degeneration of the cord, giving a mixture of upper motor neurone (extensor plantars) and lower motor neurone (absent ankle jerks) features. The sensory ataxia (positive Romberg test and absent position sense in the ankles) is most likely due to dorsal column dysfunction from vitamin B12 deficiency, and this can be confirmed by serum vitamin B12 measurement. Vitamin B12 deficiency of this severity is usually caused by pernicious anaemia.

---
### 297. Question 297
A 34 year old woman has a recurrent itchy rash which lasts for several hours before resolving (see image). She has not identified any triggers. She is systemically well. She is a firefighter and says that she does not want any treatments that may affect her level of alertness

[IMAGE: image_297_MLA7_page13_image_13_2.png]

What is the most appropriate treatment to control her symptoms?

A. Oral chlorphenamine maleate
B. Oral loratadine
C. Oral prednisolone
D. Topical aqueous cream
E. Topical hydrocortisone

**Answer**: B

**Explanation**: The image shows urticarial weals. Initial treatment for this should be a non-sedating H1-antihistamine. The correct answer is thus B (oral loratadine). Chlorphenamine maleate is a sedating antihistamine, which is more likely to cause adverse effects; this patient also specifically requested treatment that would not affect her level of alertness. Prednisolone is effective for severe, acute urticaria but should not be used first-line. Aqueous cream is a soap substitute and has no role in the management of urticaria. Topical corticosteroids are ineffective for urticaria so hydrocortisone is not indicated here. https://cks.nice.org.uk/topics/urticaria/

---
### 298. Question 298
A 29 year old woman has 2 days of marked loss of vision and acute pain in her left eye. The pain is worse when she changes her gaze direction. Her eyes appear normal on general inspection. Her vision is 'count fingers only' in the affected eye. The swinging flashlight test shows that the left pupil dilates when a bright light is moved from the right eye to the left eye. The optic discs are normal on fundoscopy

What is the most likely diagnosis?

A. Acute closed angle glaucoma
B. Giant cell arteritis
C. Idiopathic intracranial hypertension
D. Migraine with aura
E. Retrobulbar optic neuritis

**Answer**: E

**Explanation**: The most likely diagnosis in this scenario is retrobulbar optic neuritis. The acute onset of eye pain and marked loss of vision, along with the presence of relative afferent pupillary defect (RAPD) on swinging flashlight test, are suggestive of optic neuritis. The absence of optic disc swelling on fundoscopy suggests a retrobulbar lesion. Acute closed angle glaucoma also presents with acute eye pain, but it is typically associated with other features such as vomiting, headaches and a red eye with a dilated pupil accompanied by a high intraocular pressure. Giant cell arteritis can also cause acute visual loss, but it is more commonly seen in older patients and is often associated with systemic symptoms such as headache, jaw claudication, and malaise. Idiopathic intracranial hypertension can cause vision loss and headache, but it typically does not cause pain with eye movements. Migraine with aura can cause visual disturbances, but it is typically not associated with pain, and the presence of RAPD suggests a neuro-ophthalmic rather than a primary headache disorder.

---
### 299. Question 299
A 45 year old woman develops an intensely painful eruption around her right eye. The illness started with pain 5 days previously, followed by the appearance of a few vesicles, which has now developed into the rash (see image). She has no significant medical history. Treatment is started

[IMAGE: image_299_MLA7_page15_image_15_2.png]

What is the most likely long-term outcome?

A. Complete resolution with no sequelae
B. Corneal ulceration
C. Extensive scarring of the right temple
D. Partial ptosis
E. Reduced visual acuity

**Answer**: A

**Explanation**: The clinical presentation described in this scenario is consistent with herpes zoster ophthalmicus, which is caused by reactivation of the varicella-zoster virus in the ophthalmic division of the trigeminal nerve. Ocular involvement occurs in approximately 50% of patients and some of these can experience a range of complications. However, in the majority of cases there is complete resolution with no sequelae.

---
### 300. Question 300
A 48 year old woman has rheumatoid arthritis. She takes regular paracetamol and has no drug allergies. She is due to commence methotrexate weekly

What additional treatment should be prescribed?

A. Calcium carbonate
B. Folic acid
C. Pyridoxine hydrochloride
D. Thiamine
E. Vitamin D

**Answer**: B

**Explanation**: Folic acid is recommended as an additional treatment for patients taking methotrexate to reduce the risk of adverse effects. It can be used for this purpose once a week, or daily but omitted on the day of the (weekly) methotrexate dose. Calcium carbonate, pyridoxine hydrochloride, thiamine, and vitamin D are not routinely prescribed as additional treatments for methotrexate. Pyridoxine hydrochloride is usually prescribed alongside isoniazid in the treatment of tuberculosis.

---
### 301. Question 301
A 74 year old woman has 6 months of progressive weakness of her right leg and 3 months of a similar problem on the left, resulting in several falls. She has also noticed difficulty using her hands and can no longer fasten the buttons on her clothes. There is wasting of both legs and the hands, particularly the thenar eminences. There is fasciculation in her right quadriceps. Tone is increased in both legs, with brisk reflexes

What is the most likely diagnosis?

A. Chronic inflammatory demyelinating polyneuropathy
B. Motor neurone disease
C. Multiple sclerosis
D. Myasthenia gravis
E. Polymyositis

**Answer**: B

**Explanation**: The most likely diagnosis is motor neurone disease, which is characterised by progressive weakness and wasting of muscles due to degeneration of motor neurones in the brain and spinal cord. The combination of both lower motor neurone signs (fasciculation) and upper motor neurone signs (brisk reflexes) in the same limb are particularly characteristic of motor neurone disease. Multiple sclerosis is purely upper motor neurone and the options listed (chronic inflammatory demyelinating polyneuropathy, myasthenia gravis, and polymyositis) are purely lower motor neurone conditions.

---
### 302. Question 302
A 61 year old man has had 2 months of ankle swelling. He has hypertension and a 30 year history of seronegative polyarthritis. His medication includes diclofenac, hydroxychloroquine sulfate, ramipril and sulfasalzine. His BP is 156/90 mmHg. He has pitting oedema to mid-thigh and signs of chronic deforming polyarthropathy in his hands, but no joint tenderness. His optic fundi show silver wiring and arteriovenous nipping. Urinalysis: protein 4+, no other abnormalities

**Investigations:**
Sodium 133 mmol/L (135–146) Potassium 5.4 mmol/L (3.5–5.3) Urea 9.0 mmol/L (2.5–7.8) Creatinine 119 µmol/L (60–120) Albumin 21 g/L (35–50) CRP 43 mg/L (<5) Urinary protein:creatinine ratio 1100 mg/mmol (<30)

What is the most appropriate initial treatment?

A. Candesartan cilexetil
B. Furosemide
C. Indapamide
D. Prednisolone
E. Prednisolone and cyclophosphamide

**Answer**: B

**Explanation**: Based on the clinical presentation and investigations, the most likely diagnosis is nephrotic syndrome, possibly secondary to the patient's long-standing polyarthritis. The appropriate initial treatment would be to start a furosemide to reduce the patient's ankle swelling and to refer the patient to a specialist for further investigation and management of the underlying cause. Furosemide is a loop diuretic that acts on the ascending limb of the loop of Henle to increase sodium and water excretion, which can reduce oedema. It is a commonly used diuretic in the management of nephrotic syndrome.

---
### 303. Question 303
A 75 year old woman has had 5 months of a 2 cm red plaque on her leg

**Investigations:**
Skin biopsy: Bowen disease

What is the most appropriate topical treatment?

A. 5-fluorouracil (Efudix®) cream
B. Betamethasone valerate (Betnovate®) cream
C. Diclofenac (Solaraze®) gel
D. Isotretinoin gel
E. Salicylic acid gel

**Answer**: A

**Explanation**: The most appropriate topical treatment for Bowen disease, a type of squamous cell carcinoma in situ 5-fluorouracil (Efudix®) cream. This is a form of topical cytotoxic chemotherapy which is used to treat both Bowen disease and actinic keratosis. It is typically applied to the affected area once or twice a day for 2–4 weeks. An inflammatory reaction, which can be severe, should be expected. Topical corticosteroids such as betamethasone valerate have no effect on Bowen disease. Diclofenac can be used in the treatment of actinic keratosis but is not indicated for Bowen disease. Isotretinoin gel is a retinoid used in the treatment of acne. Salicylic acid is a keratolytic agent, which is used in the management of hyperkeratotic lesions such as viral warts and sometimes actinic keratoses. Whilst it might reduce hyperkeratosis in Bowen, it will not treat the underlying dysplasia effectively.

---
### 304. Question 304
A 32 year old woman has had palpitations and hot flushes for 4 weeks. She has noticed a painless swelling in her neck over the same time and her weight has decreased by 2 kg. She gave birth 4 months ago after a normal pregnancy. She is not breastfeeding. Her pulse is 120 bpm and BP 140/90 mmHg. She is tremulous and restless. She has a large smooth non-tender goitre

**Investigations:**
Free T4 35.6 pmol/L (9–25) Free T3 10.8 pmol/L (4.0–7.2) TSH <0.01 mU/L (0.3–4.2) Thyroid peroxidase antibodies >1600 IU/L (<50) Thyroid stimulating antibodies <1.0 IU/L (<1.75)

What is the most appropriate initial treatment?

A. Carbimazole
B. Propranolol
C. Propylthiouracil
D. Thyroidectomy
E. Thyrotropin alfa

**Answer**: B

**Explanation**: The patient's presentation and investigations are consistent with hyperthyroidism and a diagnosis of postpartum thyroiditis. Given her symptoms of palpitations, hot flushes, tremulousness, and a high pulse rate, the most appropriate initial treatment is option propranolol. It works by blocking the effects of thyroid hormones on the heart and peripheral tissues. Propranolol can be started immediately to control the patient's symptoms while further investigations and management are initiated.

---
### 305. Question 305
An 80 year old man has an ulcer over the left heel and reduced mobility. He has a loss of appetite. He has type 2 diabetes mellitus and has previously had a myocardial infarction. The ulcer is 3 cm in diameter and deeply penetrating. Sensory testing shows reduced vibration sense but normal sensation to light touch. His Doppler ratio (ankle brachial pressure index) on the left is 0.68 and on the right is 0.98 (normal value 1.00)

What is the most likely mechanism of his ulcer?

A. Arterial
B. Neuropathic
C. Nutritional
D. Vasculitic
E. Venous

**Answer**: A

**Explanation**: The ulcer description is arterial. Given the APB of 0.68 and a history of previous MI to support this diagnosis. Normal sensation rules out neuropathic. Nutritional, venous and vasculitic ulcers have different characteristics.

---
### 306. Question 306
A 73 year old man is in hospital with a chest infection. He has several episodes of confusion, anxiety and aggression, during which he attempts to leave the hospital. He is convinced he is being 'spied on' by the doctors and nurses and insists that 'cameras have been installed in my room'. These episodes alternate with periods of marked lethargy, which become more pronounced towards the evening. His temperature is 37.8°C, pulse 100 bpm, BP 110/73 mmHg and respiratory rate 12 breaths per minute

What is the most likely diagnosis?

A. Alzheimer dementia
B. Bipolar disorder
C. Delirium
D. Lewy body dementia
E. Schizophrenia

**Answer**: C

**Explanation**: Delirium is the most likely diagnosis given the patient's acute onset of confusion, fluctuating level of consciousness, perceptual disturbances, and physical illness (chest infection) as a precipitating factor. Delirium is a common acute neuropsychiatric disorder among hospitalised elderly patients and can be caused by a variety of factors such as infection, medication side effects and metabolic derangements. Alzheimer dementia and Lewy body dementia are chronic neurodegenerative disorders characterized by progressive cognitive decline and are not typically associated with acute changes in mental status. Bipolar disorder and schizophrenia are chronic psychiatric disorders that may cause psychosis and delusions but are not typically associated with the acute onset of confusion seen in delirium.

---
### 307. Question 307
A 78 year old woman is admitted to the surgical unit with a suspected vesicocolic fistula. She has hypertension, type 2 diabetes mellitus and angina. She takes amlodipine, metformin, gliclazide, simvastatin and bisoprolol. Her serum creatinine is 120 µmol/L (60–120). The consultant surgeon requests a CT scan of abdomen with contrast

Which medication should be stopped before her CT scan?

A. Amlodipine
B. Bisoprolol
C. Gliclazide
D. Metformin
E. Simvastatin

**Answer**: D

**Explanation**: Metformin should be stopped before a CT scan with contrast as it can increase the risk of contrast-induced nephropathy. The risk is greater in patients with impaired renal function like the patient in this scenario. The other medications do not need to be stopped before the CT scan.

---
### 308. Question 308
A 50 year old man has a 3 month history of right loin pain and weight loss. For the past 20 years, he has smoked ten cigarettes per day. His temperature is 37.4°C, pulse is 72 bpm and BP is 142/74 mmHg

**Investigations:**
Haemoglobin 11.2 g/L (130–175) Platelets 340 × 109/L (150–400) White cell count 10.1 × 109/L (4.0–11.0) Urinalysis blood 3+

What is the most likely diagnosis?

A. Benign prostatic hypertrophy
B. Pyelonephritis
C. Renal calculus
D. Renal cancer
E. Urinary tract infection

**Answer**: D

**Explanation**: Given the patient's history of weight loss, loin pain, and smoking, as well as the presence of blood in the urine, the most likely diagnosis is renal cancer. Other conditions, such as benign prostatic hypertrophy, pyelonephritis, renal calculus, and urinary tract infection, may also present with similar symptoms but are less likely given the patient's history and laboratory findings. Further imaging studies, such as a CT scan or ultrasound, would be needed to confirm the diagnosis.

---
### 309. Question 309
A 74 year old man has been increasingly unwell with progressive thirst and nausea for 2 weeks. He initially described needing to pass urine more frequently than usual, but now he has not passed urine for 24 hours. He has type 2 diabetes. He is dehydrated

**Investigations:**
Sodium 149 mmol/L (135–146) Potassium 5.2 mmol/L (3.5–5.3) Chloride 101 mmol/L (95–106) Urea 15.4 mmol/L (2.5–7.8) Creatinine 208 µmol/L (60–120) Fasting glucose 41.7 mmol/L (3.0–6.0)

What is the calculated serum osmolality?

A. 206.1 mmol/L
B. 255.2 mmol/L
C. 312.3 mmol/L
D. 355.1 mmol/L
E. Impossible to calculate, more information needed

**Answer**: D

**Explanation**: Serum osmolality is 2 x(Na) + Urea + glucose The calculation is 298 + 15.4 + 41.6 = 355

---
### 310. Question 310
A 65 year old man receives a renal transplant. He is transferred back to the ward after four hours in recovery. His pulse is 106 bpm regular, BP 110/70 mmHg and respiratory rate 18 breaths per minute. His chest is clear on auscultation. His urine output has been 15–20 mL per hour while in recovery. Drain output has been 120 mL since surgery

**Investigations:**
Haemoglobin 90 g/L (130–175) (preoperative level 103 g/L) Sodium 142 mmol/L (135–146) Potassium 5.8 mmol/L (3.5–5.3) Urea 31.9 mmol/L (2.5–7.8) Creatinine 590 µmol/L (60–120)

What is the next most appropriate management step?

A. Blood transfusion
B. Fluid challenge
C. Furosemide
D. Haemofiltration
E. Insulin and dextrose infusion

**Answer**: B

**Explanation**: The patient has a low urine output, with tachycardia and relative hypotension shortly after a renal transplant. In this early post-operative phase the most likely cause is hypovolaemia so the most appropriate intervention would be to administer a fluid challenge.

---
### 311. Question 311
A 64 year old man has developed a tremor in both arms over the last 6 months. It is worse on the right. He also reports difficulty sleeping due to restlessness. He appears emotionally flat and has a tremor at rest that is alleviated on movement

Which neurotransmitter is most likely to be deficient?

A. Acetylcholine
B. Dopamine
C. Glycine
D. Norepinephrine (noradrenaline)
E. Serotonin

**Answer**: B

**Explanation**: The diagnosis is Parkinson disease and hence dopamine is most likely to be deficient. The presence of an asymmetric resting tremor that is alleviated on movement is a characteristic feature of Parkinson disease. The restless sleep implies probable associated REM sleep behaviour disorder.

---
### 312. Question 312
An 85 year old man is admitted from a nursing home with a spreading cellulitis originating from an ulcer over his right ankle. He is mildly confused. His temperature is 39.5°C, pulse 96 bpm and BP 114/60 mmHg. Cultures taken from the ulcer and blood have grown MRSA

What is the most appropriate initial antibiotic treatment?

A. Co-amoxiclav
B. Flucloxacillin
C. Meropenem
D. Piperacillin with tazobactam
E. Vancomycin

**Answer**: E

**Explanation**: Vancomycin would be the most appropriate initial antibiotic treatment in this case of MRSA cellulitis. Vancomycin is a glycopeptide antibiotic that is active against MRSA and other Gram-positive bacteria. It is the drug of choice for treating serious MRSA infections, such as cellulitis, when the strain is known or suspected to be resistant to beta-lactam antibiotics like flucloxacillin or co-amoxiclav. Piperacillin with tazobactam and meropenem are broad-spectrum antibiotics that may be used as an alternative if the patient has a severe penicillin allergy or if the infection is suspected to be caused by Gram-negative bacteria as well. However, they are not specific for MRSA and should be used judiciously to avoid the development of antibiotic resistance. NICE guideline [NG141] Published: 27 September 2019 https://www.nice.org.uk/guidance/ng141/chapter/Recommendations

---
### 313. Question 313
A 75 year old man is found collapsed at home and is brought to the emergency department. He has right sided weakness and reduced consciousness. He has type 2 diabetes mellitus, atrial fibrillation and hypertension. He takes warfarin

**Investigations:**
INR 4.6 (<1.4) CT scan of the head shows a large intracranial haemorrhage. He is given intravenous vitamin K.

What is the most appropriate next additional treatment?

A. Cryoprecipitate
B. Fresh frozen plasma
C. Fibrinogen concentrate
D. No additional treatment needed
E. Prothrombin complex concentrate

**Answer**: E

**Explanation**: The patient has an INR of 4.6, which is significantly elevated, suggesting an excessive anticoagulant effect of warfarin. The CT scan shows a large intracranial haemorrhage, which is a life-threatening complication that requires urgent management. The administration of vitamin K will help to reverse the anticoagulant effect of warfarin, but this will take several hours to take effect. In the meantime, the patient is at risk of ongoing bleeding, and so requires further treatment. Prothrombin complex concentrate (PCC) is the most appropriate next additional treatment in this situation. PCC is a concentrated source of clotting factors that can be used to rapidly reverse the anticoagulant effect of warfarin and restore haemostasis. It is more effective than fresh frozen plasma or cryoprecipitate and has a lower risk of complications. Fibrinogen concentrate is not indicated in this situation as there is no evidence of fibrinogen deficiency.

---
### 314. Question 314
A 76 year old woman has no energy and reports excessive tiredness for 3 weeks. She has lost 5 kg in weight over the past 3 months. She drinks 30 units of alcohol per week. She is thin and jaundiced. Her temperature is 37.2°C. She has a palpable epigastric mass and 4 cm liver edge

What is the most likely diagnosis?

A. Cholangiocarcinoma
B. Cholecystitis
C. Cirrhosis of the liver
D. Hepatocellular carcinoma
E. Pancreatic adenocarcinoma

**Answer**: E

**Explanation**: The most likely diagnosis given the presentation of the patient is pancreatic adenocarcinoma. The symptoms of excessive tiredness, weight loss, jaundice, and palpable mass in the epigastric area along with a history of alcohol use make pancreatic adenocarcinoma the most probable diagnosis. The presence of a 4cm liver edge also indicates liver metastasis.

---
### 315. Question 315
A 76 year old woman with hypertension is taking amlodipine 10 mg daily. A 24 hour BP measurement shows a mean BP of 168/90 mmHg.

**Investigations:**
Sodium 135 mmol/L (135–146) Potassium 4.0 mmol/L (3.5–5.3) Urea 7 mmol/L (2.5–7.8) Creatinine 100 μmol/L (60–120) eGFR 68 mL/min/1.73 m2 (>60) Urinary albumin : creatinine ratio 50 mg/mmol (<35)

Which class of antihypertensive should be added?

A. ACE inhibitor
B. Alpha blocker
C. Beta blocker
D. Loop diuretic
E. Thiazide-like diuretic

**Answer**: A

**Explanation**: Ace inhibitors are the most effective medication to treat albuminuria to delay progression to end stage renal disease and reduces cardiovascular risk. NICE suggest that ACE inhibitors or AR2B medications should be first choice in this situation with an ACR >30 mg/mmol in a patient with hypertension. There is no evidence for the other medications to reduce proteinuria and thus CVS risk. NICE guideline [NG136] Published: 28 August 2019 Last updated: 21 November 2023 https://www.nice.org.uk/guidance/ng136/chapter/recommendations

---
### 316. Question 316
A 70 year old man is an inpatient on the cardiology ward. He has worsening breathlessness that woke him up last night. His pulse is 99 bpm, BP 160/100 mmHg and respiratory rate 20 breaths per minute. Auscultation of the chest reveals bibasal crepitations, and there is dullness to percussion of both bases. Chest X-ray shows small bilateral pleural effusions with upper lobe blood vessel diversion

What is the most appropriate diagnostic investigation?

A. Coronary angiography
B. CT pulmonary angiography
C. ECG
D. Echocardiography
E. Serum D dimer

**Answer**: D

**Explanation**: Echocardiography would be the most appropriate diagnostic investigation for this patient with worsening breathlessness and signs of heart failure on examination and chest X-ray. Echocardiography can provide information on cardiac function and identify possible causes of heart failure such as valvular disease, cardiomyopathy or pericardial effusion. Coronary angiography would be indicated if there is suspicion of underlying coronary artery disease, but the presentation in this case suggests heart failure rather than acute coronary syndrome. CT pulmonary angiography and serum D-dimer would be indicated if there is suspicion of pulmonary embolism, but the presence of bilateral pleural effusions and upper lobe blood vessel diversion on chest X-ray suggests a cardiac cause for the symptoms. ECG may show evidence of underlying cardiac disease, but echocardiography would be a more appropriate investigation to assess cardiac function.

---
### 317. Question 317
An 80 year old man has sudden onset of loss of vision in his right eye. He has hypertension and a previous stroke. His visual acuity is hand movements only in the right eye and 6/9 in left eye. The right eye has an afferent pupillary defect; left eye pupil responses are normal. On fundoscopy there is a red spot at the right macula

What is the most likely diagnosis?

A. Anterior ischaemic optic neuropathy
B. Branch retinal vein occlusion
C. Central retinal artery occlusion
D. Macular degeneration
E. Retinal detachment

**Answer**: C

**Explanation**: The most likely diagnosis in this scenario is central retinal artery occlusion (CRAO). The sudden onset of visual loss, the presence of an afferent pupillary defect, and red spot (the cherry red spot) on fundoscopy are all consistent with this diagnosis. The patient also has risk factors for this diagnosis. In branch retinal vein occlusion patients typically have multiple retinal haemorrhages in the distribution of the vein. Macular degeneration does not cause sudden onset visual loss and although both retinal detachment and anterior ischaemic optic neuropathy cause acute visual loss neither have the fundoscopic findings described.

---
### 318. Question 318
A 72 year old woman has had inability to sleep well for the past 3 years. She gets to sleep by 23:00 but wakes up two or three times in the night and gets up by 07:00. Her husband says that she doesn't snore. She carries out her normal daytime activities with no daytime somnolence. She is otherwise well. Her BMI is 23 kg/m2. Her MMSE (Mini Mental State Examination) score is 27/30

What is the most likely cause of her insomnia?

A. Depression
B. Early stages of dementia
C. Hypomania
D. Normal age related sleep pattern
E. Obstructive sleep apnoea

**Answer**: D

**Explanation**: Based on the information given, the most likely cause of her insomnia is normal age-related sleep pattern. This is because she is able to carry out normal daytime activities with no daytime somnolence, has no history of snoring or other sleep-related symptoms, and has a high MMSE score indicating good cognitive function. It is common for older adults to experience changes in their sleep patterns, such as more fragmented sleep and more frequent awakenings during the night. Other potential causes such as depression, dementia, hypomania, and obstructive sleep apnoea would require further evaluation and additional symptoms or risk factors to be confirmed.

---
### 319. Question 319
A 35 year old man attends his GP with 3 days of a red, painful left eye with no discharge. There is a diffuse area of redness in the medial aspect of his left sclera. His pupils and visual acuity are normal

What is the most appropriate management?

A. Arrange assessment in emergency eye clinic
B. Prescribe chloramphenicol eye drops
C. Prescribe corticosteroid eye drops
D. Prescribe topical aciclovir
E. Reassure patient that it will resolve spontaneously

**Answer**: A

**Explanation**: The symptoms of a painful red eye without discharge and a diffuse area of redness on the sclera are suggestive of scleritis, which requires immediate referral by his GP to an ophthalmologist via the emergency eye clinic. Scleritis is an inflammatory condition of the sclera that can lead to other serious ocular complications if untreated. Although topical corticosteroids may be used in the management of scleritis these should only be initiated under the supervision of an Ophthalmologist after confirmation of the diagnosis. None of the other options in this case would be appropriate.

---
### 320. Question 320
An 18 year old woman is found dead, sitting in front of a gas fire that is still burning. The flue that carries gases away from the fire is found to be blocked

What is the principal mechanism of action of the poison involved in her death?

A. Binding to the site on haemoglobin normally occupied by oxygen
B. Converting carbon dioxide to carbonic acid in the cytoplasm of peripheral cells
C. Converting the iron in haem to an iron salt
D. Damaging the lipid bilayer of alveolar pneumocytes
E. Inhibiting cytochrome enzyme systems

**Answer**: A

**Explanation**: The most likely cause of death in this case is carbon monoxide (CO) poisoning, which is known to result from blocked flues and unvented fires. CO binds to the site on haemoglobin normally occupied by oxygen, thereby reducing the oxygen-carrying capacity of the blood. This leads to tissue hypoxia and eventually death.

---
### 321. Question 321
A 35 year old man has burning pain in his feet and difficulty sleeping. He has type 1 diabetes mellitus, retinopathy and nephropathy

**Investigations:**
eGFR 28 mL/min/1.73m2 (> 60)

What is the most appropriate management?

A. Acupuncture
B. Amitriptyline
C. Duloxetine
D. Physiotherapy
E. Sodium valproate

**Answer**: B

**Explanation**: The most appropriate management for this patient with type 1 diabetes mellitus, burning pain in his feet, difficulty sleeping, and decreased eGFR would be amitriptyline. Although duloxetine can be used in this condition it is not recommended with an eGFR <30 mL/min. Clinical guideline [CG173] Published: 20 November 2013 Last updated: 22 September 2020 https://www.nice.org.uk/guidance/cg173/chapter/Recommendations

---
### 322. Question 322
A 24 year old woman has tiredness, bloating and weight loss with bouts of offensive smelling diarrhoea. Abdominal examination is normal

**Investigations:**
Haemoglobin 10.0 g/L (115–150) Mean cell volume (MCV) 78 fL (80–96) Platelets 350 × 109/L (150–400) Duodenal biopsy shows flattening of villi and increased lymphocytes in the lamina propria and surface epithelium. In addition, there is gross crypt hyperplasia.

What is the most likely diagnosis?

A. Carcinoid tumour
B. Coeliac disease
C. Collagenous enteropathy
D. Crohn disease
E. Pseudomembranous enteropathy

**Answer**: B

**Explanation**: The most likely diagnosis is Coeliac disease. The symptoms of tiredness, bloating and weight loss along with flattened villi and increased lymphocytes in the lamina propria and surface epithelium on duodenal biopsy suggest the diagnosis. The low haemoglobin and MCV values could also be attributed to malabsorption associated with coeliac disease. The other options listed (carcinoid tumour, collagenous enteropathy, Crohn disease, and pseudomembranous enteropathy) do not fit the clinical picture and findings described in the case.

---
### 323. Question 323
An 87 year old man develops profuse watery diarrhoea 6 days after admission for an infective exacerbation of COPD. He is currently taking oral co- amoxiclav

What is the most likely causative organism?

A. Campylobacter jejuni
B. Clostridioides difficile (Clostridium difficile)
C. Escherichia coli
D. Norovirus
E. Salmonella enteriditis

**Answer**: B

**Explanation**: The most likely causative organism in this case is Clostridioides difficile (Clostridium difficile) as it is a common cause of antibiotic-associated diarrhoea and the patient is taking oral co-amoxiclav.

---
### 324. Question 324
A 22 year old woman has worsening shortness of breath and cough productive of four to five tablespoons of sputum per day. She had childhood pneumonia and recurrent chest infections. She coughed up blood on two occasions many years ago. She has bilateral scattered wheezes and coarse inspiratory crackles

What is the most likely diagnosis?

A. Bronchiectasis
B. COPD
C. Lung cancer
D. Pulmonary fibrosis
E. Sarcoidosis

**Answer**: A

**Explanation**: Bronchiectasis is most likely due to the copious sputum production, and the history of childhood pneumonia and recurrent chest infections. Cystic fibrosis should be considered also as a cause of the bronchiectasis. Bronchiectasis is characterised by permanent dilation and thickening of bronchi resulting in chronic cough with daily sputum production and recurrent respiratory infections. Often there are coarse crackles on examination and there may be wheeze if there is an exacerbation. Haemoptysis can be a feature of bronchiectasis especially when there is an exacerbation. COPD and lung cancer are very uncommon in this age group. Pulmonary fibrosis generally has fine crackles and copious sputum production is less common. Sarcoidosis can cause fine crackles also, but it is unusual in this age group and it does not usually present with recurrent chest infections and copious sputum production is not usually a feature.

---
### 325. Question 325
A 52 year old woman has had four episodes of severe, colicky epigastric pain associated with vomiting over the past 3 months. The episodes occurred after eating and lasted for about 1 hour before complete resolution. She has type 2 diabetes mellitus and takes metformin. Abdominal examination is normal. Her BMI is 35 kg/m2

What investigation is most likely to confirm the diagnosis?

A. Helicobacter stool antigen test
B. Serum Amylase
C. Plain abdominal X-ray
D. Ultrasonography of abdomen
E. Upper gastrointestinal endoscopy

**Answer**: D

**Explanation**: The patient reports intermittent episodes of colicky pain in association with nausea and vomiting. This would be consistent with biliary colic. She has risk factors for gallstones including being female, middle aged and overweight. Therefore an ultrasound of abdomen would be the appropriate investigation at this stage. The symptoms of colicky pain occurring after eating are more consistent with gall stone disease than with gastro-oesophageal reflux disease (GORD) or dyspepsia. Upper Gi endoscopy and Helicobacter stool antigen test are relevant when investigating for suspected GORD / dyspepsia respectively and do not help diagnose gall stones. Serum amylase is indicated in suspected pancreatitis. Plain abdominal X-ray would be potentially helpful in the investigation of suspected small or large bowel pathologies (e.g. obstruction, constipation), although CT would likely be more informative.

---
### 326. Question 326
An 83 year old woman has recurring dizzy spells. The episodes are associated with transient shaking of her hands that is most noticeable before her lunch and evening meals. She has hypertension and type 2 diabetes mellitus. She takes metformin (1 g twice daily), gliclazide (80 mg twice daily) and ramipril (10 mg daily). Her BP is 138/82 mmHg lying and 130/78 mmHg standing. Her blood capillary glucose is 6 mmol/L

**Investigations:**
Sodium 136 mmol/L (135-146) Potassium 5.0 mmol/L (3.5-5.3) Urea 3.9 mmol/L (2.5-7.8) Creatinine 77 μmol/L (60-120) Glycated haemoglobin 50 mmol/mol (20-42)

What is the most appropriate therapeutic change?

A. Increase gliclazide dose
B. Increase metformin dose
C. Reduce gliclazide dose
D. Reduce metformin dose
E. Reduce ramipril dose

**Answer**: C

**Explanation**: This 83 year old woman is experiencing symptoms consistent with hypoglycaemia. The timing of her "dizzy spells" and hand shaking - before lunch and evening meals - suggests they might be related to periods of extended fasting and thus to her medications, particularly the ones that have the potential to lower blood glucose. Furthermore, her glycated haemoglobin (HbA1c) level is 50 mmol/mol. While this is elevated compared to the normal reference range provided (20-42 mmol/mol), it's in the target range or even a bit stringent for many elderly patients with type 2 diabetes. Overly aggressive glycaemic control can increase the risk of hypoglycaemia in older adults. Therefore, the most appropriate therapeutic change, given the symptoms and the clinical context, would be to reduce gliclazide dose.

---
### 327. Question 327
A 76 year old woman has progressive breathlessness with right-sided pleuritic chest pain and weight loss over 6 months. She is a retired mechanic and has a 25 pack-year smoking history

**Investigations:**
Chest X-ray: marked volume loss in right hemithorax CT scan of chest: see image

[IMAGE: image_327_MLA7_page43_image_43_2.png]

What is the most likely diagnosis?

A. Asbestosis
B. Chronic hypersensitivity pneumonitis
C. Lung cancer
D. Malignant pleural mesothelioma
E. Tuberculosis

**Answer**: D

**Explanation**: The symptoms and imaging findings described in the scenario are consistent with malignant pleural mesothelioma. The CT image shows marked volume loss in the right lung and the right lung is encased with tumour. The patient may have been exposed to asbestos in her job as a mechanic (brake pads etc). Chronic hypersensitivity pneumonitis and asbestosis have changes in the lung fields, not the pleura. The changes are usually bilateral and crackles are heard at the area of abnormality. This patient’s history would fit with lung cancer and she does have risk factors for lung cancer (smoking and asbestos exposure) but chest pain is more common with mesothelioma and the CT scan appearances are classical of mesothelioma as the thickening is of the pleura. TB can mimic anything but it is less likely in this case and there is no fever.

---
### 328. Question 328
A 65 year old woman has severe left-sided abdominal pain. Yesterday, she noticed blood mixed in with her stools. She has no weight loss. Her temperature is 37.7°C. She is very tender on palpation in the left lower quadrant. No masses are felt on rectal examination, but there is blood on the glove

What is the most likely cause of her symptoms?

A. Angiodysplasia
B. Colorectal cancer
C. Diverticulitis
D. Haemorrhoids
E. Ulcerative colitis

**Answer**: D

**Explanation**: Based on the patient's presentation of severe left-sided abdominal pain, blood mixed in with her stools, and tenderness on palpation in the left lower quadrant, the most likely cause of her symptoms is diverticulitis. Angiodysplasia is a condition where abnormal blood vessels in the gastrointestinal tract can cause bleeding, but it typically presents with painless bleeding and is not associated with abdominal pain or tenderness. Colorectal cancer can cause abdominal pain and bleeding, but it is less likely to present with acute onset of severe pain and tenderness, especially if there is no history of weight loss. Haemorrhoids can cause bleeding during bowel movements, but they typically do not cause severe abdominal pain. Ulcerative colitis is a chronic inflammatory bowel disease that can cause abdominal pain and bloody diarrhoea, but it is less likely to present with acute onset of severe pain and tenderness. Additionally, the absence of any history of weight loss makes ulcerative colitis less likely. Therefore, based on the information provided, diverticulitis is the most likely cause of this patient's symptoms.

---
### 329. Question 329
A 35 year old woman was admitted two days ago after taking 32 paracetamol tablets. She has alcohol use disorder. Her weight is 40 kg. She has been treated with a full dose of acetylcysteine

Which investigation best demonstrates restoration of liver synthetic function?

A. Albumin
B. ALT
C. Bilirubin
D. γGT
E. PT

**Answer**: E

**Explanation**: In this scenario, the patient has ingested a potentially toxic amount of paracetamol and has been treated with acetylcysteine, which is the antidote for paracetamol overdose. As a result, the most likely organ affected is the liver, and the investigation that best demonstrates the restoration of liver synthetic function is the prothrombin time (PT). Paracetamol overdose can cause liver damage, which can lead to a decrease in the synthesis of clotting factors by the liver. The PT is a measure of the time it takes for a clot to form in a blood sample, and it is used to assess liver function. An elevated PT indicates impaired liver function, and a prolonged PT is commonly seen in patients with liver damage due to paracetamol overdose. Therefore, monitoring the PT is essential in patients with paracetamol overdose to assess the extent of liver damage and to evaluate the effectiveness of treatment with acetylcysteine. Albumin is a protein synthesized by the liver and is often used as a marker of liver function. However, albumin levels may not show immediate changes in liver synthetic function in the setting of acute liver injury. ALT is an enzyme that is released into the bloodstream when liver cells are damaged. ALT levels can be elevated in patients with liver damage due to paracetamol overdose, but they do not reflect the restoration of liver synthetic function. Bilirubin is a pigment produced by the breakdown of red blood cells and is typically elevated in patients with liver damage. However, it does not reflect the restoration of liver synthetic function. γGT is an enzyme found in liver cells that can be elevated in patients with liver damage. However, it is not a specific marker of liver function, and its levels may remain elevated even after the restoration of liver synthetic function. Therefore, the investigation that best demonstrates the restoration of liver synthetic function in this patient is the prothrombin time (PT).

---
### 330. Question 330
A 64 year old woman has thumping palpitations and says that she sometimes feels her heart 'gives a sudden jump'. Her husband recently died due to myocardial infarction. Her pulse is 70 bpm and BP 136/80 mmHg. Her heart sounds are normal. Her 12-lead ECG is shown in the tracing

[IMAGE: image_330_MLA7_page47_image_47_2.png]

What is the most likely cause of her palpitations?

A. Atrial fibrillation
B. Premature supraventricular beats
C. Premature ventricular beats
D. Sinus arrhythmia
E. Ventricular tachycardia

**Answer**: C

**Explanation**: Premature ventricular beats (aka ventricular ectopic beats) are a common cause of palpitations and may present with thumping palpitations or a sensation of a sudden jump in the heart. Premature supraventricular beats can also present in this way but the ECG shows three broad-complex ectopic beats suggesting a ventricular origin. Premature ventricular beats are caused by early depolarisation of the ventricular tissue leading to an early contraction. The symptoms are usually brief and self-limited, and the patient may not require any specific treatment. However, it is important to exclude underlying cardiac disease. Atrial fibrillation and ventricular tachycardia can also cause palpitations but are less likely in this scenario based on the patient's history, normal physical examination findings and abnormal ECG. Sinus arrhythmia is a normal variation in heart rate that occurs during breathing and is not typically associated with palpitations or sudden jumps in heart rate.

---
### 331. Question 331
A 35 year old man has painless swelling of the right side of his scrotum. The swelling is soft and fluctuant, and transilluminates

What is the most likely diagnosis?

A. Hydrocoele
B. Inguinal hernia
C. Testicular torsion
D. Testicular tumour
E. Varicocoele

**Answer**: A

**Explanation**: Based on the provided information, the most likely diagnosis is hydrocoele. A hydrocoele is a collection of fluid that surrounds the testicle within the tunica vaginalis, causing painless swelling of the scrotum. The swelling is typically soft, fluctuant, and transilluminates when a light is shone on it. This condition can occur at any age, but it is more common in older men. An inguinal hernia may also present as a painless swelling in the scrotum, but it is typically firmer and does not transilluminate. Testicular torsion, on the other hand, is a painful condition that typically presents with sudden onset of severe testicular pain, often accompanied by nausea and vomiting. Testicular tumours may present as a painless testicular mass or swelling, but they are less likely to cause diffuse scrotal swelling. Varicoceles are enlarged veins within the scrotum, but they typically feel like a bag of worms and do not transilluminate.

---
### 332. Question 332
A 67 year old woman has an ulcer with a raised white margin on her left ear. The lesion has been present for 3 years, growing slowly and never completely healing. She spent 20 years living in Australia before returning to the UK recently. She has a small ulcerated area, 4 mm × 6 mm, on her left pinna

What is the most likely diagnosis?

A. Actinic keratosis
B. Basal cell carcinoma
C. Malignant melanoma
D. Seborrhoeic keratosis
E. Squamous cell carcinoma

**Answer**: B

**Explanation**: The history of an ulcerated lesion on the ear in an individual likely to have had a high level of ultraviolet light exposure from living in Australia should raise the possibility of a keratinocyte cancer. Given the long history yet small size of the lesion, together with the description of a raised, pale border make basal cell carcinoma (BCC) the most likely diagnosis. Other characteristic features would be a shiny or ‘pearly’ surface, a rolled edge or overlying telangiectasia. Actinic keratoses are pink and scaly or hyperkeratotic and do not ulcerate. There is no pigmentation to suggest melanoma. Whilst amelanotic melanoma is not completely impossible here, BCC is hugely more common and therefore a much more likely diagnosis. Seborrhoeic keratosis is a harmless warty lesion, which is usually pigmented and does not ulcerate. Squamous cell carcinoma is the other main type of keratinocyte cancer, but is usually red, not pale. It typically grows at a much faster rate than BCC.

---
### 333. Question 333
A 90 year old man has had 3 days of spasmodic suprapubic pain radiating to the tip of the penis. His long-term urinary catheter has recently been changed. He is mildly confused. His temperature is 38.2º C, pulse 88 bpm, BP 146/88 mmHg, respiratory rate 15 breaths per minute and oxygen saturation 96% breathing air. Urinalysis: dark and strong smelling, protein 1+, blood 1+, negative for leucocytes and nitrites

Which factor(s) indicate(s) the need to start antibiotics?

A. Blood and protein in urine
B. Dark strong-smelling urine
C. Fever and mild confusion
D. Presence of pain
E. Recent catheter change

**Answer**: C

**Explanation**: The patient's fever, mild confusion and urinary symptoms suggest the presence of a systemic infection, which could be due to a urinary tract infection (UTI) or catheter-related infection given his recent catheter change. It is therefore important to start antibiotics. The presence of blood and protein in the urine, are not specific to urinary infection and are very commonly associated with indwelling urinary catheters. Blood and protein in the urine could also suggest other renal or urinary tract pathologies. Dark strong-smelling urine is again not specific for urinary infection. Pain could be a symptom of urinary tract pathology, but it does not necessarily indicate the need for antibiotics unless it is associated with other signs of infection. The indications for antibiotics with a catheter change include neutrophils < 1 x 109/L, multiple attempts or traumatic insertion, post trans-urethral urological surgery, previous episode of catheter change related sepsis, frank pus at the urethral meatus or in critical care patients.

---
### 334. Question 334
A 68 year old woman attends her GP with intermittent palpitations. She has diet-controlled type 2 diabetes. Her pulse is 78 bpm, regular. BP 121/77 mmHg

**Investigations:**
Haemoglobin 137 g/L (115–150) eGFR 85 mL/min/1.73m2 (> 60) 24 hour ECG: Normal sinus rhythm with a single episode of irregularly irregular rhythm with absent P waves, and normal QRS complexes lasting 15 minutes. Ventricular rate 110 beats per minute during the episode.

What is the most appropriate initial management?

A. Start apixaban 5 mg twice daily
B. Start aspirin 75mg once daily
C. Start digoxin 125 micrograms once daily
D. Give digoxin 75 micrograms stat
E. Refer for left atrial ablation

**Answer**: A

**Explanation**: This patient has paroxysmal atrial fibrillation. Her CHA2DS2- VASc score is 3 and ORBIT Score is 0. Anticoagulant therapy, such as apixaban, is recommended for patients with atrial fibrillation and a moderate to high stroke risks. Aspirin is not recommended for stroke prevention in atrial fibrillation, and digoxin is used primarily for rate control rather than stroke prevention. Left atrial ablation would only be considered if drug treatment is unsuccessful, unsuitable or not tolerated in people with symptomatic paroxysmal or persistent atrial fibrillation. NICE guideline [NG196] Published: 27 April 2021 Last updated: 30 June 2021 https://www.nice.org.uk/guidance/ng196/chapter/Recommendations

---
### 335. Question 335
A 48 year old man has visible haematuria and right loin pain. His temperature is 37.3°C, pulse 72 bpm and BP 170/97 mmHg. Masses are palpable in both flanks

**Investigations:**
Creatinine 220 µmol/L (60-120) Urinalysis: blood 4+

What is the most appropriate next investigation?

A. CT scan of kidneys, ureters and bladder
B. Cystoscopy
C. MR scan of renal tract
D. Ultrasound scan of renal tract
E. Urine cytology

**Answer**: D

**Explanation**: The most appropriate next investigation is an ultrasound of the renal tract. The patient likely has undiagnosed polycystic kidney disease due to the bilateral renal masses, hypertension (activation of RAAS due to cysts causing reduced renal perfusion), reduced renal function and haematuria. A renal ultrasound will rapidly confirm the presence of cysts. MR scan may be done later to assess renal sizes ahead of possible therapy with vasopressin antagonists. Cystoscopy is not required at this stage and urine cytology would not be of benefit. CT kidney, ureter and bladder would be used in suspected malignancy and urolithiasis.

---
### 336. Question 336
A 35 year old man attends his GP with a severe frontal headache of 12 hours' duration. It started suddenly, reaching maximum intensity within 1 minute. He has associated nausea. At the onset of his headache he noticed a small hole in his vision. This hole started centrally, moved to the edge of his vision and has now resolved. The headache is worse in bright light. Paracetamol has not helped his pain

Which feature should prompt immediate referral to hospital?

A. Abrupt onset
B. Failure to respond to paracetamol
C. Nausea
D. Photophobia
E. Visual disturbance

**Answer**: A

**Explanation**: The case description seems to be of migraine with a surprisingly abrupt onset of headache. It is the abrupt onset of headache is the most worrying feature and suggests a serious underlying cause. Abrupt onset of headache with visual disturbance could be due to subarachnoid haemorrhage (possibly a haemorrhage into the occipital lobe, e.g. from an intracerebral arteriovenous malformation), or haemorrhage into a pituitary macroadenoma with compression of the anterior visual pathway. Other possibilities include reversible cerebral vasoconstriction syndrome, cerebral venous sinus thrombosis or low-pressure headache, though visual disturbance would not be easily explained).

---
### 337. Question 337
A 28 year old man has an insurance medical. His pulse is 72 bpm and BP 210/110 mmHg. There is radiofemoral delay. A systolic murmur is audible on auscultation. Chest X-ray reveals notching of the ribs in the mid-clavicular line

What is the most likely diagnosis?

A. Coarctation of the aorta
B. Dissecting aortic aneurysm
C. Marfan syndrome
D. Renal artery stenosis
E. Takayasu arteritis

**Answer**: A

**Explanation**: The patient's elevated blood pressure, radiofemoral delay, and chest X-ray findings of notching of the ribs in the mid-clavicular line are suggestive of aortic coarctation. Coarctation of the aorta is a congenital defect that results in a narrowing of the aorta, just beyond the origin of left subclavian artery. This can lead to hypertension and other cardiovascular complications. The systolic murmur heard on auscultation may arise from flow across the coarctation itself or associated aortic valve disease. Dissecting aortic aneurysm is less likely, as it typically presents with sudden, severe chest or back pain and is a medical emergency requiring immediate intervention. Marfan syndrome is a genetic disorder that can affect multiple organ systems, including the heart and blood vessels, but typically presents with other clinical features such as joint hypermobility and tall stature. Renal artery stenosis and Takayasu arteritis may also cause hypertension but are less likely given the patient's other clinical findings.

---
### 338. Question 338
A 42 year old woman has two episodes of haemoptysis. She also reports two months of sinusitis with pain, stuffiness and nose bleeds. She has some loosening of her teeth and painful oral ulceration. Previously, she noticed a rash and nodules over her elbows but they have disappeared

**Investigations:**
Chest X-ray: see image Urinalysis: occasional red cell casts

[IMAGE: image_338_MLA7_page56_image_56_2.png]

What is the most likely diagnosis?

A. Behçet disease
B. Granulomatosis with polyangiitis
C. Metastatic nasopharyngeal carcinoma
D. Syphilis
E. Tuberculosis

**Answer**: B

**Explanation**: Granulomatosis with polyangiitis (GPA) is the most likely diagnosis based on the history of sinusitis, oral ulceration and haemoptysis and the bilateral pulmonary nodules on chest X-ray. GPA is a rare autoimmune disease that affects small blood vessels in the body, causing inflammation and tissue damage. The presence of red cell casts in the urinalysis suggests renal involvement, which is also common in GPA. The other conditions listed are less likely to explain the patient's symptoms and findings.

---
### 339. Question 339
A 19 year old man has had a sore throat, malaise and intermittent fever for 2 weeks. His pulse is 74 bpm and BP 115/75 mmHg. His throat is red and tonsils are swollen. His sclerae are yellow-tinged. There are multiple soft palpable lymph nodes in the neck. There is tenderness in the right upper abdominal quadrant

What is the most appropriate diagnostic investigation?

A. Epstein–Barr virus test
B. HIV test
C. Lymph node biopsy for histology
D. Mantoux test
E. Throat swab and culture

**Answer**: A

**Explanation**: Based on the presented information, the most appropriate diagnostic investigation is an Epstein-Barr virus (EBV) test. The clinical features, including sore throat, malaise, intermittent fever, swollen tonsils, yellow-tinged sclerae, and tender lymph nodes, suggest infectious mononucleosis (glandular fever). This is a relatively common disease in the 15 - 25 year old age group and is caused by EBV. Blood tests for antibodies can be used to confirm acute infection once a person has been ill for at least 7 days.

---
### 340. Question 340
A 27 year old woman has had abdominal pain for 48 hours. She also reports recurrent mouth ulcers and altered bowel habit for a few weeks. Her temperature is 37.5°C. She has central abdominal tenderness

**Investigations:**
CT colonoscopy shows a normal appendix with distal small bowel thickening. There are enlarged nodes in the small bowel mesentery.

What is the most likely diagnosis?

A. Crohn ileitis
B. Intestinal tuberculosis
C. Meckel diverticulitis
D. Mesenteric adenitis
E. Small bowel lymphoma

**Answer**: A

**Explanation**: Crohn ileitis is the most likely diagnosis based on the patient's symptoms, findings on CT colonoscopy, and demographic factors. Crohn disease is a chronic inflammatory bowel disease that can affect any part of the gastrointestinal tract, but it most commonly involves the terminal ileum. The patient's symptoms of recurrent mouth ulcers and altered bowel habit are consistent with Crohn disease, and the finding of small bowel thickening with enlarged mesenteric nodes on CT colonoscopy is also suggestive. Intestinal tuberculosis may be considered in the differential diagnosis, but the patient's demographics make this less likely. Meckel diverticulitis and mesenteric adenitis may also be considered, but the lack of a diverticulum or focal lymphadenopathy makes these less likely. Small bowel lymphoma is another possible diagnosis, but the presence of a normal appendix makes this less likely.

---
### 341. Question 341
A 34 year old man has cough and weight loss. A diagnosis of tuberculosis is confirmed and treatment is started. As part of his monitoring, he is screened for loss of visual acuity

Which antituberculosis drug is an indication for visual monitoring?

A. Ethambutol hydrochloride
B. Isoniazid
C. Moxifloxacin
D. Pyrazinamide
E. Rifampicin

**Answer**: A

**Explanation**: Ethambutol hydrochloride is the antituberculosis drug that requires monitoring of visual acuity. Ethambutol can cause optic neuritis, which can lead to impaired colour discrimination, central visual field defects, and blurred vision. Therefore, it is recommended to perform baseline ophthalmologic examination before starting the treatment and periodic monitoring during the treatment, especially in patients with pre-existing visual impairment or renal impairment. The other antituberculosis drugs listed do not require routine ophthalmologic monitoring.

---
### 342. Question 342
A 21 year old woman attends her GP with moderately severe acne. She has tried topical retinoids and topical antibiotics without satisfactory response. She previously had a deep vein thrombosis following a long-haul flight

What is the most appropriate treatment?

A. Co-cyprindiol
B. Desogestrel
C. Flucloxacillin
D. Isotretinoin
E. Lymecycline

**Answer**: E

**Explanation**: The most appropriate treatment next treatment for moderately severe acne in a patient with a history of deep vein thrombosis is Lymecycline. Co-cyprindiol is a form of the oral contraceptive pill (OCP) with anti- androgenic effects, which is licensed for acne. However, it carries a higher risk of thromboembolic disease than other OCPs and is contraindicated here. Desogestrel (when used alone) is a progesterone-only OCP, which may exacerbate acne. Flucloxacillin has no effect on acne. Oral isotretinoin is the most effective treatment for acne but on account of its potential adverse effects is usually reserved for severe or scarring disease or when other treatments – including tetracycline antibiotics – have not been sufficiently effective. NICE guideline [NG198] Published: 25 June 2021 Last updated: 07 December 2023 https://www.nice.org.uk/guidance/ng198/chapter/Recommendations

---
### 343. Question 343
A 45 year old man has had weight loss, fatigue and polyuria for 3 months. He takes a number of multivitamin preparations. Clinical examination is unremarkable

**Investigations:**
Serum corrected calcium 2.9 mmol/L (2.2–2.6) Phosphate 0.82 mmol/L (0.8–1.5) Serum alkaline phosphatase 154 IU/L (25–115) Parathyroid hormone 7.9 pmol/L (1.6–8.5) Serum electrolytes and urea are normal.

What is the most likely diagnosis?

A. Bony metastases
B. Excess calcium intake
C. Primary hyperparathyroidism
D. Sarcoidosis
E. Vitamin D excess

**Answer**: C

**Explanation**: The most likely diagnosis in this case is primary hyperparathyroidism as it is characterised by increased serum calcium and alkaline phosphatase. The parathyroid hormone is only slightly elevated which is still consistent with the diagnosis, as it should be suppressed in the presence of hypercalcaemia. Excess calcium intake and vitamin D excess can also cause hypercalcaemia but they are less likely in this case as the patient does not report any excessive intake of these substances. Bony metastases and sarcoidosis can also cause hypercalcemia, but they would cause a suppressed PTH.

---
### 344. Question 344
A 59 year old man has a 1 year of erectile dysfunction. He has angina, type 2 diabetes mellitus and peripheral vascular disease. He had a thyroidectomy 2 years ago for thyrotoxicosis. He takes aspirin, diltiazem, levothyroxine, metformin, ramipril and simvastatin. His BP is 140/90 mmHg lying and 135/85 mmHg standing. His foot pulses are not palpable. He has normal sensation in his feet

What is most likely to be the main cause of his erectile dysfunction?

A. Adverse effect of medication
B. Autonomic neuropathy
C. Hypothyroidism
D. Testosterone deficiency
E. Vascular insufficiency

**Answer**: E

**Explanation**: Vascular insufficiency is the most likely main cause of erectile dysfunction in this patient. The patient has peripheral vascular disease and similar vascular disease can occur in the penile blood supply. None of his medications is likely to cause erectile dysfunction and there are no clinical features of testosterone deficiency. Autonomic neuropathy can contribute to erectile dysfunction in patients with diabetes but the patient does not have any other features of neuropathic disease. Hypothyroidism can also cause erectile dysfunction, but this is less likely in this patient given that he is on levothyroxine replacement therapy.

---
### 345. Question 345
A 52 year old man has had 3 months of fatigue. He has ulcerative colitis and takes mesalazine. He drinks 20 units of alcohol per week. His temperature is 36.8°C and pulse 80 bpm. He has 3 cm hepatomegaly

**Investigations:**
Albumin 36 g/L (35–50) ALT 65 IU/L (10–50) ALP 580 IU/L (25–115) Bilirubin 18 µmol/L (<17) γGT 230 IU/L (9–40)

What is the most likely diagnosis?

A. Alcoholic hepatitis
B. Cholangiocarcinoma
C. Choledocholithiasis
D. Hepatocellular carcinoma
E. Primary sclerosing cholangitis

**Answer**: E

**Explanation**: The correct answer is Primary Sclerosing cholangitis. He has had non-specific symptoms for a number of months. His liver function test show a cholestatic pattern with a raised ALP. This is an increased incidence of primary sclerosing cholangitis in patients with inflammatory bowel disease. While alcoholic hepatitis is a possibility an alcohol intake of 20 units per week is not high enough to cause significant damage in an otherwise healthy liver. Cholangiocarcinoma and hepatocellular carcinoma are less likely given the short duration of symptoms and lack of specific risk factors, such as viral hepatitis or cirrhosis. Choledocholithiasis may present with elevated liver function tests, but is less likely to cause hepatomegaly or fatigue.

---
### 346. Question 346
A 73 year old man has increasing breathlessness over 1 week. He has chronic kidney disease and ischaemic heart disease. He takes alfacalcidol, aspirin, atorvastatin, bisoprolol fumarate, furosemide and irbesartan. There are bibasal inspiratory crepitations and mild peripheral oedema.

**Investigations:**
Sodium 134 mmol/L (135–146) Potassium 6.7 mmol/L (3.5–5.3) Urea 19 mmol/L (2.5–7.8) Creatinine 259 µmol/L (60–120) eGFR 23 mL/min/173 m2 (>60)

Which drug is most likely to be contributing to his hyperkalaemia?

A. Alfacalcidol
B. Aspirin
C. Bisoprolol fumarate
D. Furosemide
E. Irbesartan

**Answer**: E

**Explanation**: The most likely drug contributing to the patient's hyperkalaemia is irbesartan. Irbesartan is an angiotensin II receptor blocker (ARB) commonly used to treat hypertension, especially in CKD. It leads to reduced aldosterone secretion, which in turn leads to reduced potassium secretion.

---
### 347. Question 347
A 65 year old man is invited to the abdominal aortic aneurysm screening programme. An ultrasound scan shows his abdominal aorta to be 33 mm in diameter

What is the most appropriate management plan?

A. Reassure and discharge
B. Refer for angiography
C. Refer for vascular surgery
D. Repeat ultrasound scan in 12 months
E. Request CT scan of abdomen

**Answer**: D

**Explanation**: Abdominal aortic aneurysm (AAA) is defined as a permanent dilatation of the abdominal aorta with a diameter of 3 cm or more. The risk of AAA rupture increases with increasing diameter. In the UK, screening for AAA is offered to all men aged 65 years and above. The aorta should be measured at three levels: just below the origin of the renal arteries, at the level of the superior mesenteric artery, and just above the bifurcation. Current NICE guidance recommends that if the abdominal aorta measures between 3.0 and 4.4 cm in diameter, then an ultrasound scan should be repeated every year. If the aorta measures between 4.5 and 5.4 cm in diameter, then an ultrasound scan should be repeated every three months. If the aorta measures 5.5 cm or more in diameter, then the patient should be referred for vascular surgery. In this case, as the diameter of the aorta is 33 mm, which is between 3.0 and 4.4 cm, the most appropriate management plan is to repeat the ultrasound scan in 12 months. NHS abdominal aortic aneurysm (AAA) screening programme: care pathway Updated 16 June 2021 https://www.gov.uk/government/publications/abdominal-aortic-aneurysm- screening-care-pathway/nhs-abdominal-aortic-aneurysm-aaa-screening- programme-care-pathway

---
### 348. Question 348
A 28 year old woman has pain on swallowing. She has asthma that is well controlled using metered dose salbutamol and beclometasone dipropionate (800 micrograms/day) inhalers. She has white plaques in her mouth. An anti-fungal oral suspension is prescribed

What is the most appropriate management with regard to her beclometasone?

A. Change beclometasone dipropionate to a dry powder formulation
B. Change beclometasone dipropionate to fluticasone
C. Change beclometasone dipriopionate to salmeterol
D. Take beclometasone dipropionate using a large volume spacer
E. Take salbutamol and beclometasone dipropionate at least 1h apart

**Answer**: D

**Explanation**: This patient has developed oral candidiasis and this is most likely due to local deposition of the inhaled steroid (beclometasone dipropionate). The risk of this happening again can be reduced by using a large volume spacer as there will be less local deposition of the drug in her mouth. Changing to a dry powder or a different steroid inhaler is unlikely to help and may make things worse.

---
### 349. Question 349
A 37 year old man has increasing fever and shortness of breath. He was admitted 3 days ago with left lower lobe pneumonia due penicillin-sensitive Streptococcus pneumoniae. He is receiving intravenous benzylpenicillin 1.2 g four times daily. His temperature is 38.5°C, pulse 100 bpm and BP 122/80 mmHg

**Investigations:**
Chest X-ray: left basal effusion. Diagnostic pleural aspiration: Purulent fluid. Microscopy shows numerous polymorphs and Gram-positive cocci

What is the most appropriate next step in management?

A. Chest drain insertion
B. Increase dose of benzylpenicillin
C. Open thoracostomy
D. Switch benzylpenicillin to ceftriaxone
E. Switch benzylpenicillin to vancomycin

**Answer**: A

**Explanation**: This patient has a fever and an empyema at the left lung base. A chest drain needs to be inserted to allow the purulent fluid to be drained away. The patient is already on appropriate antibiotics for Streptococcus pneumoniae but a discussion with the Microbiology team would still be useful.

---
### 350. Question 350
A 52 year old man has 4 weeks of joint pain, fever and weight loss. He is a non-smoker and has no significant medical history. Examination is unremarkable

**Investigations:**
Calcium 3.12 mmol/L (2.2–2.6) Plasma parathyroid hormone <0.5 pmol/L (0.9–5.4) Chest X-ray shows perihilar lymphadenopathy.

What is the most likely diagnosis?

A. Granulomatosis with polyangiitis
B. Hodgkin lymphoma
C. Primary hyperparathyroidism
D. Sarcoidosis
E. Tuberculosis

**Answer**: D

**Explanation**: The most likely diagnosis is sarcoidosis due to the history, elevated calcium and perihilar lymphadenopathy. The elevated calcium and low parathyroid hormone can occur in sarcoidosis due to increased production of 1,25-dihydroxyvitamin D by activated macrophages in the granulomas. Hodgkin lymphoma and tuberculosis can also cause lymphadenopathy, weight loss and fever but hypercalcaemia is less likely. The normal plasma parathyroid hormone level makes primary hyperparathyroidism less likely. Granulomatosis with polyangiitis may present with joint pain and fever but does not usually cause hypercalcaemia.

---
### 351. Question 351
The daughter of a 78 year old man is concerned about an area of redness on her father's back. He lives alone and spends most of his day sitting in a chair. There is a reddened area over the sacrum, but his skin is intact. He is considered to be at risk of pressure ulcers

Which member of the community multidisciplinary team would be most suited to conduct an initial assessment?

A. Dietician
B. District nurse
C. Occupational therapist
D. Physiotherapist
E. Tissue viability nurse

**Answer**: B

**Explanation**: The district nurse is the most appropriate member of the community multidisciplinary team to conduct an initial assessment of redness over the sacrum in an elderly man who is at risk of pressure ulcers. The district nurse will advise on care planning and give repositioning advice. Tissue viability nurses offer support to district nurses in the management of complex wounds. Dieticians have an important role in the optimisation of patients at risk of pressure damage but would not carry out the initial assessment of an area at risk of further pressure damage. Occupational therapists provide assessment and treatment to those who are finding it difficult to carry out everyday tasks. Physiotherapists support and optimise movement and function in patients.

---
### 352. Question 352
A doctor in training sustains a needle-stick injury while inserting a venous cannula into a patient. The patient has a history of intravenous drug use

What is the most important first action for the doctor in training?

A. Encourage bleeding from the needle-stick injury wound
B. Make an appointment with occupational health
C. Seek post-exposure prophylaxis
D. Test the patient for HIV
E. Get an immediate blood sample taken from themselves

**Answer**: A

**Explanation**: The most important first action is to manage the local skin puncture wound sustained by the doctor in training, so the best answer is to encourage bleeding from the wound. Standard management of the needlestick puncture wound states "puncture wounds should be encouraged to bleed freely, but should not be sucked. Small wounds and punctures may also be cleansed with an antiseptic, for example an alcohol-based hand hygiene solution." Post-exposure prophylaxis for HIV Last revised in March 2025 https://cks.nice.org.uk/topics/hiv-infection-aids/management/post-exposure- prophylaxis/

---
### 353. Question 353
A 32 year old woman has 3 weeks of fever, rigors and lethargy. In the past week, she has also become breathless on exertion. She is an intravenous drug user. Her temperature is 38°C, pulse 100 bpm regular, and BP 100/60 mmHg. Her JVP is raised with predominant V waves. There is a pansystolic murmur at the left sternal edge on inspiration. She has reduced air entry with dullness to percussion at the right lung base. She has swelling of both ankles

What is the most likely pathogen?

A. Enterococcus faecalis
B. Staphylococcus aureus
C. Staphylococcus epidermidis
D. Streptococcus bovis / streptococcus equinus complex
E. Streptococcus viridans

**Answer**: B

**Explanation**: The patient's presentation with fever, rigors, lethargy and breathlessness suggests sepsis. The pansystolic murmur at the left sternal edge heard on inspiration suggests tricuspid regurgitation and thus the most likely diagnosis is tricuspid valve endocarditis. Tricuspid regurgitation is a common complication of right-sided infective endocarditis in intravenous drug users. Staphylococcus aureus is a common pathogen in intravenous drug users and can cause endocarditis, pneumonia, and sepsis. The other organisms listed can all cause endocarditis but are less commonly associated with intravenous drug use-related infections.

---
### 354. Question 354
A 34 year old woman has sudden onset of right arm weakness and inability to speak. She has migraines and generalised joint pains. Four years ago, she had a deep vein thrombosis in her right leg. Her pulse is 68 bpm and BP 178/94 mmHg. She has an expressive dysphasia. She has flaccid weakness of her right arm and facial droop on the right lower half of her face.

**Investigations:**
Haemoglobin 118 g/L (115–150) White cell count 4.3 × 109/L (3.8–10.0) Neutrophils 2.1 × 109/L (2.0–7.5) Lymphocytes 0.6 × 109/L (1.1–3.3) Platelets 132 × 109/L (150–400) Total cholesterol 4.6 mmol/L (<50) CT scan of head left frontoparietal infarct

What additional investigation is most likely to reveal the underlying cause of her stroke?

A. Anti-dsDNA antibody
B. Anticardiolipin antibody
C. Anti-Ro antibody
D. Rheumatoid factor
E. Serum immunoglobulins

**Answer**: B

**Explanation**: The most likely underlying cause of her stroke is a cardioembolic source, possibly related to her history of deep vein thrombosis. Therefore, the most appropriate investigation to reveal the underlying cause of her stroke is anticardiolipin antibody. Anticardiolipin antibodies are a type of antiphospholipid antibody that can cause thrombosis and are associated with an increased risk of stroke. Patients with a history of deep vein thrombosis, like this patient, are at increased risk for the development of anticardiolipin antibodies. Testing for the presence of anticardiolipin antibodies can help confirm the diagnosis of antiphospholipid syndrome, which is an important cause of thrombotic events, including stroke. While the patient's history of migraine and joint pains raise the possibility of an underlying autoimmune disorder, such as systemic lupus erythematosus, the presence of anticardiolipin antibodies is a more specific and relevant investigation in the context of her recent stroke.

---
### 355. Question 355
A 55 year old woman has been feeling tired and sleepy. Her partner says that she snores heavily. She has type 2 diabetes mellitus and takes metformin. Her BMI is 38 kg/m2. Her oxygen saturation is 95% breathing air. Her Epworth sleepiness score is 19 (normal <11). Her HbA1C is 60 mmol/mol (20-42)

What treatment is most likely to improve her daytime somnolence?

A. Bariatric surgery
B. Continuous positive airway pressure ventilation
C. Long acting insulin
D. Mandibular advancement device
E. Modafinil

**Answer**: B

**Explanation**: Based on the patient's clinical presentation and history, the most likely cause of the daytime somnolence is obstructive sleep apnoea (OSA), which is characterised by snoring, excessive daytime sleepiness, and obesity. Continuous positive airway pressure (CPAP) ventilation is the gold standard treatment for OSA and involves using a mask to deliver air pressure to keep the airway open during sleep. It is highly effective in reducing daytime sleepiness, improving quality of life, and reducing the risk of cardiovascular complications associated with untreated OSA. While bariatric surgery may be considered in obese patients with OSA, it is not the first-line treatment for daytime somnolence. Long-acting insulin is also not indicated in this patient. Mandibular advancement devices may be considered in patients with mild to moderate OSA who cannot tolerate CPAP, but they are generally less effective than CPAP. Modafinil is a wake-promoting agent may be used as an adjunctive therapy in patients with residual daytime sleepiness despite optimal CPAP therapy, but it is not a first-line treatment for OSA.

---
### 356. Question 356
A 72 year old man has had six months of increased frequency of defaecation and three months of dark red rectal bleeding mixed with the stool

**Investigations:**
Haemoglobin 101 g/L (130–175) Mean cell haemoglobin (MCH) 24 pg (27–33) MCV 73 fL (80–96) White cell count 9.1 x 109/L (3.0–10.0) Platelets 354 x 109/L (150–400)

What is the most likely diagnosis?

A. Colonic carcinoma
B. Diverticular disease
C. Haemorrhoids
D. Ischaemic colitis
E. Ulcerative colitis

**Answer**: A

**Explanation**: Colonic carcinoma is the most likely diagnosis in this patient with a six-month history of increased frequency of defecation and three months of dark red rectal bleeding mixed with the stool. The low haemoglobin, low MCV, and low MCH suggest that the patient has iron deficiency anaemia, which is commonly associated with colorectal cancer. The other differential diagnoses, such as diverticular disease, haemorrhoids, ischaemic colitis, and ulcerative colitis, may also cause rectal bleeding, but are less likely to present with such a prolonged duration of symptoms and iron deficiency anaemia. A colonoscopy would be required for confirmation of the diagnosis.

---
### 357. Question 357
A 24 year old man is reviewed following a recent orchidectomy. The pathologist's report describes a mass with cystic spaces. Histological examination shows areas of mature cartilage and columnar epithelium

What is the most likely diagnosis?

A. Chondrosarcoma
B. Hamartoma
C. Lymphoma
D. Seminoma
E. Teratoma

**Answer**: E

**Explanation**: The most likely diagnosis in this case is teratoma, as it is a type of germ cell tumour that often contains different types of tissue, including cartilage and epithelium.

---
### 358. Question 358
A 50 year old man has had increasing breathlessness when climbing the stairs. He has no chest pain, wheeze or cough. He has COPD. He takes a salbutamol inhaler several times per day. He used to smoke until 3 months ago and has a 30 pack-year smoking history. His weight is stable and he is otherwise well

**Investigations:**
FEV1 : 75% predicted

What is the most appropriate next step in pharmacological management?

A. Inhaled beclometasone
B. Inhaled tiotropium and salmeterol
C. Nebulised salbultamol and ipratropium bromide
D. Oral prednisolone
E. Oral theophylline

**Answer**: B

**Explanation**: The most appropriate next step in pharmacological management would be inhaled tiotropium and salmeterol. This combination therapy is recommended for patients with COPD who have persistent symptoms despite bronchodilator therapy (such as salbutamol) and who have an FEV1 of less than 80% predicted. Tiotropium is a long-acting anticholinergic bronchodilator, while salmeterol is a long-acting beta-agonist bronchodilator. Together, they work to improve lung function and reduce breathlessness in patients with COPD. Inhaled beclometasone is a corticosteroid inhaler and oral prednisolone is a systemic corticosteroid used for acute exacerbations of COPD rather than chronic management. Nebulised salbutamol and ipratropium bromide is a combination bronchodilator therapy used for acute exacerbations of COPD. Oral theophylline is a bronchodilator that is not typically recommended as a first-line therapy for COPD management. NICE guideline [NG115] Published: 05 December 2018 Last updated: 26 July 2019 https://www.nice.org.uk/guidance/ng115/chapter/Recommendations

---
### 359. Question 359
An 86 year old woman has had three falls in the past 3 months. On each occasion, she describes feeling lightheaded and dizzy prior to falling. She is taking alendronic acid, amlodipine, atorvastatin, metformin and zolpidem tartrate. Her BP is 132/80 mmHg sitting and 138/84 mmHg standing

Which medication is most likely to be contributing to her falls?

A. Alendronic acid
B. Amlodipine
C. Atorvastatin
D. Metformin
E. Zolpidem tartrate

**Answer**: E

**Explanation**: Alendronic acid is a bisphosphonate and is not directly associated with falls. Atorvastatin is an HMG-CoA Reductase inhibitor which is not directly related to falls. Metformin is a biguanide and is not directly associated with falls. Whilst amlodipine can be associated with postural hypotension and subsequent falls this is not the case in this patient who does not have a postural drop in blood pressure on standing. Zolpidem tartrate is the correct answer as it is a non-benzodiazepine hypnotic and sedative and is associated with postural instability and falls.

---
### 360. Question 360
A 45 year old man has had 6 months of tiredness, reduced libido and erectile dysfunction

**Investigations:**
Testosterone 1.8 nmol/L (9.9–27.8) LH 1.2 U/L (1–8) FSH 1.0 U/L (1–12)

What is the most likely cause of his presentation?

A. Anabolic steroid misuse
B. Androgen insensitivity syndrome
C. Congenital adrenal hyperplasia
D. Klinefelter syndrome
E. Pituitary adenoma

**Answer**: E

**Explanation**: Based on the low testosterone and low LH and FSH levels, the most likely cause of his presentation is a pituitary adenoma leading to hypogonadotropic hypogonadism. The pituitary adenoma would suppress the production of LH and FSH, which are required for testosterone production in the testes.

---
### 361. Question 361
A 40 year old man develops sudden breathlessness 5 days after an acute inferior ST-elevation myocardial infarction treated by primary coronary intervention. His pulse is 110 bpm, BP 110/75 mmHg, respiratory rate 22 breaths per minute and oxygen saturation 92% breathing 28% oxygen via Venturi mask. There is a pansystolic murmur at the apex and bibasal inspiratory crackles

What is the most likely cause of this presentation?

A. Acute pulmonary embolus
B. Aortic regurgitation
C. Cardiac tamponade
D. Papillary muscle rupture
E. Pericarditis

**Answer**: D

**Explanation**: Based on the clinical features described, the most likely cause of the presentation is acute heart failure due to papillary muscle rupture as a complication of his recent myocardial infarction. The presence of a pansystolic murmur at the apex suggests mitral regurgitation, which can occur due to the rupture of one of the papillary muscles that anchors the valve leaflets. The bibasal inspiratory crackles suggest pulmonary oedema, which can occur as a result of the increased pressure in the left atrium and pulmonary veins due to the mitral regurgitation. While acute pulmonary embolus, aortic regurgitation, cardiac tamponade, and pericarditis can also cause acute breathlessness, they are less likely in this clinical scenario.

---
### 362. Question 362
A 48 year old man attends the GP surgery with headaches. He has noticed that his hands have become larger, and his facial features have coarsened. More recently, his vision has deteriorated. He has an upper temporal defect in both visual fields

Damage to which structure is the most likely source of his visual problems?

A. Lateral geniculate body
B. Occipital cortex
C. Oculomotor nerve
D. Optic chiasm
E. Optic radiation

**Answer**: D

**Explanation**: This 48-year-old man's presentation suggests acromegaly, which is typically caused by a growth hormone-secreting pituitary adenoma. One of the complications of a pituitary tumour is compression of nearby structures. Given the bitemporal (upper temporal) visual field defect described, this indicates compression of the optic chiasm. When the optic chiasm is compressed, particularly from an inferior approach as with a pituitary tumour, the crossing fibres (those responsible for the peripheral/temporal vision) are primarily affected, leading to a bitemporal field defect.

---
### 363. Question 363
A 42 year old man has a rash on his face, mainly around his chin. The rash started 24 hours ago with a 0.5 cm thin-walled blister that then ruptured, leaving a yellow crusted lesion that has since enlarged and now other similar lesions are appearing in the same area. He is a primary school teacher

What is the most likely causative organism?

A. Escherichia coli
B. Pseudomonas aeruginosa
C. Staphylococcus aureus
D. Streptococcus pyogenes
E. Varicella zoster virus

**Answer**: C

**Explanation**: The description of the eruption fits best with bullous impetigo, although this usually occurs in children. Staphylococcus aureus, is the most common causative organism, although Streptococcus pyogenes can also be responsible for non-bullous impetigo. E. coli is not expected to cause skin infection. Pseudomonas may be found as a coloniser in chronic wounds but does not cause primary cutaneous infection in immunocompetent individuals. Varicella zoster virus causes chicken pox and subsequently shingles, neither of which fit the clinical picture described here.

---
### 364. Question 364
A 48 year old woman has had 3 years of increasing knee pain and reduced physical activity. She has radiologically-confirmed osteoarthritis. She has hypertension and type 2 diabetes. She takes lisinopril, metformin, semaglutide and simvastatin. Her BMI is 48 kg/m2and has not changed despite lifestyle advice and a low calorie diet for the last year

**Investigations:**
Glycated haemoglobin 55 mmol/mol (20-42)

What is the most appropriate management?

A. Intensify lifestyle measures and review in 6 months
B. Prescribe orlistat
C. Refer for bariatric surgery
D. Refer for bilateral knee replacements
E. Start insulin therapy

**Answer**: C

**Explanation**: The patient has severe obesity (BMI > 40 kg/m2) and comorbidities including hypertension and type 2 diabetes, which puts her at high risk for obesity-related complications. Despite lifestyle measures and low calorie diet, she has not been able to achieve significant weight loss. Bariatric surgery is an effective treatment option for obesity in patients with BMI > 40 kg/m2, or BMI > 35 kg/m2 with comorbidities such as diabetes and hypertension. The surgery has been shown to improve weight loss, reduce obesity-related comorbidities, including knee pain, and improve quality of life. https://www.nice.org.uk/guidance/ng246/chapter/Medicines-and-surgery January 2025

---
### 365. Question 365
A 22 year old soldier steps off a cramped military aircraft following a long flight from the UK. She suddenly collapses and hits her head on the ground. While unconscious, she has asynchronous jerking of her limbs for less than 15 seconds. Witnesses say that she looked pale. She regains consciousness within 1 minute

What is the most likely cause of her collapse?

A. Cardiac arrhythmia
B. Epilepsy
C. Hypoglycaemia
D. Pulmonary embolism
E. Vasovagal syncope

**Answer**: E

**Explanation**: The most likely cause of her collapse is vasovagal syncope. The cramped conditions and fatigue during the flight could have caused her to experience a vasovagal response, resulting in a temporary loss of consciousness. The asynchronous jerking of her limbs may have been due to myoclonus, which can occur during syncope. The pallor may be due to a transient decrease in blood pressure during the episode. Pulmonary embolism is a possibility but vasovagal syncope is much more likely. Epilepsy is a possibility but the duration of shaking would be unusually short.

---
### 366. Question 366
A 62 year old man has 2 months of increasing shortness of breath and chest pain. He is now unable to lie flat. For the past 2 weeks, he has also had a productive cough which was flecked with blood on two occasions. He had a myocardial infarction 6 months ago, at which point he stopped smoking. His temperature is 37.1°C, BP 126/66 mmHg, respiratory rate 24 breaths per minute and oxygen saturation 93% breathing air

**Investigations:**
Chest X-ray: moderate right-sided pleural effusion. Pleural aspirate protein content 56 g/L.

What is the most likely underlying diagnosis?

A. Bacterial pneumonia
B. Heart failure
C. Lung cancer
D. Pulmonary embolism
E. Tuberculosis

**Answer**: C

**Explanation**: The most likely underlying diagnosis is lung cancer. The high protein content (56 g/L) in the pleural aspirate indicates an exudative effusion, which more indicative of malignancies like lung cancer. Heart failure and pulmonary embolism can present with similar symptoms, but they are less likely given the chest X-ray and pleural aspirate. Bacterial pneumonia or tuberculosis are also less likely due to a lack of fever.

---
### 367. Question 367
A 55 year old man is referred to the vascular outpatient clinic with bilateral claudication, limiting his walking distance to 10 metres. He smokes. Imaging shows chronic distal aortic and bilateral common iliac occlusive disease

What is the most appropriate surgical intervention?

A. Aortic endarterectomy
B. Aorto-bifemoral bypass graft
C. Aorto-iliac embolectomy
D. Bilateral iliac angioplasty
E. Femoral-to-femoral crossover graft

**Answer**: B

**Explanation**: Chronic distal aortic and bilateral common iliac occlusive disease would make aorto-bifemoral bypass graft the most appropriate surgical intervention. Bypass surgery is offered go people with severe lifestyle‑limiting intermittent claudication when angioplasty has been unsuccessful, or is unsuitable, and imaging has confirmed that bypass surgery is appropriate for the person. Aorto-bifemoral bypass graft involves bypassing the occluded aortic and iliac vessels with a synthetic graft to restore blood flow to the legs. Other surgical options like aortic endarterectomy or aorto-iliac embolectomy may not be suitable for chronic occlusive disease, while bilateral iliac angioplasty and femoral-to-femoral crossover graft may not be adequate for restoring blood flow to the entire leg. Clinical guideline [CG147] Published: 08 August 2012 Last updated: 11 December 2020 https://www.nice.org.uk/guidance/cg147/chapter/recommendations

---
### 368. Question 368
A 65 year old man attends his GP for monitoring of hypertension and ischaemic heart disease. He takes aspirin, atenolol, amlodipine, lisinopril and simvastatin. He has marked ankle swelling

Which drug is the most likely cause of his ankle swelling?

A. Amlodipine
B. Aspirin
C. Atenolol
D. Lisinopril
E. Simvastatin

**Answer**: A

**Explanation**: Some antihypertensive medications, such as calcium channel blockers like amlodipine, can cause ankle swelling as a side effect. Lisinopril is an angiotensin-converting enzyme (ACE) inhibitor used to treat hypertension and heart failure. It is known to cause cough as a side effect. Statins such as Simvastatin and beta blockers such as Atenolol are not known to cause ankle swelling as a side effect.

---
### 369. Question 369
An 85 year old woman was admitted with a stroke three weeks ago. She has urinary incontinence and a long-term urinary catheter in situ. She takes clopidogrel and ramipril. Her temperature is 36.8°C, pulse 85 bpm and BP 134/74 mmHg. A catheter specimen of urine shows >105CFU/mL, mixed growth

What is the most appropriate management?

A. No change in treatment
B. Remove urinary catheter
C. Request antibiotic sensitivities
D. Start oral ciprofloxacin
E. Start oral trimethoprim

**Answer**: A

**Explanation**: Colonisation of urinary catheters with a mixed growth of bacteria is very common, does not usually cause symptoms and is not an infection that needs treatment with antibiotics in most patients. It would be inappropriate to remove the catheter, in this patient with a previous history of incontinence who in addition has had a stroke and will be at increased risk of pressure area damage. There are no indications for antibiotics. Indwelling urinary catheters quickly become colonised with microorganisms after insertion. These microorganisms produce proteins and facilitate the formation of biofilms. These biofilms often make it impossible to eradicate the bacteria with antibiotics.

---
### 370. Question 370
A 28 year old man has a headache, intermittent fever, sore throat and diarrhoea. His temperature is 37.7°C. His fauces are red and there are two small aphthous ulcers on his left buccal mucosa. He also has a maculopapular erythematous rash on his upper trunk, red hands and folliculitis on his chest. His liver and spleen are just palpable and he has mild neck stiffness.

**Investigations:**
Haemoglobin 135 g/L (130–175) White cell count 3.3 x 109/L (3.0–100) Platelets 84 x 109/L (150–400)

What investigation is most likely to lead to a diagnosis?

A. First catch urine microscopy
B. Glandular fever screening test
C. HIV serology
D. Serum antinuclear antibodies
E. Serum toxoplasma gondii IgM antibody titre

**Answer**: C

**Explanation**: The presentation suggests an infection, which is affecting a number of different body regions and systems. The most specific information is the presence of a rash with folliculitis on the chest, which is a prominent feature in late stage HIV infection. Additionally, HIV can explain all of the symptoms, hence the correct answer is HIV serology.

---
### 371. Question 371
A 78 year old woman is found dead at home. At autopsy, the pathologist finds bilateral pneumonia and meningitis. Microscopy of a meningeal swab shows Gram-positive cocci arranged in pairs

What is the most likely causative organism?

A. Candida albicans
B. Neisseria meningitidis
C. Pseudomonas aeruginosa
D. Staphylococcus aureus
E. Streptococcus pneumoniae

**Answer**: E

**Explanation**: The most likely causative organism in this case is Streptococcus pneumoniae. Streptococcus pneumoniae is a Gram-positive coccus that can cause pneumonia and meningitis, particularly in the elderly. The presence of bilateral pneumonia and meningitis, as well as the Gram-positive cocci seen on microscopy, are consistent with this diagnosis. Of the other possible answers, Neisseria meningitidis, Candida albicans and Pseudomonas aeruginosa are not Gram positive cocci. Staph aureus tends to form clusters rather than being arranged in pairs.

---
### 372. Question 372
A 55 year old man attends the GP surgery concerned that he may be a carrier of cystic fibrosis. The condition has just been diagnosed in his 5 year old grandson. He has heard that this is an inherited condition, but no one else in his family has the illness

What is the likelihood that the grandfather is a carrier?

A. 1 in 2
B. 1 in 4
C. 1 in 8
D. 1 in 16
E. 1 in 25

**Answer**: A

**Explanation**: Cystic fibrosis is an autosomal recessive disorder, which means that an individual must inherit two copies of the mutated gene (one from each parent) to develop the disease. If the grandchild is affected, both of his parents must be carriers. The parent of the 5 year old must have received the recessive gene from one of their parents. There is a 50:50 chance that this was the grandfather and 50:50 that it was the grandmother. This means that the likelihood that the grandfather is a carrier is 1 in 2.

---
### 373. Question 373
A 79 year old woman has been repeatedly found wandering at night by her neighbours. This has progressively worsened over 6 months. She is independent in her activities of daily living, although her family do her shopping. She was previously well

Based on the likely diagnosis, what aspect of cognition is likely to show the greatest impairment?

A. Attention
B. Concentration
C. Praxis
D. Registration of information
E. Short-term memory

**Answer**: E

**Explanation**: The scenario describes a patient with symptoms of dementia, and impairment of short-term memory is a characteristic feature of dementia. The patient's wandering behaviour may be due to disorientation caused by forgetfulness or confusion. Attention, concentration, and praxis may also be affected in dementia, but short-term memory is often the most severely impaired.

---
### 374. Question 374
A 52 year old woman has increased urinary frequency, urgency and urge incontinence. She has multiple sclerosis, which affects her walking. A midstream urine sample shows no cells and is sterile on culture. A bladder scan shows a residual volume of 300 mL. Urodynamic assessment shows that she has a neuropathic bladder

What is the most appropriate management?

A. α-Adrenoceptor blocker
B. Anticholinergic drug
C. Indwelling urethral catheter
D. Intermittent self catheterisation
E. Suprapubic catheter

**Answer**: D

**Explanation**: The most appropriate management in this case of a patient with a neuropathic bladder due to multiple sclerosis would be intermittent self- catheterization. Drug interventions are unlikely to be of benefit. Indwelling urethral catheter or suprapubic catheter are to be avoided due to increase infection risk.

---
### 375. Question 375
An 84 year old man develops profuse diarrhoea whilst in hospital. An outbreak of Clostridioides (Clostridium) difficile has occurred in his ward

Which feature of this organism makes it particularly difficult to destroy?

A. Motility
B. Outer capsule
C. Rapid mutation
D. Spore formation
E. Surface adherence

**Answer**: D

**Explanation**: The feature of Clostridioides difficile that makes it particularly difficult to destroy is spore formation. C. difficile spores are resistant to many environmental stresses, including heat, disinfectants, and antibiotics, which makes them particularly difficult to eliminate. These spores can persist on surfaces for months, making them a significant source of transmission in healthcare settings.

---
### 376. Question 376
A 40 year old man was admitted with central crushing chest pain. He has pale cream coloured nodules on both elbows and medial aspects of his upper eyelids. ECG on admission showed ST elevation and T wave inversion. He deteriorated and died. A post mortem examination is performed and shows very severe narrowing of the anterior descending branch of the left coronary artery

What is the most likely causative mechanism?

A. Atheroma
B. Arterial dissection
C. Malignant deposit
D. Thrombosis
E. Vasculitis

**Answer**: A

**Explanation**: The most likely causative mechanism of the severe narrowing of the anterior descending branch of the left coronary artery is atheroma, given the patient's clinical presentation of central crushing chest pain, ST elevation and T wave inversion on ECG, and subsequent deterioration and death and the post mortem findings. The presence of pale cream coloured nodules on both elbows and medial aspects of the upper eyelids suggests the possibility of xanthomas, which are associated with hyperlipidemia and can be seen in patients with atheromatous plaques. However, thrombosis on the atheroma is likely to cause the acute presentation and fatal outcome. Arterial dissection, malignant deposits, and vasculitis are less likely causes in this clinical scenario.

---
### 377. Question 377
A 60 year old man has 6 months of dry cough and increasing shortness of breath on effort. He was previously fit and well, and does not smoke. His temperature is 36.8°C, pulse 60 bpm and oxygen saturation 89% breathing air. He has finger clubbing. Cardiac examination is normal, and chest examination reveals bibasal crepitations

What is the most likely diagnosis?

A. Bronchiectasis
B. Extrinsic allergic alveolitis
C. Idiopathic pulmonary fibrosis
D. Lung carcinoma
E. Pulmonary tuberculosis

**Answer**: C

**Explanation**: All of the answers are possible causes of cough, finger clubbing and increasing breathlessness but Idiopathic Pulmonary Fibrosis (IPF) is most likely. The dry cough, increasing shortness of breath on exertion, hypoxia, finger clubbing and bibasal crepitations are all in keeping with IPF. Lung cancer is less likely as the patient is a non-smoker and the signs are bilateral in the chest. Extrinsic allergic alveolitis is a possible correct answer but it is less common than IPF and it is usually associated with a history of exposure to a specific antigen. Pulmonary TB is less likely as there is no fever, the cough is dry and the signs are bibasal. Bronchiectasis is a suppurative lung disease which means it presents with a productive cough with large volumes of sputum and this case has a dry cough so it is unlikely.

---
### 378. Question 378
A 65 year old man attends the anticoagulant clinic. He has had a metal mitral valve replacement and atrial fibrillation. He takes warfarin 7 mg daily. His pulse is 70 bpm, irregularly irregular, with a mechanical second heart sound. There are no signs of bleeding. His INR is 5.1

What is the most appropriate next step in management?

A. Continue warfarin at lower dose
B. Continue warfarin at same dose
C. Give vitamin K intravenously
D. Give vitamin K orally
E. Withhold warfarin for 2 days then restart at lower dose

**Answer**: E

**Explanation**: It is important to maintain a therapeutic INR to avoid thromboembolism from both the metallic valve and atrial fibrillation. However, we also have to manage the risk of bleeding. With the INR of 5.1 there is a risk of bleeding which can be catastrophic if affecting vital organs such as the brain. In this situation with no bleeding, it is safe to withhold the warfarin for 2 days to allow it to reduce naturally and then perhaps start at a lower dose of warfarin than before. Not stopping warfarin runs the risk that the INR fails to fall with a risk of bleeding (A and B wrong). Reducing the INR too quickly with vitamin K (IV or oral) in the absence of bleeding, can lead to the development of thromboembolisms occurring and also challenges in maintaining future therapeutic levels (requirement for SC heparin).

---
### 379. Question 379
A 55 year old man is rescued from a collapsed building where he has been trapped for 12 hours without water. His temperature is 35.6°C, pulse 100 bpm and BP 90/42 mmHg. His JVP is not visible. His abdomen is non tender

**Investigations:**
Haemoglobin 168 g/L (130–175) Sodium 148 mmol/L (135–146) Potassium 6.0 mmol/L (3.5–5.3) Urea 25.1 mmol/L (2.5–7.8) Creatinine 184 μmol/L (60–120) Creatine kinase 840 U/L (25–200)

What is the most likely cause of this biochemical picture?

A. Bladder outflow obstruction
B. Direct renal trauma
C. Hypovolaemia
D. Rhabdomyolysis
E. Sepsis

**Answer**: C

**Explanation**: The most likely cause is acute kidney injury due to hypovolaemia. The observations of tachycardia and hypotension fit this. There are no signs of sepsis or reason why this has developed. The creatine kinase is only minimally elevated and would normally be >1,000 to be considered rhabdomyolysis, which until around 5,000U/L would be considered mild.

---
### 380. Question 380
A 56 year old man has had a single episode of painless visible haematuria. He has no other urinary symptoms and is otherwise fit and well. He has smoked ten cigarettes per day for the past 35 years. His BP is 140/85 mmHg. Urinalysis performed after this episode shows blood 2+, no protein and no nitrites.

**Investigations:**
Urea 6.5 mmol/L (2.5–78) Creatinine 95 µmol/L (60–120) Urine culture: no growth

What investigation is most likely to confirm the diagnosis?

A. Flexible cystoscopy
B. Serum prostate specific antigen
C. Transrectal ultrasound scan of prostate
D. Ultrasound scan of kidneys
E. Urine cytology

**Answer**: A

**Explanation**: A single episode of painless visible haematuria in a smoker is concerning for bladder cancer. Cystoscopy will enable visualisation and biopsy of any lesion in the bladder wall.

---
### 381. Question 381
A 81 year old man has three months of malaise, bleeding gums and pain in his legs. He has been struggling to look after himself since his wife died one year ago. He has a poor diet and reports that he mostly has tea and toast. He has gingival hypertrophy and skin petechiae

What micronutrient deficiency is most likely to account for his symptoms?

A. Magnesium
B. Vitamin A
C. Vitamin B1
D. Vitamin C
E. Zinc

**Answer**: D

**Explanation**: This is typical of vitamin C deficiency which presents with a petechial rash and gum changes. It is still seen in UK in people with poor diets. https://bestpractice.bmj.com/topics/en-gb/632

---
### 382. Question 382
A 24 year old man is admitted to hospital with an exacerbation of asthma. His symptoms improve with treatment, and he is ready for discharge after 24 hours. His discharge medication includes a combined beclometasone and salmeterol inhaler, and a short course of oral prednisolone

What further management must be provided prior to discharge?

A. Antibiotic rescue pack
B. Course of antihistamines
C. Nebuliser machine for use at home
D. Personalised asthma action plan
E. Volumatic spacer device

**Answer**: D

**Explanation**: A personalised asthma action plan should be provided prior to discharge. It is a written plan that outlines the patient's daily management of asthma and how to adjust treatment in response to worsening symptoms or changes in lung function. It is an essential tool for patients with asthma to ensure that they can manage their condition effectively and prevent future exacerbations. Antibiotic rescue packs and antihistamines are not routinely prescribed for asthma management. Nebuliser machines and Volumatic spacer devices may be prescribed as needed, but a personalised asthma action plan is a more crucial component of long-term asthma management. NICE Guidelines Asthma Quality standard [QS25] Last updated: 20 September

---
### 383. Question 383
A 79 year old woman has 6 months of increasing breathlessness on exertion. Her pulse is 72 bpm, irregularly irregular, and BP 118/72 mmHg. She has a low-pitched, mid-diastolic murmur best heard at the apex in expiration

What is the most likely cause of her murmur?

A. Aortic regurgitation
B. Aortic stenosis
C. Hypertrophic cardiomyopathy
D. Mitral regurgitation
E. Mitral stenosis

**Answer**: E

**Explanation**: Based on the location, intensity and timing of the murmur, the most likely cause is Mitral stenosis. Most patients with mitral stenosis have a severely dilated left atrium due to the valve stenosis, and are therefore often in atrial fibrillation at presentation. Aortic regurgitation also causes an diastolic murmur best hear in expiration, but this is usually high pitched and in early in diastole, and is best heard down the left sternal edge. All the other options result in SYSTOLIC murmurs. The murmur of HCM is similar to that of aortic stenosis, as it is usually secondary to left ventricular outflow tract turbulence causes by a hypertophic basal interventricular septum.

---
### 384. Question 384
A 43 year old woman is admitted with acute right upper quadrant pain, which radiates to her right shoulder. Her temperature is 38.6°C and respiratory rate 20 breaths per minute. She is tender to palpation in the right upper quadrant but has no rebound tenderness

**Investigations:**
Haemoglobin 132 g/L (115–150) White cell count 13 x 109/L (3.8–10.0) Platelets 340 x 109/L (150–400) Bilirubin 30 µmol/L (<17) Alanine aminotransferase (ALT) 80 IU/L (10–50) Alkaline phosphatase 306 IU/L (25–115)

What is the next most appropriate radiological test?

A. Abdominal X-ray
B. CT scan of abdomen
C. Erect chest X-ray
D. MR scan of abdomen
E. Ultrasound scan of abdomen

**Answer**: E

**Explanation**: The symptoms and signs suggest acute cholecystitis for which the most appropriate radiological test is an ultrasound scan of the abdomen. Most gall stones are not radio-opaque and therefore do not show on plain films so am abdominal C ray would likely not prove or disprove this potential diagnosis, An erect CXR would be more useful to exclude air under the diaphragm consistent with perforated ulcer which might be considered if there were signs of peritonitism but there is no rebound tenderness to suggest this. A CT or MRI might show signs of cholecystitis but would not be the next investigation, given that ultrasound is more effective use of finite resource and unlike CT would not involve exposure to significant doses of ionising radiation.

---
### 385. Question 385
A 41 year old man is admitted with an acute myocardial infarction. His father died of a myocardial infarction aged 52 years

**Investigations:**
Fasting glucose 8.2 mmol/L (3.0–6.0) Cholesterol (fasting) 9.2 mmol/L (3.5–6.5) Triglycerides (fasting) 1.9 mmol/L (<2.3) HDL cholesterol 1.0 mmol/L (>1.2)

What is the most likely cause of his hyperlipidaemia?

A. Chylomicronaemia
B. Diabetes mellitus
C. Familial combined hyperlipidaemia
D. Heterozygous familial hypercholesterolaemia
E. Polygenic hypercholesterolaemia

**Answer**: D

**Explanation**: This is because the commonest genetic lipid disorder listed which would give this profile.

---

### 386. Question 386
A 25 year old man has had penile pain for two days. His most recent sexual intercourse was one week ago. There are multiple tender ulcers on his preputial skin. His penile and scrotal skin does not have any other abnormality

Which is the most likely diagnosis?

A. Genital warts
B. Gonorrhoea
C. Herpes simplex
D. Lymphogranuloma venereum
E. Syphilis

**Answer**: C

**Explanation**: Based on the given information, the most likely diagnosis is Herpes simplex. The presence of multiple tender ulcers on the preputial skin following recent sexual intercourse is suggestive of herpes simplex virus infection. Genital warts usually present as painless, raised, and cauliflower-like growths on the genital skin. Ulcers in syphilis are typically painless, whilst gonorrhoea presents with discharge. In lymphogranuloma venerum discharge and lymphadenopathy is often present.

---
### 387. Question 387
A 60 year old man has increasing left hip pain. It is worse after exercise and occasionally wakes him at night. He has stiffness in the mornings that lasts for about 10 minutes. He has hypertension treated with ramipril, but is otherwise in good health. He has reduced internal rotation on passive movement. This also elicits pain

Which is the most appropriate initial treatment for his pain?

A. Celecoxib
B. Codeine phosphate
C. Naproxen
D. Paracetamol
E. Tramadol

**Answer**: C

**Explanation**: Oral non-steroidal anti-inflammatory drugs are recommended as initial pharmacotherapy for hip osteoarthritis. Paracetamol or weak opioids should not be routinely offered unless they are only used infrequently for short-term pain relief and all other pharmacological treatments are contraindicated, not tolerated or ineffective. NICE guideline [NG226] Published: 19 October 2022 https://www.nice.org.uk/guidance/ng226/chapter/Recommendations

---
### 388. Question 388
An 18 year old woman is 19 weeks pregnant. An ultrasound scan shows her baby has anencephaly. She wants to discuss her options with regards to termination of pregnancy

When will termination of this pregnancy be legally permitted?

A. After spontaneous fetal death
B. At any time during the pregnancy
C. Before 20 weeks' gestation
D. Before 24 weeks' gestation
E. Before 28 weeks' gestation

**Answer**: B

**Explanation**: The law in the UK is that the usual limit for termination of pregnancy is 24 week’s gestation. However, anacephaly is a fetal anomaly that inevitably results in the death of the fetus. This, or a risk of serious harm to the woman, means that termination is legal at any time.

---
### 389. Question 389
A 65 year old man has had constant back and right knee pain for 6 months, partially relieved by analgesia. He is an ex-smoker. He is otherwise well

**Investigations:**
Haemoglobin 132 g/L (130-175) Alkaline phosphatase 850 IU/L (25-115) Calcium 2.3 mmol/L (2.2-2.6) Phosphate 0.9 mmol/L (0.8-1.5) Prostate specific antigen 5 μg/L (<4.0) X-rays: sclerotic areas in lower right femur and lumbar spine L3 Isotope bone scan: areas of increased uptake in femur, lumbar spine and skull

Which is the most likely diagnosis?

A. Hyperparathyroidism
B. Metastatic carcinoma of prostate
C. Metastatic small cell carcinoma of lung
D. Myeloma
E. Paget's disease of bone

**Answer**: E

**Explanation**: Based on the given information, the most likely diagnosis is E. The patient’s history, investigations and imaging findings suggest a diagnosis of Paget’s disease of bone. The elevated alkaline phosphatase, with normal Calcium and Phosphate and bone scan results support this diagnosis. Hyperparathyroidism can cause hypercalcemia and bone resorption, but it is less likely in this case given the normal calcium and phosphate levels. Metastatic small cell carcinoma of lung, prostate and myeloma can also cause the imaging changes, but these are less likely given the patient’s history, and laboratory findings.

---
### 390. Question 390
A 14 year old girl has had crampy abdominal pain and poor appetite for 24 hours. She has also had a sore throat for 3 days. Her temperature is 38.5°C. There is cervical lymphadenopathy and tenderness in the right iliac fossa

Which is the most likely diagnosis?

A. Acute appendicitis
B. Crohn's ileitis
C. Meckel's diverticulum
D. Mesenteric adenitis
E. Ovarian cyst

**Answer**: D

**Explanation**: Based on the given information, the most likely diagnosis is Mesenteric adenitis. The patient’s symptoms, including crampy abdominal pain, poor appetite, sore throat, fever, cervical lymphadenopathy, and tenderness in the right iliac fossa, suggest mesenteric adenitis, which is an inflammation of the lymph nodes in the mesentery that can be caused by viral or bacterial infections, such as streptococcal pharyngitis. Acute appendicitis can also cause right lower quadrant pain and tenderness, but it typically presents with more severe pain, rebound tenderness, and migration of pain from the periumbilical region to the right iliac fossa. Crohn’s ileitis and Meckel’s diverticulum are less likely given the patient’ s age and symptoms, and ovarian cyst typically presents with unilateral pelvic pain or mass. The patient should be evaluated by her healthcare provider and may require further testing, such as blood tests and imaging, to confirm the diagnosis and rule out other conditions.

---
### 391. Question 391
The links between deprivation and health inequalities are well evidenced and widely accepted, but there are a number of explanations for that association. One explanation proposes that ill health determines people's social class

Which type of explanation of health inequality is this?

A. Artefact
B. Cultural/behavioural
C. Idealist
D. Materialist
E. Social selection/mobility

**Answer**: E

**Explanation**: This is an example of Social selection/mobility. This explanation proposes that ill health can limit social mobility due to decreased ability to work, and decreased income, leading to lower social class, which in turn can contribute to health inequalities. Artefact would be proposing that the observed differences are due to differences in measurement (and so not actually present). Cultural/behavioural is proposing that differences in behaviour cause differences in health. Idealist would be suggesting that individuals’s construction of health is different in different groups, so they might define health differently, and Materialist, emphasises the role of economic and social factors, such as income, education, and employment, in shaping health outcomes.

---
### 392. Question 392
A 19 year old man has 1 day of fever, muscle stiffness, palpitations and difficulty breathing. He has a psychotic depression. He has been taking fluoxetine for 6 weeks and started taking risperidone 1 week ago. He is agitated and distressed. His temperature is 39.8°C, pulse is 114 bpm, BP 172/89 mmHg and respiratory rate 30 breaths per minute. Chest examination is otherwise normal. There is increased tone globally; there are no other neurological abnormalities

Which test is most likely to help confirm the diagnosis?

A. CT scan of head
B. ECG
C. EEG
D. Lumbar puncture
E. Serum creatine kinase

**Answer**: E

**Explanation**: The symptoms described in the scenario suggest the possibility of neuroleptic malignant syndrome (NMS), a rare but potentially life-threatening side effect of antipsychotic medication. The most appropriate test to help confirm the diagnosis in this case would be E. Serum creatine kinase (CK), which is a muscle enzyme that can be elevated in NMS. Imaging tests such as CT scan of head or lumbar puncture are unlikely to provide useful information in this case, as the patient’s symptoms and physical examination findings suggest a systemic rather than neurological problem. ECG and EEG may be useful in ruling out other possible causes of the patient’s symptoms, such as cardiac or seizure disorders, but are unlikely to be diagnostic for NMS.

---
### 393. Question 393
A 43 year old man is involved in a low speed road traffic collision. Following this, he develops pain in his lower back that it is still troublesome several months later. The pain is worse after activity and is relieved by rest. He has an exaggerated lumbar lordosis with a palpable depression above L5. The range of movement of his spine is grossly normal. Neurological examination of his lower limbs is also normal. An MR scan is obtained (see image)

[IMAGE: image_393_MLA8_page9_image_9_2.png]

What is the diagnosis?

A. Cauda equina syndrome
B. Compression fracture
C. Herniated intervertebral disc
D. Spondylolisthesis
E. Spondylosis

**Answer**: D

**Explanation**: Spondylolisthesis is a condition where one vertebra slips out of line with the one above it, most commonly in the lumbar spine. The exaggerated lumbar lordosis and the palpable depression above L5 can be clinical findings of spondylolisthesis. Symptoms include lower back pain that worsens with activity and improves with rest. Neurological examination is typically normal.

---
### 394. Question 394
A 30 year old man goes out gambling. One night he makes a profit of £100,000, and the following night he loses £150,000

Which psychological process most likely occurred on the first night that led to his risk taking on the following night?

A. Classical conditioning
B. Disinhibition
C. Modelling
D. Positive reinforcement
E. Social learning

**Answer**: D

**Explanation**: This is because winning on the first night positively reinforced his gambling behaviour - hence his repetition on the following night.

---
### 395. Question 395
A 85 year old woman has a breast lump. She has hypertension, heart failure and a previous stroke. She takes bisoprolol, ramipril, furosemide, aspirin and atorvastatin. Her pulse is 76 bpm irregularly irregular and BP 105/70 mmHg. Her jugular venous pressure is visible 6 cm above the sternal angle. She has bibasal late inspiratory crepitations and bilateral pedal oedema. There is a 2.5 cm diameter, mobile, firm, non tender swelling in the upper outer quadrant of the her breast. There is no palpable lymphadenopathy. An ultrasound guided core biopsy was taken from the mass

**Investigations:**
Pathology report of breast biopsy: infiltrating ductal carcinoma, ER positive , HER2 negative She is started on an aromatase inhibitor and bisphosphonate.

Which is the most appropriate next treatment to offer?

A. Chemotherapy
B. Immunotherapy
C. No additional treatment
D. Radiotherapy
E. Surgery

**Answer**: C

**Explanation**: Given the patient’s age and comorbidities, surgery may not be a suitable option. The pathology report indicates that the breast cancer is ER positive, which suggests that the tumor may be responsive to hormone therapy. Therefore, the most appropriate next treatment to offer would be hormone therapy with an aromatase inhibitor, which has been already started, and a bisphosphonate, which is used to prevent bone loss associated with hormone therapy. Chemotherapy and immunotherapy may not be appropriate for this patient given her age and comorbidities. Radiotherapy may be considered in certain cases, but it is not the most appropriate next treatment to offer in this scenario. Therefore, the answer is no additional treatment.

---
### 396. Question 396
A 29 year old woman attends her GP with a heavy sensation in her vagina when exercising. She is aware of a bulge in her vagina, sometimes associated with a desire to void urine. She had a vaginal delivery 2 years ago. There is some laxity of the anterior vaginal wall, but this does not descend to the introitus on straining. Urine culture is negative

Which is the most appropriate management plan?

A. Oxybutinin hydrochloride
B. Pelvic floor exercises
C. Refer for urodynamic testing
D. Refer to urogynaecology clinic
E. Ultrasound scan of pelvis

**Answer**: B

**Explanation**: The most appropriate management plan for this patient with symptoms of pelvic organ prolapse is pelvic floor exercises from the physiotherapists. The GP has examined the patient and she has a first degree anterior prolapse. The physios will also make a further assessment including a thorough examination of the pelvic floor, to establish the extent of the prolapse and any associated symptoms. This will inform the choice of treatment, which will nearly always include conservative measures such as pelvic floor exercises. Referral to urogynaecology clinic is usually needed if there is a severe prolapse e.g. 3rd degree or severe urinary bowel incontinence or failed PFEs when management may include more invasive options such as surgical repair. Oxybutinin hydrochloride is used in the management of urgency urinary incontinence, which is not the main symptom in this patient. Pelvic floor exercises can be recommended as part of the management of pelvic organ prolapse, but in the absence of a full assessment and diagnosis, their effectiveness may be limited. Urodynamic testing and ultrasound scan of the pelvis may be considered as part of the overall management plan, but only if referral to a specialist clinic is needed.

---
### 397. Question 397
A 29 year old woman has pain and morning stiffness in her finger and wrist joints. This improves during the day and after active movement. She has had recurrent mouth ulcers for the last 2 years. She had an episode of pleuritic chest pain 6 months ago which resolved without seeking help. Her BP is 128/85 mmHg. She has no warmth or tenderness in her hands

**Investigations:**
Haemoglobin 109 g/L (115–150) White cell count 3.8 × 109/L (4.0–11.0) Lymphocytes 0.9 × 109/L (1.1–3.3) Platelets 160 × 109/L (150–400) Creatinine 90 µmol/L (60–120) CRP 21 mg/L (< 5) Urinalysis: protein 1+, blood 1+

Which is the most likely diagnosis?

A. Behçet's disease
B. Reactive arthritis
C. Rheumatoid arthritis
D. Sjögren's syndrome
E. Systemic lupus erythematosus

**Answer**: E

**Explanation**: Based on the symptoms and investigations provided, the most likely diagnosis is systemic lupus erythematosus (SLE). The patient has joint pain and morning stiffness, which are common symptoms of SLE. She also has a history of mouth ulcers and pleuritic chest pain, which are other features that may be seen in SLE. The urinalysis shows proteinuria and haematuria, which can be associated with lupus nephritis. The low haemoglobin level and lymphopenia may also be seen in SLE. The elevated CRP suggests an underlying inflammatory process. Patients with Behcet’s syndrome experience ulceration and joint pain but renal involvement and haematological changes are less likely. Patients with Rheumatoid arthritis and reactive arthritis would have inflamed joints. Patients with Sjogrens syndrome usually have normal CRP.

---
### 398. Question 398
A 66 year old man has lethargy, cough and a persistent pain in the right upper quadrant of the abdomen. He has smoked between 15 and 40 cigarettes daily for 50 years. He has an enlarged liver. Needle biopsy of the liver reveals adenocarcinoma, and immunohistochemistry is positive for the marker thyroid transcription factor-1, indicative of a primary pulmonary tumour

Which is the most likely route by which this tumour spread to the liver?

A. Direct infiltration
B. Haematogenous spread
C. Lymphatic spread
D. Pagetoid spread
E. Transcoelomic spread

**Answer**: B

**Explanation**: The presence of a thyroid transcription factor- 1 marker in the liver biopsy suggests that the adenocarcinoma originated from the lung, rather than the liver. Adenocarcinomas of the lung often metastasise to the liver through the bloodstream, making haematogenous spread the most likely route. Direct infiltration would be less likely due to the distance between the lung and liver, while lymphatic, Pagetoid, and transcoelomic spread are less common routes of metastasis for lung cancer to the liver.

---
### 399. Question 399
A 63 year old woman has two days of facial swelling, early morning facial discomfort and fullness. Nine months ago she was treated with chemotherapy and radiotherapy for lung cancer. Her jugular venous pressure is elevated and non pulsatile. Her face, neck and arms are swollen, and there are prominent veins across her chest

Which structure is most likely to be occluded?

A. Axillary vein
B. Internal jugular vein
C. Right atrium
D. Subclavian vein
E. Superior vena cava

**Answer**: E

**Explanation**: Superior vena cava is the most likely structure to be occluded. The patient’s symptoms of facial swelling, fullness, and prominent chest veins are consistent with superior vena cava syndrome, which can occur when the SVC is compressed or obstructed. The previous history of lung cancer and recent chemotherapy and radiotherapy suggest the possibility of SVC obstruction due to malignancy.

---
### 400. Question 400
A 45 year old man attends his GP with right knee pain. He has had no previous problems with his knee before. He has had previous episodes of a severe pain in his toe and painful swelling of the dorsum of the feet. There is no history of trauma. He drinks 20 pints of beer a week. His temperature is 37.5°C, and his knee is warm, diffusely tender and very painful to flex

What is the most likely diagnosis?

A. Gout
B. Osteoarthritis
C. Rheumatoid arthritis
D. Septic arthritis
E. Torn meniscal cartilage

**Answer**: A

**Explanation**: Based on the presentation, the most likely diagnosis is gout. The presence of a warm, diffusely tender and very painful knee, along with a previous history of acute inflammation in the feet and alcohol excess would be consistent with a diagnosis of gout.

---
### 401. Question 401
A 68 year old woman has noticed a lump in her neck for 2 months. She otherwise feels well. There are small lymph nodes palpable in the cervical, axillary and inguinal regions

**Investigations:**
Haemoglobin 124 g/L (115–150) White cell count 27.2 × 109/L (3.8–10.0) Neutrophils 2.5 × 109/L (2.0–7.5) Lymphocytes 21.6 × 109/L (1.1–3.3) Monocytes 0.9 × 109/L (0.2–1.0) Eosinophils 0.4 × 109/L (0–0.4) Basophils 0.1 × 109/L (0–0.1) Platelets 137 × 109/L (150–400) Blood film: increased lymphocytes with sparse cytoplasm

Which is the most likely diagnosis?

A. Acute lymphoblastic leukaemia
B. Chronic lymphocytic leukaemia
C. Infectious mononucleosis
D. Myeloma
E. Non Hodgkin's lymphoma

**Answer**: B

**Explanation**: The most likely diagnosis is Chronic Lymphocytic Leukaemia as it is the commonest lymphoproliferative neoplasm causing a lymphocytosis in this age of patient (lifetime risk approx. 1 in 200) and the patient is otherwise well (approx. 75% of CLL diagnosis are in >65 year olds and the average age of presentation is 70 years). The lymphocytosis with normal Hb, neutrophil count and near normal platelet count and the film appearances (small mature lymphocytes and smear cells are common) are also consistent. Low grade Non Hodgkin's lymphoma is the main differential diagnosis of painless persistent lymphadenopathy in this age group and is also common but is less likely to present with significant lymphocytosis (lymphadenopathy is more of a feature). Infectious mononucleosis is caused by the Epstein-Barr virus and can also present with lymphadenopathy with lymphocytosis although these are reactive lymphocytes with plenty of cytoplasm. EBV also typically presents with fever and sore throat, and it is a self-limited condition and resolves within weeks. Acute lymphoblastic leukaemia is a malignancy of lymphoid progenitor cells that primarily affects children and young adults and is typically associated with a short history of bone pain, fever and pancytopenia. Myeloma is a malignancy of plasma cells within the bone marrow, which can present with bone pain, hypercalcaemia, anaemia, and renal dysfunction. Myeloma does not cause lymphadenopathy or lymphocytosis.

---
### 402. Question 402
A randomised controlled trial was designed to compare a new drug with a placebo. There were 120 patients in the treatment group of which 12 patients died within 2 years. There were 240 patients in the control group of which 48 patients died within 2 years

Which is the number needed to treat to avoid one death within 2 years?

A. 2
B. 4
C. 8
D. 10
E. 20

**Answer**: D

**Explanation**: The absolute risk reduction (ARR) can be calculated as the difference in the risk of death between the treatment and control groups: ARR = risk in control group - risk in treatment group ARR = 48/240 - 12/120 ARR = 0.2 - 0.1 ARR = 0.1 The number needed to treat (NNT) can be calculated as the reciprocal of the ARR: NNT = 1 / ARR NNT = 1 / 0.1 NNT = 10 Therefore, the NNT to avoid one death within 2 years is 10.

---
### 403. Question 403
A 62 year old woman is seen at home because her legs feel "wobbly". She has been incontinent of urine once. She has been experiencing increasing pain in her mid back over the previous fortnight. She is being treated for metastatic breast cancer with anastrozole. There is slight weakness, rated 4/5, in hip flexion and knee extension bilaterally. Plantar reflexes are equivocal and tendon jerks brisk. She is tender over the 10th thoracic vertebra

Which is the most appropriate next course of action?

A. Admission to the local hospice
B. Advise bed rest until pain resolves
C. Arrange domiciliary physiotherapy
D. Emergency admission for MR scan of spine
E. Give analgesia and re-examine her in the morning

**Answer**: D

**Explanation**: The patient’s symptoms and examination findings are suggestive of spinal cord compression, which is a medical emergency. Urgent imaging with an MRI of the spine is necessary to confirm the diagnosis and identify the underlying cause of the cord compression, which can include metastatic cancer, disc herniation, or spinal stenosis. Typical treatment options include surgical decompression or palliative radiation therapy. The patient may require admission to the hospital for further management.

---
### 404. Question 404
A 3 year old boy has had diarrhoea for 6 months. He has 4-5 watery stools per day that contain visible pieces of sweetcorn and other vegetables. He is thriving and developing well

What is the most likely diagnosis?

A. Coeliac disease
B. Gastroenteritis
C. Inflammatory bowel disease
D. Lactose intolerance
E. Toddler diarrhoea

**Answer**: E

**Explanation**: The most likely diagnosis is toddler diarrhoea. Toddler diarrhoea is a common condition in children between 6 months and 5 years of age, characterised by chronic, non-bloody, watery diarrhoea with no signs of malabsorption or growth failure. It typically occurs during the daytime and is associated with the intake of large amounts of fruit juice, high-fibre foods, and other carbohydrates. It is usually self-limiting and resolves by the age of 5 years.

---
### 405. Question 405
A 25 year old nulliparous woman with an uncomplicated pregnancy attends for induction of labour at 41 weeks. Examination reveals the head is engaged; the cervix is posterior, 2cm long and the os is closed

Which is the most appropriate method of induction?

A. Endovaginal prostaglandin gel
B. Membrane sweep
C. Oxytocin infusion
D. Oxytocin infusion and amniotomy
E. Progesterone suppository

**Answer**: A

**Explanation**: Endovaginal prostaglandin gel is the most appropriate method of induction in this scenario. The woman is at term and the head is engaged, indicating that the fetal head is in the pelvis. Cervical assessment reveals that the cervix is unfavourable for induction, with a posterior position, a length of 2 cm, and a closed os. Endovaginal prostaglandin gel is a method of cervical ripening, and reserved for cases in which the cervix is unfavourable, and there is a need to ripen the cervix before induction. Membrane sweeps encourage normal labour but are not a recognised induction method on their own. Oxytocin infusion and amniotomy is unlikely to be an effective method of induction in this situation. The cervix is closed making ARM difficult if not impossible without cervical ripening – oxytocin cannot be used without amniotomy. Progesterone suppositories are used to prevent preterm labour, and they are not indicated for induction of labour at term.

---
### 406. Question 406
A 75 year old man attends his GP with fatigue, blurred vision and poor concentration for 4 months. He has had type 2 diabetes for 30 years and takes metformin (1 g twice daily). He lives alone and reports having a well- balanced diet

**Investigations:**
Haemoglobin 98 g/L (130–175) Mean cell volume (MCV) 115 fL (80–96) Serum vitamin B12 90 ng/L (160–925)

Which is the most appropriate initial treatment for this patient?

A. Advise dietary modifications to include more vitamin B12-rich foods
B. Start intramuscular hydroxocobalamin 1 mg every 2 months
C. Start intramuscular hydroxocobalamin 1 mg on alternate days
D. Start oral cyanocobalamin 1 mg once daily
E. Start oral cyanocobalamin 150 micrograms once daily

**Answer**: C

**Explanation**: This patient has vitamin B12 deficiency, likely exacerbated by long-term metformin use, which can interfere with B12 absorption. Initial treatment for vitamin B12 deficiency, especially in the presence of neurological symptoms such as blurred vision and poor concentration, is intramuscular hydroxocobalamin. The recommended regimen for patients with neurological involvement is 1 mg of hydroxocobalamin intramuscularly on alternate days until there is no further improvement, followed by maintenance dose every 2 months. This allows rapid replenishment of B12 stores to address the neurological symptoms effectively. Scenario: Management of anaemia - vitamin B12 and folate deficiency. Last revised in March 2024 https://cks.nice.org.uk/topics/anaemia-b12-folate- deficiency/management/management/#treatment-for-b12-deficiency

---
### 407. Question 407
A 94 year old woman has a deep gnawing pain in her left arm. She has had 10 kg weight loss in the past year. Her temperature is 37.3°C. She has localised tenderness over the left upper arm

**Investigations:**
X-ray left arm (see image).

[IMAGE: image_407_MLA8_page23_image_23_2.png]

Which is the most likely cause of her pain?

A. Metastatic carcinoma
B. Osteomyelitis
C. Osteoporosis
D. Osteosarcoma
E. Paget's disease

**Answer**: A

**Explanation**: The most likely cause of the 94-year-old woman’s pain in her left arm is metastatic carcinoma. She has lost weight and the site of the abnormality i.e. proximal humerus, is a common site for metastasis. The X-ray is consistent with metastatic carcinoma.

---
### 408. Question 408
A 45 year old man has a 5 month history of chronic sinusitis and unresolving headaches. When he bends forward, purulent fluid pours from his nose

Which anatomical structure is most likely to be the source of this fluid?

A. Anterior ethmoid air cells
B. Frontal sinus
C. Lacrimal sac
D. Maxillary sinus
E. Posterior ethmoid air cells

**Answer**: D

**Explanation**: The patient’s symptoms suggest chronic maxillary sinusitis; when the patient bends forward, gravity causes the accumulated pus or mucus to drain out through the osteomeatal complex into the nasal cavity. The anterior ethmoids and the frontal sinus also drain through the OM complex, but the maxilla is the most commonly involved.

---
### 409. Question 409
A 6 hour old boy, born at term, is grunting and cyanosed. He has been struggling to feed. His temperature is 36.8°C, pulse is 190 bpm (120-160), respiratory rate 60 breaths per minute (30-60) and oxygen saturation 82% breathing air. His oxygen saturation does not improve significantly breathing high flow oxygen. He has a loud single second heart sound and a systolic murmur. He is treated with intravenous fluids and antibiotics

What is the most appropriate next medication?

A. Alprostadil
B. Ibuprofen
C. Indomethacin
D. Sildenafil
E. Surfactant

**Answer**: A

**Explanation**: The most appropriate next medication is Alprostadil. These clinical findings are consistent with congenital heart disease. The loud single second heart sound and systolic murmur suggest a possible ventricular septal defect (VSD) or patent ductus arteriosus (PDA). The grunting and cyanosis, along with the low oxygen saturation that does not improve with high flow oxygen, suggest that the baby is experiencing significant respiratory distress. Alprostadil, a prostaglandin E1 analogue, helps maintain ductal patency and allows adequate systemic perfusion until definitive management, such as surgical correction or catheter-based intervention, can be undertaken. Ibuprofen and indomethacin are both nonsteroidal anti-inflammatory drugs that are used to treat patent ductus arteriosus, but they are not appropriate in this case as they would cause closure of the ductus arteriosus, exacerbating the baby’s symptoms. Sildenafil is a medication used to treat pulmonary hypertension, which can occur in neonates with congenital heart defects, but it is not the most appropriate initial medication in this case. Surfactant is a medication used to treat respiratory distress syndrome, which is not the primary diagnosis in this case.

---
### 410. Question 410
A 5 year old girl has a rash over her arms that has been gradually worsening over the past month. Her mother reports that she seems more tired than usual. She has a petechial rash over both forearms with some petechiae over her left anterior chest wall. She is pale and has hepatosplenomegaly

What is the most appropriate management option?

A. Full blood count and blood film and review within 48 hours
B. Intramuscular benzylpenicillin sodium and immediate ambulance
C. Oral prednisolone and review in 3 days
D. Routine general paediatrics outpatient appointment
E. Urgently referral to paediatric assessment unit

**Answer**: E

**Explanation**: The most appropriate management option is to refer her urgently to the paediatric assessment unit. The presence of a petechial rash, hepatosplenomegaly, and tiredness in a child should raise suspicion of a serious underlying condition, such as leukaemia or other haematological disorders. Urgent referral to the paediatric assessment unit is necessary to ensure prompt diagnosis and treatment. Intramuscular benzylpenicillin sodium is not appropriate in this case, as it is unlikely to address the underlying condition. Prednisolone is also not appropriate, as it is not indicated for the management of petechial rash and hepatosplenomegaly. Referral to a general paediatric clinic is not urgent enough, given the severity of the symptoms, and a full blood count and blood film should be taken urgently, but this should be done in the context of urgent referral to the paediatric assessment unit.

---
### 411. Question 411
A 62 year old man attends the outpatients clinic with his wife. He has had reduced energy and lack of interest in his work and poor sleep for six weeks. He has lost weight. He has benign prostatic enlargement. There is evidence of self-neglect and reduced eye contact

What is the single most appropriate drug treatment?

A. Benzodiazepine
B. Selective serotonin re-uptake inhibitor
C. Serotonin noradrenaline re-uptake inhibitor
D. Tricyclic antidepressant
E. Z-drug

**Answer**: B

**Explanation**: Based on the symptoms described, the most appropriate drug treatment would be a selective serotonin re-uptake inhibitor (SSRI), as this class of drugs is commonly used in the treatment of depression, which the patient may be experiencing. Benzodiazepines and Z-drugs are more appropriate for short-term management of insomnia or anxiety, while tricyclic antidepressants and serotonin noradrenaline re-uptake inhibitors (SNRIs) may have more side effects and risks in older patients with comorbidities. However, it is important to note that a full assessment and diagnosis by a healthcare professional is necessary before initiating any drug treatment.

---
### 412. Question 412
A doctor is approached by their neighbour who is aware that another person on their street has been admitted to the ward the doctor is working on. They wish to know how the patient is doing. The doctor is aware the patient is stable but the prognosis is uncertain

Which is the most appropriate response by the doctor?

A. They can confirm they are caring for him and that he is unwell but stable
B. They can confirm they are caring for him but cannot comment on his condition
C. They can confirm they are caring for him and that he is making good progress
D. They cannot confirm they are caring for him but have heard he is unwell but
E. They cannot confirm who is caring for him and cannot comment on his

**Answer**: E

---
### 413. Question 413
A 40 year old woman has had right-sided facial weakness for the past 12 hours. She has weakness of all of the muscles on the right side of her face. There is no limb weakness and speech is normal. Examination of her ears is normal

Which is the most appropriate drug treatment?

A. Aciclovir
B. Aspirin
C. Cinnarizine
D. None
E. Prednisolone

**Answer**: E

**Explanation**: The patient has symptoms of facial palsy, which is likely due to Bell’s palsy, a type of idiopathic facial nerve palsy. The most appropriate initial treatment in this case (within 72 hours of the onset of symptoms) is a short course of prednisolone to reduce inflammation and improve outcomes. Aciclovir may be considered if herpes simplex virus infection is suspected, but it is not the first-line treatment for Bell’s palsy, and should be used in combination with a corticosteroid. Aspirin and cinnarizine are not indicated in this case.

---
### 414. Question 414
A 19 year old man attends his GP with two days of a burning sensation when passing urine, urethral discomfort and a penile discharge. This developed a week after he had unprotected sex with a new female partner. He declines a referral to the genito-urinary medicine (GUM) clinic

Which is the most appropriate treatment?

A. Doxycycline
B. Ciprofloxacin and metronidazole
C. Fluconazole and penicillin V
D. Metronidazole and fluconazole
E. Penicillin V and azithromycin

**Answer**: A

**Explanation**: The man has suspected urethritis. There are no specific features to suggest gonorrhoea and the most likely organism is chlamydia. The most appropriate treatment for this patient would be Doxycycline. Azithromycin alone would be an alternative. A first-void sample for nucleic acid amplification testing (NAAT) should be sent. The patient should also be advised to inform his sexual partner to get tested and treated as well.

---
### 415. Question 415
A 9 month old boy is brought to his GP with 4 days of coryzal symptoms, intermittent fever, coughing and wheezing. He has been taking smaller feeds for the past 2 days and was unsettled last night. He has adequate oral intake. His mother has given him paracetamol suspension. He is alert, there is no rash and he is drooling. His temperature is 38.2°C, capillary return 1 second, pulse is 148 bpm (80-160), respiratory rate 60 breaths per minute (30-60) and oxygen saturation 97% in air. He has widespread wheeze and crackles, and his ears and throat are normal

Which is the most appropriate next step in management?

A. Admission to paediatric ward
B. Prescribe oral doxycycline
C. Prescribe oral co-amoxiclav
D. Reassure and give safety netting advice
E. Give nebulised salbutamol and review

**Answer**: D

**Explanation**: The presentation of this baby is consistent with bronchiolitis. The most appropriate next step in management would be to reassure and give safety netting advice. Admission to paediatric ward may be considered in severe cases or if the baby is unable to take oral fluids, but is not necessary in this case. Prescribing oral doxycycline is not appropriate as doxycycline is contraindicated in children under 12 years of age due to the risk of tooth discolouration. Prescribing oral co-amoxiclav is not appropriate as antibiotics are not routinely recommended in the management of bronchiolitis, which is usually caused by a viral infection. Reassurance and safety netting advice is important in all cases. This baby has a low grade fever but the other observations are all within normal range so there is no indication for any other intervention at present. Giving nebulised salbutamol and review would be indicated if observations were outside the normal range or if the baby was significantly distressed, not feeding etc.

---
### 416. Question 416
A 60 year old man feels tired, but has no specific symptoms. He is a non- smoker and drinks eight units of alcohol per week.

**Investigations:**
Haemoglobin 120 g/L (130–175) White cell count 5.8 × 109/L (3.0–10.0) Platelets 170 × 109/L (150–400) MCV 110 fL (80–96) TSH 2.0 mU/L (0.3–42)

Which additional investigation is most likely to help with the diagnosis?

A. Erythrocyte sedimentation rate
B. Ferritin
C. Folate and vitamin B 12
D. Haptoglobin
E. Protein electrophoresis

**Answer**: C

**Explanation**: The patient has a macrocytic anaemia (MCV increased, Hb reduced). Folate and vitamin B12 deficiencies are common causes of macrocytic anaemia and therefore testing for these would be initial investigations. Ferritin is incorrect because iron deficiency causes a microcytic anaemia. Alcohol misuse can cause a macrocytosis, but 8 units of alcohol a week is not enough to cause this. Hypothyroidism can also cause a macrocytosis but this man’s thyroid function test is normal. Haemolysis can cause a macrocytic anaemia (due to increase in the number of reticulocytes which are larger than mature red cells) and haptoglobin is a test used as part of a haemolysis screen but on its own is not helpful and would not be an initial investigation. Protein electrophoresis is used to investigate possible myeloma which can cause a normocytic or macrocytic anaemia but is less likely than B12 or folate deficiency. ESR is a non-specific investigation that can be increased for many reasons (infection, inflammation, malignancy, myeloma) and would not be a helpful investigation (many labs no longer do this test).

---
### 417. Question 417
A 15 year old girl has delayed puberty. She has always been short for her age (height <0.4th centile for age). She has not started her periods yet. She has no dysmorphic facial features but does have a webbed neck and widely spaced nipples. She has no breast development

Which chromosomal abnormality is most likely to cause her clinical presentation?

A. 45X0
B. 47XXX
C. 47XXY
D. Trisomy 13
E. Trisomy 21

**Answer**: A

**Explanation**: The most likely chromosomal abnormality to cause the clinical presentation of delayed puberty, short stature, webbed neck, widely spaced nipples, and lack of breast development is Turner syndrome, which is caused by a complete or partial monosomy of the X chromosome, also known as 45X0.

---
### 418. Question 418
A 36 year old man is brought to the Emergency Department with a head injury after a fall from 10 metres. He was unconscious for a minute but recovered and seemed fully alert and orientated. Four hours later he becomes drowsy and confused, and then collapses. His GCS is 7/15

Which is the most likely diagnosis?

A. Cerebral contusions
B. Compound depressed skull fracture
C. Diffuse axonal injury
D. Extradural haematoma
E. Subarachnoid haemorrhage

**Answer**: D

**Explanation**: A fall from a height with loss of consciousness and subsequent deterioration in consciousness level suggests an extradural haematoma. The initial lucid interval followed by a rapid deterioration is a classic feature. A cerebral contusion would be less likely to cause a lucid interval, and a subarachnoid haemorrhage or diffuse axonal injury may not be associated with a lucid interval. A compound depressed skull fracture is often visible on examination and may be associated with a break in the skin, and the patient would have required immediate surgical intervention.

---
### 419. Question 419
A 3 year old boy has had multiple skin lesions on his chest wall for 2 weeks (see image). The lesions are not itchy and he is otherwise well. He is apyrexial

[IMAGE: image_419_MLA8_page35_image_35_2.png]

Which is the most likely diagnosis?

A. Chickenpox
B. Discoid eczema
C. Hand, foot and mouth disease
D. Molluscum contagiosum
E. Rubella

**Answer**: D

**Explanation**: The most likely diagnosis based on the given information is molluscum contagiosum. The lesions are typically painless, firm, dome-shaped, and have a central indentation. They are caused by a poxvirus and are usually self-limiting, resolving within 6 to 12 months.

---
### 420. Question 420
A 42 year old woman has 6 months of a painful right shoulder. Her pain keeps her awake at night and is worsened by movement. She is otherwise well. There is no history of trauma. She has pain on shoulder abduction between 80° and 120°. Her shoulder movements are otherwise normal. There is no joint effusion. X-ray of right shoulder is normal

Which is the most likely diagnosis?

A. Cervical radiculopathy
B. Osteoarthritis of glenohumeral joint
C. Polymyalgia rheumatica
D. Pseudogout
E. Subacromial bursitis

**Answer**: E

**Explanation**: The most likely diagnosis is subacromial bursitis. The symptoms of pain worsened by movement and difficulty sleeping, along with a normal X-ray and pain on shoulder abduction between 80 deg; and 120 deg; are consistent with subacromial bursitis. The patient is describing a painful arc.

---
### 421. Question 421
A 45 year old man has his BMI measured as part of a clinical trial for type 2 diabetes

Which is the most appropriate classification of data on this parameter?

A. Categorical
B. Continuous
C. Discrete
D. Nominal
E. Subjective

**Answer**: B

**Explanation**: BMI is a continuous variable as it can take any value within a range of values (e.g. 18.5 to 50). Categorical variables are those that can be grouped into categories (e.g. blood type, race). Discrete variables are those that can only take certain values, usually integers (e.g. number of children). Nominal variables are those that have no intrinsic order or ranking (e.g. hair colour, occupation). Subjective is a term for phenomena not variables.

---
### 422. Question 422
A 75 year old man with metastatic bowel cancer is dying. He is semi- conscious. He has increasingly audible respiratory secretions. He is being treated with morphine sulfate and haloperidol via a syringe driver

Which is the most appropriate drug management?

A. Amoxicillin
B. Furosemide
C. Hyoscine butylbromide
D. Levomepromazine
E. Midazolam

**Answer**: C

**Explanation**: The most appropriate drug management for a dying patient with increased respiratory secretions and a rattly breathing is Hyoscine which is a commonly used antimuscarinic medication for the management of respiratory secretions in end-of-life care. It reduces secretions by blocking muscarinic receptors, thus drying the mouth and airways. Therefore, the answer is Hyoscine. Amoxicillin is an antibiotic that would not be indicated in this situation. Furosemide is a loop diuretic and would not be helpful for respiratory secretions. Levomepromazine is an antipsychotic medication that may have sedative effects and is sometimes used in palliative care for symptom management, but it is not the first-line medication for managing respiratory secretions. Midazolam is a benzodiazepine that may be used for sedation and anxiety relief, but it is not used for managing respiratory secretions.

---
### 423. Question 423
A 67 year old man has had 24 hours of a painful swollen left knee. He went hill walking 3 days ago. His temperature is 37.6°C, pulse is 104 bpm and BP 116/80 mmHg. His left knee is red, swollen and hot to touch. He has a reduced range of movement in his knee and is unable to weight bear due to pain

**Investigations:**
Haemoglobin 145 g/L (130–175) White cell count 23.4 × 109/L (4.0–11.0) Platelets 546 × 109/L (150–400) Neutrophils 19.2 × 109/L (2.0–7.5) CRP 122 mg/L (<5)

Which is the most appropriate next investigation?

A. Aspiration of left knee joint for microscopy and culture
B. MR imaging of left knee
C. Serum anti-cyclic citrullinated peptide antibody
D. Serum uric acid
E. X-ray of left knee

**Answer**: A

**Explanation**: The most appropriate next investigation for this patient is aspiration of left knee joint for microscopy and culture. The patient has a painful swollen left knee with fever and raised inflammatory markers, which suggests an acutely infected knee joint. Aspiration of the joint for microscopy and culture is the most appropriate investigation to identify the causative organism and guide antibiotic treatment. MR imaging may be useful in cases of chronic joint disease, but is not necessary in this acute presentation. X-ray may be useful in cases of trauma or chronic joint disease, but again is not indicated acutely. Testing for anti-cyclic citrullinated peptide antibody and serum uric acid are not relevant in this scenario.

---
### 424. Question 424
A 36 year old woman and her partner have been trying to conceive for the last 18 months. Neither has attained a pregnancy before. Both are medically fit and well and have no surgical history. Her periods are every 38-45 days. Both smoke 5-10 cigarettes per day and drink occasionally at the weekend. Examination is unremarkable in both

Which is the most likely cause of their inability to conceive?

A. Abnormal semen
B. Anovulatory cycles
C. Parental smoking
D. Unexplained subfertility
E. Uterine tube blockage

**Answer**: B

**Explanation**: Based on the given information, the most likely cause of their inability to conceive is anovulatory cycles. The woman’s menstrual cycle is longer than the normal range of 21-32 days, which suggests that she may not be ovulating regularly. The absence of any other medical conditions or abnormalities in either partner suggests that anovulation is the most likely cause of their infertility.

---
### 425. Question 425
A 45 year old man has a lump in the right side of his neck. He has never smoked and takes no regular medications. Fine needle aspiration of the mass reveals squamous cell carcinoma, and subsequent investigations identify the primary tumour in the right tonsil

Which virus is associated with this malignancy?

A. Cytomegalovirus
B. Epstein–Barr virus
C. Human immunodeficiency virus
D. Human papilloma virus
E. Human T-lymphotropic virus

**Answer**: D

**Explanation**: Human papilloma virus (HPV) is associated with squamous cell carcinoma of the oropharynx, which includes the tonsils (typically palatine tonsils and lingual tonsils). Other risk factors for this cancer include smoking and alcohol use, but the incidence of HPV-associated oropharyngeal cancers is increasing. HPV-associated cancers also include cervical, vulval, penile and anal cancers. https://www.cancer.net/navigating- cancer-care/prevention-and-healthy-living/hpv-and-cancer

---
### 426. Question 426
A 78 year old man has worsening breathlessness. He has heart failure that has been worsening progressively over the past 12 months. He has been bed bound for the past 2 weeks. He was recently found to have probable lung carcinoma but was not fit for further investigation. He is dyspnoeic, cyanosed and confused. His temperature is 36.1°C, pulse is 100 bpm, BP 92/60 mmHg, respiratory rate 30 breaths per minute and oxygen saturation 88% on 15 L/min via a Venturi mask. He has inspiratory crackles in both bases. He is treated with furosemide

Which additional treatment is most likely to reduce his breathlessness?

A. Intramuscular haloperidol
B. Intravenous glyceryl trinitrate
C. Nasal intermittent positive pressure ventilation
D. Nebulised salbutamol
E. Oral morphine

**Answer**: E

**Explanation**: Morphine is most likely to reduce the breathlessness in this patient. The patient is experiencing severe dyspnea, which is a common symptom in end-stage heart failure. Morphine is an opioid analgesic with respiratory depressant effects that can reduce the sensation of dyspnea. Glyceryl trinitrate and nebulised salbutamol are more appropriate for patients with bronchospasm or heart failure due to left ventricular dysfunction. Nasal intermittent positive pressure ventilation is more appropriate for patients with acute respiratory failure due to hypoventilation. Haloperidol is indicated for patients with delirium, agitation or confusion.

---
### 427. Question 427
An 18 year old woman has a sudden sharp stabbing pain in her abdomen, lasting only a few minutes. It is 14 days since her last period started. She indicates that the pain is localised to the left iliac fossa

A surge in which hormone is most likely to coincide with her pain?

A. Follicle stimulating hormone
B. Luteinising hormone
C. Oestrogen
D. Progesterone
E. Prolactin

**Answer**: B

**Explanation**: The surge in luteinising hormone is most likely to coincide with the pain experienced by the 18 year old woman. This is because the pain is localised to the left iliac fossa, which is where the ovary is located. The surge in luteinising hormone occurs just before ovulation and stimulates the release of an ovum from the ovary. It is most likely that the pain was caused by the rupture of the follicle during ovulation with this temporal relationship.

---
### 428. Question 428
A 72 year old man with lung cancer is admitted to the respiratory ward with recurrent haemoptysis. He is known to the palliative care team and it is felt that he is near the end of his life. He says that he wants to have his terminal care on the respiratory ward because he knows and trusts the nurses. A 'do not attempt resuscitation' form is completed. He subsequently has further haemoptysis and becomes more breathless, so he is treated with an opioid infusion to relieve his dyspnoea. A doctor suggests that the local hospice is better equipped to care for the patient. His son agrees with the doctor, believing that the hospice is "the right place to die"

What should be the most important factor influencing the decision on whether to move him to a hospice?

A. Consultant's view of patient's best interests
B. Hospital bed state
C. Local policy on end of life care
D. Patient's previous opinion
E. Son's wishes

**Answer**: D

**Explanation**: Patient’s previous opinion should be the most important factor influencing the decision on whether to move him to a hospice. The patient has expressed his desire to stay on the respiratory ward because he knows and trusts the nurses. It is important to respect the patient’s wishes and provide care in the location where the patient feels most comfortable, especially in end-of-life care situations. The son’s wishes can also be taken into consideration, but the patient’s own wishes should be the primary consideration.

---
### 429. Question 429
A 74 year old woman has had left sided headache and discomfort when chewing food for 3 months. She experiences a sensation of pressure and pain in her jaw, even when talking. She has lost 8 kg in weight over the same time period

**Investigations:**
CRP 45 mg/L (<5)

Which investigation is most likely to establish the diagnosis?

A. CT scan of head
B. Parotid sialogram
C. Serum anti-neutrophil cytoplasmic antibodies
D. Temporal artery biopsy
E. X-ray of temporomandibular joint

**Answer**: D

**Explanation**: Temporal artery biopsy is the most appropriate investigation in this patient to establish the diagnosis of giant cell arteritis. The typical symptoms of headache, jaw claudication, and unintentional weight loss, along with elevated CRP levels, raise a strong suspicion of giant cell arteritis. Temporal artery biopsy is the gold standard test for diagnosis, as it shows characteristic histopathological changes of giant cell arteritis such as mononuclear cell infiltration and granulomatous inflammation. Some centres will arrange a temporal artery ultrasound to help with the diagnostic process but this is not an option in this question, so biopsy is the most appropriate.

---
### 430. Question 430
A group of 75 men and a group of 75 women performed a standardised exercise test and had their pulse measured at the end. The data from the two groups were compared. The data is normally distributed with equal variance

Which is the most appropriate statistical test to compare these groups?

A. Analysis of variance
B. Friedman's test
C. Mann–Whitney test
D. Paired Student's t-test
E. Unpaired Student's t-test

**Answer**: E

**Explanation**: Unpaired Student’s t-test would be the most appropriate statistical test to compare these groups, as it is used to compare the means of two independent groups of data with equal variances assuming normal distribution.

---
### 431. Question 431
A 45 year old man has a tremor that has worsened over several weeks. He has schizophrenia and takes haloperidol. He has bilateral tremor and cog-wheel rigidity in his upper limbs

Which is the most appropriate treatment to manage his symptoms?

A. Co-beneldopa
B. Entacapone
C. Pramipexole
D. Procyclidine hydrochloride
E. Selegiline hydrochloride

**Answer**: D

**Explanation**: Procyclidine is an antispasmodic drug and a muscarinic antagonist that crosses the blood-brain barrier and is used in the treatment of drug-induced extrapyramidal disorders and in parkinsonism. Here Co-Benedopa can be used to treat Parkinson's disease but not EPSE. Drug-induced parkinsonism is likely the most common drug-induced movement disorder and one of the most common nondegenerative causes of parkinsonism. Any medication that interferes with dopamine transmission may cause parkinsonism. Haloperidol is a dopamine receptor blocking agent.

---
### 432. Question 432
A 30 year old man is unable to straighten his right middle finger after an injury. He has a flexion deformity of the finger at the distal interphalangeal joint and is unable to actively extend his finger

Which is the most appropriate management option?

A. External finger fixation
B. Finger splint
C. Internal finger fixation
D. Reassurance
E. Steroid injection

**Answer**: B

**Explanation**: The most appropriate management option for a 30-year-old man with a flexion deformity of the finger at the distal interphalangeal joint and inability to actively extend his finger following an injury is a finger splint. A finger splint can provide support and immobilise the finger, allowing the tendon to heal and the finger to regain its full range of motion.

---
### 433. Question 433
A 20 year old man has had two months of night sweats and 5 kg weight loss. He was previously well. His temperature is 37.6°C. He has palpable neck lymph nodes and splenomegaly

**Investigations:**
CT scan chest, abdomen and pelvis: enlarged mediatinal lymph nodes and Splenomegaly Lymph node biopsy: Hodgkin/Reed-Sternberg (HRS) cells admixed with a polymorphous inflammatory infiltrate

Which is the most appropriate first line treatment?

A. Chemotherapy
B. Corticosteroids
C. Immunotherapy
D. Radiotherapy
E. Surgical excision of mediastinal lymph nodes

**Answer**: A

**Explanation**: The most appropriate first-line treatment for classical Hodgkin lymphoma is chemotherapy. Corticosteroids may be used in addition to chemotherapy in certain cases but are not typically used as a first- line treatment. Immunotherapy and radiotherapy may be used as part of a treatment regimen but are not typically used as a first-line treatment for classical Hodgkin lymphoma. Surgical excision of mediastinal lymph nodes is not a treatment option for Hodgkin lymphoma.

---
### 434. Question 434
A 72 year old man is admitted with cough, breathlessness and confusion. He has metastatic adenocarcinoma and is being treated with chemotherapy. His wife reports that he has had enough of his treatment and planned to discontinue active treatment. He is drowsy and unable to answer questions. He has bronchial breathing at the left base. He is given 0.9% sodium chloride and broad spectrum antibiotics intravenously

Which is the most appropriate way to determine his cardiopulmonary resuscitation status on this admission?

A. Admitting team should decide
B. Ask an independent advocate to decide
C. Ask consultant oncologist to decide
D. Ask his wife to decide
E. Wait 24 hours to see if patient regains capacity to decide

**Answer**: A

**Explanation**: As the patient is currently unable to answer questions and although his wife reports that he planned to discontinue active treatment, this has not been documented and cannot be verified. The admitting team should therefore decide about the best clinical approach to the patient, including appropriateness or otherwise of CPR.

---
### 435. Question 435
A 36 year old man with type 1 diabetes mellitus has a pilonidal sinus. He takes 14 units long-acting insulin at night, and short-acting insulin three times daily at mealtimes (typically 6-8 units with each meal). He is scheduled for excision of the sinus under general anaesthesia, first on a morning operating list. He is asked to fast from midnight the night before. His HbA1c is 58 mmol/mol (20-42)

Which is the most appropriate plan for managing his insulin pre-operatively?

A. Omit evening and morning insulin doses
B. Start a variable-rate insulin infusion on the morning of surgery
C. Start a variable-rate insulin infusion the evening before surgery
D. Take evening and morning insulin doses, as usual
E. Take usual evening insulin and omit morning insulin

**Answer**: E

**Explanation**: It is important to ensure that blood glucose levels are well-controlled in patients with diabetes undergoing surgery. Omitting insulin doses can lead to hyperglycaemia, which increases the risk of surgical complications, while taking too much insulin can lead to hypoglycaemia, which can also be dangerous. In this case, he should take his usual long-acting insulin the evening before but will need to adjust his short- acting insulin dose based on the anticipated timing of the surgery the following day. As he is scheduled as first on the list in the morning, and having been starved from midnight he should omit his morning short acting insulin prior to surgery and recommence this when eating and drinking. The anaesthetist should be informed of the patient’s diabetes and insulin regimen, and should monitor blood glucose levels during the perioperative period. Guideline for Perioperative Care for People with Diabetes Mellitus Undergoing Elective and Emergency Surgery. Updated October 2023 https://cpoc.org.uk/guidelines-resources-guidelines-resources/guideline- diabetes

---
### 436. Question 436
A one week old girl has pale stools in her nappy, with streaks of dark urine (see image). She is fully breastfed and was born at term. She has lost 8.2% of her birth weight. She is apyrexial. She is alert and has jaundice

[IMAGE: image_436_MLA8_page52_image_52_2.png]

Which is the most appropriate investigation?

A. Coombs (direct antiglobulin) test
B. Full blood count and film
C. Plasma glucose
D. Split bilirubin
E. Urea and electrolytes

**Answer**: D

**Explanation**: The history and presentation is suggestive of conjugated hyperbilirubinaemia, which is indicative of pathology rather than being physiological. A split bilirubin measures the ratio of conjugated and unconjugated bilirubin levels in the baby’s blood, which is necessary to diagnose conjugated jaundice.

---
### 437. Question 437
A 36 year old woman attends for an asthma review. She requires a long- acting β-agonist and steroid combination inhaler. The guidelines suggest either a metered dose inhaler or a dry powder. They are the same price. This patient asks which is better for the environment

Which component of these inhalers has the highest carbon footprint?

A. Hydrofluorocarbon propellant in the metered dose inhaler
B. Packaging of the dry powder inhaler
C. Plastic component of the dry powder inhaler
D. Plastic component of the metered dose inhaler
E. Powder component of the dry powder inhaler

**Answer**: A

**Explanation**: Hydrofluorocarbon propellant in the metered dose inhaler has the highest carbon footprint of the components listed. It is a greenhouse gas that contributes to climate change. Dry powder inhalers do not use propellants and are considered to have a lower carbon footprint. However, the manufacturing and disposal of all inhalers contribute to environmental impact.

---
### 438. Question 438
A 18 year old man is worried about his cancer risk. His paternal grandfather died of colorectal cancer at 42 years of age and his 36 year old father has just been diagnosed with colorectal cancer. The son's colonoscopy shows hundreds of colonic polyps, and biopsies from several of the polyps show adenomatous change with low grade dysplasia

Which is the most appropriate strategy to prevent colon cancer in this situation?

A. Daily low dose aspirin
B. Diet rich in fruit and vegetables
C. Panproctocolectomy
D. Annual faecal immunochemical test (FIT)
E. Annual colonoscopy and biopsy

**Answer**: C

**Explanation**: The most appropriate strategy to prevent colon cancer in this situation is panproctocolectomy, which is the removal of the entire colon, rectum, and anus. This patient has a strong family history of early-onset colorectal cancer and has already developed hundreds of colonic polyps with evidence of adenomatous change and low-grade dysplasia. These findings are consistent with a diagnosis of familial adenomatous polyposis (FAP), an inherited condition that predisposes to the development of colorectal cancer. Prophylactic surgery is recommended in patients with FAP to prevent the development of colorectal cancer. Daily low dose aspirin and a diet rich in fruit and vegetables have been shown to have some protective effect against colon cancer, but these measures are not sufficient for a patient with FAP. Annual FIT and colonoscopy and biopsy are not adequate for cancer prevention in a patient with FAP.

---
### 439. Question 439
A 21 year old man has a fear of public speaking. He is a student and has to give an oral presentation, and he feels unable to manage this. He fears that he will do something to embarrass himself or even vomit. The thought of giving his presentation gives him palpitations and makes him breathless and dizzy. He has avoided his tutor for 3 months and has not left his flat for several weeks. He recognises that his fears are irrational but feels overwhelmed

Which is the most likely diagnosis?

A. Agoraphobia
B. Anxious avoidant personality disorder
C. Emetophobia
D. Panic disorder
E. Social phobia

**Answer**: E

**Explanation**: The patient’s fear of public speaking, avoidance behaviour, and recognition that his fears are irrational are consistent with a diagnosis of social phobia. Social phobia is a type of anxiety disorder characterised by an excessive and persistent fear of social situations, including public speaking. It can cause significant distress and interfere with daily activities. Treatment options may include cognitive-behavioural therapy and/or medication.

---
### 440. Question 440
A 46 year old man has sudden onset and intense lower back pain. He has no pain or numbness in his buttocks or legs. He is diagnosed with mechanical back pain. He has no drug contra-indications

Which is the most appropriate initial medication?

A. Amitriptyline
B. Fentanyl
C. Ibuprofen
D. Paracetamol
E. Triamcinolone

**Answer**: C

**Explanation**: The most appropriate initial medication is non- steroidal anti-inflammatory drugs (NSAIDs) in this age group if there are no contra-indications. Paracetamol on its own is not recommended. Amitriptyline, fentanyl, and triamcinolone are not typically used for the initial treatment of mechanical back pain.

---
### 441. Question 441
A 62 year old man is brought to the operating theatre recovery room after a laryngoscopy and vocal cord biopsy. He appears to be conscious, but his breathing is shallow and respiratory rate 28 breaths per minute. His voice is weak and, when the recovery nurse asks him to squeeze her fingers with his hand, the grip is not sustained

Which drug will reverse these signs?

A. Doxapram
B. Glycopyrronium
C. Naloxone
D. Neostigmine
E. Rocuronium

**Answer**: D

**Explanation**: The weak grip, cough and shallow breathing suggest residual effects of neuromuscular blockade that has been administered to facilitate laryngoscopy and vocal chord biopsy under general anaesthetic. Doxapram acts on central and peripheral chemoreceptors to stimulate respiration but would have no effect on improving neuromuscular strength. Naloxone is an opioid antagonist and would not reverse the effects of neuromuscular blockade. Glycopyrronium is an antimuscarinic agent and would not have any effect on reversing neuromuscular blockade at the neuromuscular junction and improving strength. Neostigmine is a cholinesterase inhibitor and is the most appropriate agent to administer to reverse the effects of neuromuscular blockade. It reduces the breakdown of acetylcholine at the neuromuscular junction increasing its availability to bind to the acetylcholine receptor and therefore trigger muscular contraction and increased strength. Administration would increase grip strength, respiratory muscular strength and may improve vocal chord movement and speech. Rocuronium is a neuromuscular blocking agent and would not be appropriate in this situation.

---
### 442. Question 442
A 50 year old woman has broken her right radius after tripping at home. She has been experiencing hot flushes and night sweats for the past six months, with irregular menstruation. She has been taking salbutamol and beclometasone regularly for more than five years to treat asthma. Her fracture heals with no complications

Which investigation will most effectively evaluate her future risk of fractures?

A. 99m-technetium bone scintigraphy
B. Dual energy X-ray absorptiometry
C. MR scan of spine and hip
D. Plain X-ray lumbar spine and pelvis
E. Quantitative CT scan of spine and hip

**Answer**: B

**Explanation**: Dual energy X-ray absorptiometry (DEXA) is the most appropriate investigation to evaluate future fracture risk in this patient. The presence of hot flushes, night sweats, and irregular menstruation suggests that the patient is likely going through menopause. The patient’s use of long-term inhaled corticosteroids for asthma increases her risk of osteoporosis. DEXA scan is a simple, non-invasive test that measures bone mineral density and is the gold standard for diagnosing osteoporosis and assessing fracture risk. A bone scintigraphy or MR scan are not first-line investigations for evaluating osteoporosis and would not provide the same level of detail as DEXA. X-rays and CT scans are not sensitive enough to diagnose osteoporosis but may be used to assess for fractures after they have occurred.

---
### 443. Question 443
A 72 year old man has had difficulty swallowing solids. He has cancer of the middle third of the oesophagus and hepatic metastases

Which is the most appropriate initial management of his dysphagia?

A. Chemotherapy
B. Excision of tumour
C. Gastrostomy feeding tube
D. Oesophageal stent
E. Radiotherapy

**Answer**: D

**Explanation**: Placement of an oesophageal stent can provide palliation of dysphagia in patients with oesophageal cancer. It is a minimally invasive procedure that can be done under sedation or general anaesthesia. It involves placement of a metal or plastic stent into the oesophagus to hold it open, allowing food and liquid to pass through. It is a safe and effective option for patients with dysphagia due to oesophageal cancer, particularly in those with advanced or metastatic disease who may not be candidates for curative treatment.

---
### 444. Question 444
A 64 year old man has low thoracic back pain and has been tired for the past 6 weeks. He is a non-smoker. He has hypertension and takes amlodipine. His urinalysis is normal.

**Investigations:**
Haemoglobin 81 g/L (135–175) MCV 82 fL (80–96) White cell count 4.3 × 109/L (3.0–100) Platelets 74 × 109/L (150–400) Creatinine 203 µmol/L (60–120)

Which initial investigation is most likely to help establish a diagnosis?

A. Anti-neutrophil cytoplasmic antibody
B. Antinuclear antibody
C. Complement levels (C3 and C4)
D. Coagulation screen
E. Serum free light chains

**Answer**: E

**Explanation**: This patient has back pain, fatigue, normocytic anaemia, thrombocytopenia and renal failure. The location of the back pain is low thoracic which is higher than the lumbosacral area commonly affected by mechanical back pain. Based on the patient’s clinical presentation and laboratory results, the most likely diagnosis is myeloma. The most appropriate initial investigation to confirm this diagnosis is serum free light chains testing. This will detect the presence of Bence-Jones protein characteristic of myeloma. Other options are not relevant to the diagnosis of myeloma.

---
### 445. Question 445
A 66 year old woman has become forgetful, does not sleep well and has lost her appetite over the last few weeks. She has been getting up early in the morning because she cannot sleep. She feels that she is no longer of any use to the rest of her family. Mini Mental State Examination is 27/30

Which is the most likely diagnosis?

A. Age-associated memory impairment
B. Alzheimer’s disease
C. Depression
D. Frontotemporal dementia
E. Vascular dementia

**Answer**: C

**Explanation**: Based on the information provided, the most likely diagnosis is depression. The patient is presenting with symptoms such as forgetfulness, loss of appetite, early morning awakening, and feelings of worthlessness. While some of these symptoms can be seen in dementia, the Mini Mental State Examination score of 27/30 suggests that cognitive impairment may not be the primary cause of her symptoms. Age-associated memory impairment is not a recognised diagnosis, and frontotemporal dementia typically presents with more behavioural changes and personality changes rather than forgetfulness. Vascular dementia may also present with cognitive changes, but there is no indication of a history of cerebrovascular disease in this case. Therefore, depression is the most likely diagnosis.

---
### 446. Question 446
A consultant is looking to find published evidence on reducing the incidence of deep venous thrombosis

Which type of study would provide the highest quality evidence?

A. Case control study
B. Case series
C. Cohort study
D. Meta-analysis of trials
E. Randomised controlled trial

**Answer**: D

**Explanation**: While randomised controlled trials provide high quality evidence about interventions, a meta-analysis of trials includes an assessment of their risk of bias, and a pooling of results, which increases the statistical power of the findings.

---
### 447. Question 447
A 62 year old man has had 3 months of general weakness, fatigue, 10 kg weight loss and mild abdominal discomfort over the right hypochondrium. He was found to have liver cirrhosis 10 years ago and has abstained from alcohol since the diagnosis. He has a non-tender, fixed hard mass in the right upper quadrant

Which serum investigation is most appropriate to aid diagnosis?

A. α-Fetoprotein
B. β-Human chorionic gonadotropin
C. CA 125
D. CA 19-9
E. Carcinoembryonic antigen

**Answer**: A

**Explanation**: α-Fetoprotein is the most appropriate serum investigation to aid diagnosis in this case. The patient has a history of liver cirrhosis and a palpable mass in the right upper quadrant, which raises suspicion of hepatocellular carcinoma (HCC). α-Fetoprotein is a tumour marker that is often elevated in patients with HCC. However, it is important to note that not all patients with HCC have elevated & α-Fetoprotein, and elevated levels can also be seen in other conditions such as pregnancy and some benign liver diseases. Therefore, a definitive diagnosis of HCC usually requires confirmation by imaging studies such as ultrasound, CT scan or MRI, and/or tissue biopsy.

---
### 448. Question 448
A 7 year old boy has intermittent pain in his left groin when playing football and climbing stairs. This has worsened over the past 4 weeks. He has now developed a painless limp. His temperature is 37.1°C. He has reduced range of movement and pain on internal rotation and abduction

Which is the most likely diagnosis?

A. Osgood–Schlatter disease
B. Perthes disease
C. Septic arthritis
D. Slipped upper femoral epiphysis
E. Transient synovitis

**Answer**: B

**Explanation**: Transient synovitis is unlikely as there is no evidence of preceding viral infection. Septic arthritis would be a concern, given the fever, but the pain is typically more severe and constant, with systemic signs of inflammation. Osgood–Schlatter disease affects the knee rather than hip. Slipped upper femoral epiphysis presents in older children and typically presents with acute onset of pain and a limp. Perthes (Legg-Calvé-Perthes disease) is more common in boys, with peak presentation at age 4-6 years. It is characterised by insidious onset of a limp with or without pain. There is no history of trauma, and the presentation is usually unilateral.

---
### 449. Question 449
A 23 year old woman commenced chemotherapy for Burkitt's lymphoma yesterday. Since then, she has been feeling increasingly nauseated. Her temperature is 36.8°C, pulse is 96 bpm and BP 112/80 mmHg. Urine output has been 40 mL in the last 12 hours. Investigations on admission were normal.

**Investigations:**
Today: Potassium 6.2 mmol/L (3.5–5.3) Urea 9 mmol/L (2.5–78) Creatinine 410 µmol/L (60–120)

Which investigation is most likely to identify the cause of her acute deterioration?

A. Blood cultures
B. C reactive protein
C. Creatine kinase
D. Phosphate
E. Urate

**Answer**: E

**Explanation**: Based on the patient’s symptoms and laboratory results, she may be experiencing tumour lysis syndrome, which is a potentially life-threatening complication of chemotherapy that can cause electrolyte imbalances and kidney damage. The most appropriate investigation to identify the cause of her acute deterioration would be urate, as elevated uric acid levels are a hallmark of tumour lysis syndrome. However, all of the other options may also be useful in helping to manage her condition. Blood cultures may be taken to rule out a bacterial infection, C-reactive protein can indicate inflammation or infection, creatine kinase may be elevated in rhabdomyolysis (another potential complication of chemotherapy), and phosphate levels may also be elevated in tumour lysis syndrome.

---
### 450. Question 450
A 44 year old woman is increasingly hypotensive in the high dependency unit. She was admitted 12 hours earlier with loin pain, dysuria and rigors, and was treated with intravenous broad spectrum antibiotics. Her temperature is 37.8°C, pulse is 112 bpm, BP 91/60 mmHg, central venous pressure +12 mmHg and oxygen saturation 95% on 60% oxygen

**Investigations:**
Sodium 139 mmol/L (135–146) Potassium 5.1 mmol/L (3.5-5.3) Urea 10.3 mmol/L (2.5-7.8) Creatinine 159 μmol/L (60–120) She has been treated with 3 L of 0.9% sodium chloride since admission, with a urine output of 400 mL in total and 10–20 mL/hr for the past 4 hours.

Which is the most appropriate next step in management?

A. Haemofiltration
B. Intravenous 500 mL gelatin over 30 minutes
C. Intravenous 500 mL 0.9% sodium chloride over 30 minutes
D. Intravenous furosemide bolus
E. Intravenous noradrenaline/norepinephrine infusion

**Answer**: E

**Explanation**: Intravenous noradrenaline/norepinephrine infusion is the most appropriate next step in management. The patient is presenting with signs of sepsis and is experiencing hypotension despite adequate fluid resuscitation. This suggests septic shock, and the most appropriate next step in management is to initiate vasopressor support, such as noradrenaline/norepinephrine infusion, to increase systemic vascular resistance and maintain blood pressure. Haemofiltration may be appropriate if the patient develops worsening acute kidney injury, but it is not the first-line management for septic shock. Intravenous gelatin or sodium chloride may provide additional fluid resuscitation however the central venous pressure of +12 mmHg suggests adequate fluid replacement and further volume expansion will not address the underlying hypotension. Intravenous furosemide may exacerbate the patient’s hypotension and should be avoided.

---
### 451. Question 451
A 43 year old man has vomiting and increased pain due to not being able to take oral medication. He has inoperable cancer of the bowel with hepatic and peritoneal metastases. He has back pain due to tumour infiltration which had previously been controlled with regular codeine phosphate at maximum dosage

**Investigations:**
Creatinine 85 µmol/L (60–120)

Which is the most appropriate drug to control his pain?

A. Buprenorphine transdermal patch
B. Codeine phosphate intramuscular injection
C. Fentanyl transdermal patch
D. Morphine sulfate continuous subcutaneous infusion
E. Tramadol hydrochloride intramuscular injection

**Answer**: D

**Explanation**: In this case, the most effective drug to control the patient’s pain would likely be morphine sulfate continuous subcutaneous infusion. This is because the patient is unable to take oral medication due to bowel obstruction and vomiting. The use of an intramuscular injection would be painful to administer and only provide intermittent analgesia, whereas the patient needs continuous analgesia. Buprenorphine transcutaneous patch and fentanyl transcutaneous patch would not be appropriate as his pain may change due to the progressive bowel obstruction and therefore not be stable enough for transcutaneous analgesia.

---
### 452. Question 452
A 35 year old woman finds a small firm lump on self examination of her breast. It is excised and is a firm, well-circumscribed solid mass, 2 cm in diameter. Histology shows a discrete mass with duct-like structures lined by regular columnar cells, separated by loose fibrous tissue

Which is the most likely diagnosis?

A. Carcinoma in situ
B. Ductal carcinoma
C. Fibroadenoma
D. Intraductal papilloma
E. Paget's disease of the breast

**Answer**: C

**Explanation**: The histological description of duct-like structures lined by regular, low columnar cells separated by loose fibrous tissue, with well-defined margins is consistent with a fibroadenoma. These are the most common benign breast lumps in young women, often presenting as a solitary, painless, firm, mobile mass. They can be surgically removed if they are causing discomfort or for cosmetic reasons. Carcinoma in situ and ductal carcinoma are malignant breast cancer and would have different histological features. Intraductal papilloma presents as a small, soft, often palpable mass and can be associated with nipple discharge. Paget’s disease of the breast presents with nipple and areolar changes, such as erythema, scaling, and ulceration, and is usually associated with an underlying invasive or in situ breast carcinoma.

---
### 453. Question 453
A 22 year old woman has intense itching and pain in her right ear that has gradually worsened over several days. She says that her hearing appears to be affected. She is a surfer. She has debris in the right ear canal, and the tympanic membrane is not visible. There is pain on pulling the pinna

Which is the most likely diagnosis?

A. Cholesteatoma
B. Mastoiditis
C. Otitis externa
D. Otitis media
E. Ruptured tympanic membrane

**Answer**: C

**Explanation**: Otitis externa is an inflammation or infection of the external auditory canal and is commonly associated with water exposure, as in swimmers and surfers. Pulling the pinna, or pressure on the tragus often exacerbates the pain.

---
### 454. Question 454
A 35 year old woman has a painful lump in her breast. Her mother had breast cancer at the age of 65 years. She is 32 weeks pregnant with no past medical history. She is not taking any medication. She smokes 5 cigarettes per day. There is a 2 cm lump in her right breast that is tender on palpation. There is redness of the overlying skin

Which is the most appropriate management?

A. Bilateral mammogram
B. No further investigations until after delivery
C. Start oral cefalexin
D. Surgical excision of lump
E. Triple assessment

**Answer**: E

**Explanation**: Triple assessment is the most appropriate management for a pregnant woman with a breast lump. This includes clinical examination, imaging (usually ultrasound), and biopsy. Whilst the most likely diagnosis is a breast abscess, pregnancy does not preclude the possibility of breast cancer and should be excluded in this case. It is important to fully investigate breast lumps in pregnant women promptly to ensure early diagnosis and treatment if necessary.

---
### 455. Question 455
A 35 year old woman is admitted unconscious to the Emergency Department after being found collapsed outside a pub. There was an empty vodka bottle lying next to her. Her pulse is 86 bpm, BP 112/62 mmHg, respiratory rate 12 breaths per minute and oxygen saturation is 98% breathing air

Which is the most important immediate investigation?

A. Arterial blood gas
B. Blood alcohol level
C. Capillary blood glucose
D. Urea and electrolytes
E. Urinary drug screen

**Answer**: C

**Explanation**: Capillary blood glucose is the most important immediate investigation to exclude hypoglycaemia (particularly in the context of alcohol) or hyperglycaemia. Although an arterial blood gas may be helpful, there is no evidence of respiratory compromise, and a venous blood gas may be appropriate (following a capillary blood glucose) to exclude a metabolic cause of this collapse. Blood alcohol level is likely to be high based upon the history and would not be the most important immediate investigation. Although urea and electrolytes are important investigations to consider, a capillary blood glucose would be more important to do immediately. A urinary drug screen may be helpful if the diagnosis is unclear, but this is not the most important immediate investigation.

---
### 456. Question 456
A 28 year old woman has a lobar pneumonia and is treated with intravenous amoxicillin. A few minutes after she is given the antibiotic therapy, she develops an itchy skin eruption and increased breathlessness

Which is the most likely mechanism of this reaction?

A. Antibody binding to cell-bound antigen
B. Complement activation
C. Delayed-type hypersensitivity
D. Immediate hypersensitivity
E. Immune complex hypersensitivity

**Answer**: D

**Explanation**: This patient is experiencing an anaphylactic reaction, which is a type of immediate hypersensitivity reaction. It is caused by the release of histamine and other mediators from mast cells and basophils in response to an allergen. The symptoms include skin rash, itching, and shortness of breath. Treatment involves immediate cessation of the offending agent, administration of epinephrine, and supportive care.

---
### 457. Question 457
A 39 year old woman has had worsening tiredness for 2 weeks. She was previously well. She is mildly jaundiced. Her pulse is 96 bpm and BP 112/76 mmHg

**Investigations:**
Haemoglobin 48 g/L (115–150) White cell count 6.2 × 109/L (4.0–11.0) Platelets 165 × 109/L (150–400) Mean cell volume (MCV) 98 fL (80–96) Alkaline phosphatase 100 IU/L (25–115) Aspartate aminotransferase (AST) 27 IU/L (10–40) Bilirubin (total) 41 µmol/L (< 21) Lactate dehydrogenase 560 IU/L (70–250) Blood film: red cell polychromasia, occasional spherocytes, no red cell fragments

Which is the most appropriate diagnostic investigation?

A. Bone marrow aspiration
B. Direct antiglobulin test
C. Serum antinuclear antibody
D. Serum folate
E. Serum vitamin B₁₂

**Answer**: B

**Explanation**: Based on the provided information, the most appropriate diagnostic investigation is direct antiglobulin test (coombs test). The patient has anaemia with raised bilirubin and LDH but otherwise normal liver function tests. The polychromasia on the film is due to an increase in reticulocytes and together these laboratory results are consistent with haemolytic anaemia (evidence of both increased RBC production and destruction). The recent history suggests an acquired not hereditary cause and there are spherocytes on the film in keeping with autoimmune haemolytic anaemia. The diagnosis would be confirmed by a direct antiglobulin test which tests for immunoglobulin or complement on the surface of red cells. &nbsp;Bone marrow causes of anaemia, B12 and folate deficiency can also cause anaemia and raised LDH but the blood film appearances, including increased red cell production, are not in keeping with this diagnosis. Therefore, bone marrow aspiration, B12 and folate are not as appropriate next investigations. Antinuclear antibody is also not a diagnostic investigation for haemolysis.

---
### 458. Question 458
A 65 year old woman has two episodes of vaginal bleeding. Her last menstrual period was 12 years ago. Abdominal and pelvic examination are normal. Pelvic ultrasound scan shows an endometrial thickness of 10 mm

Which is the most appropriate next investigation?

A. CA 125
B. Cervical cytology
C. CT scan of pelvis, abdomen and chest
D. Hysteroscopy and endometrial biopsy
E. MR scan of pelvis

**Answer**: D

**Explanation**: The most common cause of postmenopausal bleeding is atrophic vaginitis, however, endometrial cancer must be excluded. The initial evaluation of women with postmenopausal bleeding is an ultrasound to measure the endometrial thickness. If the thickness is >4 mm, further investigation is needed. In this case, since the endometrial thickness is 10 mm, hysteroscopy and endometrial biopsy are the most appropriate next investigations to evaluate for endometrial cancer. CA 125 is not specific for endometrial cancer and can be elevated in other conditions as well. Cervical cytology is not indicated in postmenopausal bleeding unless cervical cancer is suspected. CT and MR scans are not the initial investigations for postmenopausal bleeding.

---
### 459. Question 459
A 25 year old man develops a muscle contraction in his neck causing pain and an involuntary rotation of his neck. He was admitted to the psychiatric unit 24 hours ago with persecutory delusions, agitation, and auditory hallucinations. He has been given risperidone since admission

Which side effect is he experiencing?

A. Akathisia
B. Autonomic instability
C. Dystonia
D. Parkinsonism
E. Tardive dyskinesia

**Answer**: C

**Explanation**: The patient is exhibiting symptoms of acute dystonia, which is a side effect of antipsychotic medication such as risperidone. It is characterised by muscle spasms and contractions, often in the neck and facial muscles. Treatment includes anticholinergic medication such as benztropine or diphenhydramine.

---
### 460. Question 460
An 18 year old woman with sickle cell disease attends the Emergency Department with severe pain in her left leg. She rates her pain score as 8/10. Her temperature is 36.9°C, pulse is 110 bpm, BP 120/80 mmHg, respiratory rate 16 breaths per minute and oxygen saturation 96% breathing air

**Investigations:**
White cell count 7.1 x 109/L (4.0–11.0) Haemoglobin 71 g/L (115–150) Platelets 190 × 109/L (150–400)

Which is the next management step?

A. Intravenous co-amoxiclav
B. Oral prednisolone
C. Red cell transfusion
D. Subcutaneous morphine
E. Treatment dose dalteparin

**Answer**: D

**Explanation**: This patient has sickle cell disease and is presenting with severe pain crisis. Treatment of an acute painful sickle cell crisis needs to be considered an acute medical emergency. Pain must be assessed immediately and treated with an acute bolus of a strong opioid such as morphine. The patient is afebrile with a normal white cell count and thus no evidence of infection, and hence antibiotics such as co-amoxiclav are not indicated at this stage. Oral prednisolone may be used to treat acute chest syndrome, but is not the first-line treatment for pain crisis. There is no immediate urgency for red cell transfusion in an acute pain crisis although it can be considered at a later stage. Treatment dose dalteparin is indicated in patients with sickle cell disease who have a high risk of thromboembolism, but it is not indicated for this patient’s current presentation.

---
### 461. Question 461
A 79 year old woman has had malaise and pain in the arms and legs for 4 weeks, with morning stiffness that lasts for 3 hours each day. She has difficulty washing and dressing. She cannot lift her arms above her head due to pain, but there is no objective muscle weakness. She has Heberden's nodes in her hands

**Investigations:**
Haemoglobin 112 g/L (115–150) White cell count 9.8 × 109/L (4.0–11.0) Platelets 365 × 109/L (150–400) Mean cell volume (MCV) 89 fL (80–96) CRP 67 mg/L (<5)

Which is the most likely diagnosis?

A. Osteoarthritis
B. Osteomalacia
C. Polymyalgia rheumatica
D. Polymyositis
E. Rheumatoid arthritis

**Answer**: C

**Explanation**: The most likely diagnosis is Polymyalgia rheumatica. This is based on the patient’s age, symptoms of malaise and pain in the arms and legs, morning stiffness lasting for 3 hours each day, difficulty washing and dressing, inability to lift her arms above her head, and elevated CRP. Heberden’s nodes are not a feature of polymyalgia rheumatica but are seen in osteoarthritis. Rheumatoid arthritis would present with joint inflammation. Osteomalacia is a metabolic bone disease, which is unlikely to cause these symptoms. Polymyositis would be associated with muscle weakness, which is not present in this case.

---
### 462. Question 462
A 30 year old woman becomes acutely short of breath. She was admitted to hospital 3 hours ago with an acute exacerbation of asthma. She improved following treatment with oxygen, nebulised salbutamol and oral prednisolone. Her chest X-ray on admission was clear. Her pulse is 122 bpm, BP 88/50 mmHg, respiratory rate 30 breaths per minute and oxygen saturation 88% breathing 40% oxygen via a face mask. She has reduced expansion of the upper left chest. She has mild wheeze throughout the chest with reduced breath sounds over the left apex

Which is the most likely explanation for her deterioration?

A. Anaphylaxis
B. Increasing severity of asthma
C. Lobar collapse
D. Pneumothorax
E. Pulmonary embolus

**Answer**: D

**Explanation**: Based on the given information, the most likely explanation for her deterioration would be the development of a pneumothorax following admission based on the acute nature of her symptoms, reduced breath sounds on examination and association with her history of asthma. The reduced expansion of the upper left chest and reduced breath sounds over the left apex could suggest a possible collapse of the left upper lobe of the lung however one would expect to see changes on the chest X-ray. Anaphylaxis, increasing severity of asthma, and pulmonary embolus can all cause respiratory distress, but do not explain the physical examination findings.

---
### 463. Question 463
A 40 year old man had a laparotomy for intestinal obstruction 12 hours ago. He has an epidural for analgesia and has been given a 500 mL intravenous crystalloid bolus. He has no pain. He has no pre-existing medical problems. His pulse is 120 bpm and BP 80/62 mmHg. He has passed 10 mL of urine in the past 4 hours. He shows no sign of heart failure

Which is the most appropriate first line of management?

A. IV diuretic
B. IV fluid bolus
C. IV vasoconstrictor
D. Place bed head down
E. Stop epidural analgesia

**Answer**: B

**Explanation**: The most appropriate first line of management for this patient would be IV fluid bolus. The patient has signs of hypovolemia, including tachycardia, hypotension, and oliguria. The 500 mL intravenous crystalloid bolus he received may not have been sufficient to address his ongoing fluid losses following the laparotomy. Therefore, another fluid bolus is indicated to improve his perfusion and restore his blood pressure. IV diuretic would not be appropriate as the patient is hypovolemic, and administering a diuretic would exacerbate his intravascular volume depletion. IV vasoconstrictor could be considered if the patient's hypotension persists despite adequate fluid resuscitation, but it is not the first-line treatment. Placing the bed head down may help with improving venous return and increasing blood pressure, but it would not be the first-line management in this case, especially since the patient is oliguric and if prolonged could risk cephalad spread of epidural solution. Stopping epidural analgesia may be considered if there is a concern for epidural-induced hypotension, but it is not the most appropriate first-line management in this situation. Reference: Faculty of Pain Management Best Practice in the Management of Epidural Analgesia in the Hospital Setting available at https://fpm.ac.uk/sites/fpm/files/documents/2020-09/Epidural-AUG-2020- FINAL.pdf

---
### 464. Question 464
A 23 year old man has had joint pains for the last 6 months. He thinks he may have contracted hepatitis B following unprotected sex 6 months ago and is unsure of his hepatitis B vaccination status

**Investigations:**
HBsAg –ve anti-HBc IgG +ve anti-HBs IgG +ve

Which is the best description of his hepatitis B status?

A. Acute infection
B. Chronic infection
C. Immune due to naturally resolved infection
D. Immune due to previous vaccination for hepatitis B
E. Not infected but susceptible to further infection

**Answer**: C

**Explanation**: Based on the given information, the best description of his hepatitis B status would be immune due to naturally resolved infection. The negative HBsAg and positive anti-HBc IgG and anti-HBs IgG results suggest that the patient has been exposed to hepatitis B virus in the past but has cleared the infection, leading to the development of immunity against the virus. The presence of anti-HBs IgG indicates that the patient has developed protective antibodies against the virus, likely through natural infection or previous vaccination. Acute infection would be characterised by the presence of HBsAg, which is not present in this case. Chronic infection would be characterised by the presence of HBsAg for at least six months, which is not the case here. Immunity due to previous vaccination for hepatitis B could also be a possibility, but the patient is unsure of his vaccination status, and the presence of anti-HBc IgG suggests that he may have had a natural infection. Not infected but susceptible to further infection would be characterised by negative results for all hepatitis B markers, which is not the case here.

---
### 465. Question 465
A 65 year old woman has had headaches for 3 months. She was treated for cancer of the right breast 12 years ago. There is no evidence of local or regional recurrence. Examination of the central nervous system is normal. CT scan of brain shows an isolated metastasis with cerebral oedema

Which is the most appropriate immediate treatment?

A. Anastrozole
B. Chemotherapy
C. Dexamethasone
D. Radiotherapy
E. Surgical decompression

**Answer**: C

**Explanation**: The most appropriate immediate treatment for this patient would be Dexamethasone. The patient has an isolated metastasis in the brain with cerebral oedema, which can cause significant symptoms and can be life-threatening if left untreated. Dexamethasone is a corticosteroid that can help to reduce cerebral oedema and alleviate symptoms such as headaches. It is commonly used as an initial treatment for brain metastases. Anastrozole is a hormonal therapy used for the treatment of breast cancer but would not be the appropriate treatment for this patient's current symptoms. Chemotherapy may be used for the treatment of metastatic breast cancer, but it would not be the most appropriate immediate treatment for this patient's presentation. Most chemotherapy drugs do not cross the blood brain barrier. Radiotherapy and surgical decompression are also treatment options for brain metastases, but they would not be the most appropriate immediate treatment for this patient. Radiotherapy (including stereotactic radiotherapy) and surgical intervention may be considered following complete radiological staging to define extent of metastatic disease and discussion at neuro-oncology MDM. These options are considered following control of initial symptoms with dexamethasone.

---
### 466. Question 466
A 45 year old man has had two hours of colicky left sided abdominal pain radiating to his groin. The pain started abruptly and is associated with nausea and vomiting. He is restless and writhing in pain. There is tenderness on palpation of the left costovertebral angle. Abdominal examination is normal. Bowel sounds are present but scanty. His urinalysis shows blood 3+ and no other abnormalities

Which is the most appropriate initial analgesic agent?

A. Aspirin
B. Diclofenac
C. Oxycodone
D. Paracetamol
E. Tramadol

**Answer**: B

**Explanation**: The patient is presenting with symptoms consistent with renal colic, which is typically associated with severe, colicky pain that can radiate to the groin, nausea, and vomiting. The tenderness on palpation of the left costovertebral angle and the presence of blood in the urine (indicated by 3+ on urinalysis) suggest that the patient has a kidney stone causing the obstruction and pain. The most appropriate initial analgesic agent for this patient would be a nonsteroidal anti-inflammatory drug such as diclofenac. Tramadol and oxycodone are opioid analgesics that are effective for the treatment of moderate to severe pain, including renal colic, however, are not first line and should be used only if NSAIDs are contraindicated and following treatment with intravenous paracetamol. Aspirin is rarely used for its analgesic effects in renal colic. Paracetamol is an analgesic that can be used for mild to moderate pain but is second line (if given in intravenous form) to NSAIDs.

---
### 467. Question 467
A 70 year old man has had 1 day of cough and breathlessness. He has COPD and heart failure. His normal exercise tolerance is 100 m. He has had no previous hospital admissions. He has a 35 pack-year smoking history. He is taking lisinopril and uses a tiotropium inhaler. He is cyanosed and dyspnoeic. His pulse is 100 bpm, BP 105/78 mmHg, respiratory rate 30 breaths per minute and oxygen saturation 84% breathing 28% oxygen. He has scattered wheeze and crackles bilaterally. He has been given nebulised salbutamol

**Investigations:**
Arterial blood gas on 28% oxygen pH 7.25 (7.35-7.45) PO2 6.9 kPa (11-15) PCO2 7.8 kPa (4.6-6.4) Bicarbonate 34 mmol/L (22-30)

Which is the most appropriate next step in management?

A. Increase oxygen to 40% via a Venturi mask
B. Intravenous amoxicillin
C. Intravenous furosemide
D. Non-invasive ventilation
E. Reduce oxygen to 2 L/min via a nasal cannula

**Answer**: D

**Explanation**: The patient is experiencing an acute exacerbation of COPD and is in respiratory failure with a low oxygen level and high CO2 level (type II respiratory failure). The most appropriate next step in management would be to provide non-invasive ventilation (NIV) to help improve his gas exchange and reduce his work of breathing. NIV can be provided through a mask and helps to provide positive pressure to the airways, reducing the effort required by the patient to breathe. This can improve oxygenation, reduce CO2 retention, and reduce the need for invasive ventilation. Increasing the oxygen concentration alone is unlikely to improve the patient’s condition and could potentially worsen his hypercapnia. Antibiotics and diuretics may be indicated in some cases, but the priority in this scenario is to improve the patient’s respiratory status with NIV.

---
### 468. Question 468
A 2 day old boy undergoes his routine neonatal hearing screen. His mother has been deaf since early childhood and has bilateral hearing aids. She asks whether her baby will be deaf

Which is the most appropriate additional assessment?

A. Brainstem evoked response test
B. Cytomegalovirus serology
C. Distraction testing
D. MR scan of brain
E. Weber's test

**Answer**: A

**Explanation**: Brainstem evoked response test would be the most appropriate additional assessment in this case. This test measures the electrical activity in the auditory pathway in response to sound and can detect hearing loss even in newborn infants. It is a reliable and objective way of assessing the function of the auditory system and can identify hearing loss at an early stage, which is important for early intervention and treatment.

---
### 469. Question 469
A 52 year old woman has had two days of worsening confusion. She has chronic liver disease secondary to alcohol and has been abstinent for six months. She is disoriented in time and place, and is unable to hold a conversation. Her temperature is 37.1°C, pulse is 90 bpm and BP 119/80 mmHg. She has a distended abdomen, widespread spider naevi and a flapping tremor. She is given intravenous vitamin supplements

Which is the most appropriate additional management of her acute confusion?

A. Ciprofloxacin
B. Furosemide
C. Lactulose
D. Lorazepam
E. Restrict dietary protein intake to 60 g/day

**Answer**: C

**Explanation**: The most appropriate additional management of her acute confusion would be Lactulose. The patient is exhibiting signs of hepatic encephalopathy due to her chronic liver disease, which can cause confusion, disorientation, and other neurological symptoms. Lactulose is a standard treatment for hepatic encephalopathy as it helps to reduce the amount of ammonia in the blood, which can contribute to the neurological symptoms. Intravenous vitamin supplements may be helpful to address any nutritional deficiencies, but lactulose is the primary treatment for hepatic encephalopathy. Antibiotics such as ciprofloxacin may be used if there is evidence of infection, but there is no indication of infection in this scenario. Furosemide and protein restriction are not appropriate for hepatic encephalopathy. Lorazepam can be used to treat alcohol withdrawal however may worsen hepatic encephalopathy and should be used with caution in patients with liver disease.

---
### 470. Question 470
A 40 year old woman is admitted with a seizure. She is a primigravid woman, at 28 weeks' gestation. She had epigastric pain and blurred vision preceding the seizure. Her BP is 155/105 mmHg. Reflexes are brisk with two beats of ankle clonus. Her urinalysis shows protein 2+

What intravenous drug is the most appropriate immediate treatment?

A. Diazepam
B. Hydralazine
C. Levetiracetam
D. Magnesium sulfate
E. Phenytoin

**Answer**: D

**Explanation**: The most appropriate immediate treatment for this patient is magnesium sulfate. She is presenting with features of severe pre-eclampsia and eclampsia, which require urgent management to prevent maternal and foetal complications. Magnesium sulfate is the first-line treatment for preventing seizures in women with severe pre-eclampsia and eclampsia. Diazepam and phenytoin are not recommended for the prevention of seizures in pre-eclampsia/eclampsia. Hydralazine is a second-line agent for the control of hypertension, and levetiracetam is an antiepileptic drug that is not routinely used in the management of pre-eclampsia/eclampsia.

---
### 471. Question 471
A 15 month old girl has been able to sit unsupported for 1 month. She has a vocabulary of 4 separate words and can build a tower of 2 blocks using a pincer grip. She was born at 30 weeks' gestation

What is the best description of her current developmental progress?

A. Fine motor delay
B. General developmental delay
C. Gross motor delay
D. Mild developmental delay
E. Normal development

**Answer**: C

**Explanation**: The best description of the development is gross motor delay. A child should be able to sit unsupported by 7 months of age; speak at least 2 words and feed themselves using fingers or build a tower of 2 bricks using a pincer grip by 12 months of age. The fact that she was born at 30 weeks’s gestation i.e. 10 weeks premature, should be taken into consideration when assessing her development. Development may be delayed by approximately 10 weeks, but this does not explain the delay seen here. The delay is only in the sitting unsupported, which makes it gross motor delay.

---
### 472. Question 472
A 37 year old woman who is 10 weeks pregnant has experienced excessive vomiting for 1 week. The fundal height is consistent with 16 weeks' gestation. Her temperature is 37.2°C, pulse is 100 bpm and BP 180/110 mmHg

What is the most likely diagnosis underlying the clinical presentation?

A. Gastroenteritis
B. Missed abortion
C. Molar pregnancy
D. Pre-eclampsia
E. Pregnancy-induced hypertension

**Answer**: C

**Explanation**: The most likely diagnosis is molar pregnancy. This is the classic presentation of molar pregnancy as the underlying diagnosis with large for gestation uterus and severe early onset pre-eclampsia as a secondary phenomenon. Molar pregnancy can present with exaggerated symptoms of pregnancy such as excessive vomiting and rapidly increasing uterine size due to the proliferation of abnormal trophoblastic tissue. Additionally, elevated blood pressure can occur as a result of gestational trophoblastic disease-induced hypertension. Missed abortion must be diagnosed with an ultrasound and Pregnancy Induced Hypertension occurs after 20/40. Gastroenteritis would have normal-low BP, not raised.

---
### 473. Question 473
A 17 year old girl attends her GP with her mother. She has had severe headaches, stomach aches and has vomited four times over 2 days. She was invited to a close friend's birthday party but refused to attend. She is extremely shy and isolated, and has very few friends. She is always worried that others criticise her and is extremely sensitive to any rejection. She is also very attached to her mother

What personality disorder is most likely?

A. Avoidant
B. Dependent
C. Paranoid
D. Schizoid
E. Schizotypal

**Answer**: A

**Explanation**: The features described are consistent with avoidant personality disorder, which is characterised by social inhibition, feelings of inadequacy and hypersensitivity to criticism, and a strong desire for affection and acceptance. People with this disorder tend to avoid social situations and have few close relationships, often relying heavily on a single attachment figure. They may also experience physical symptoms such as headaches and stomach aches when faced with stress or anxiety-provoking situations.

---
### 474. Question 474
A 15 year old boy has had severe anorexia nervosa for one year. He is not acutely physically unwell. His weight is 75% of the expected weight for his height, age and sex

What is the most appropriate therapy?

A. Cognitive-analytic therapy
B. Cognitive-behaviour therapy
C. Family therapy
D. Non-directive counselling
E. Psychodynamic psychotherapy

**Answer**: C

**Explanation**: Family therapy is the first-line treatment for children and adolescents with anorexia nervosa, as it focusses on the family as a whole rather than just the individual with the disorder. It aims to improve family communication and functioning, and to help family members understand and support the individual's recovery. Other types of therapy, such as cognitive-behaviour therapy or psychodynamic psychotherapy, may be used in conjunction with family therapy to address specific symptoms or issues. https://cks.nice.org.uk/topics/eating-disorders/management/confirmed-eating- disorder/ (updated 2024)

---
### 475. Question 475
A 28 year old woman is elated in mood. She has not slept for 7 days and has been attending all-night parties. She is sexually disinhibited and believes that she is a member of the royal family. She was previously fit and well and has no past psychiatric history. A urine drug screen is negative

What is the most appropriate medication to prescribe?

A. Diazepam
B. Lithium carbonate
C. Olanzapine
D. Sodium valproate
E. Zuclopenthixol decanoate

**Answer**: C

**Explanation**: In this context olanzapine would be appropriate as it would act as both antipsychotic and sedative medication. Diazepam and zuclopenthixol decanoate are not the treatments of choice for mania. Lithium carbonate is a standard treatment for bipolar disorder, but it may take several days to become effective and is not appropriate for the acute management of severe mania. Sodium valproate is not prescribed to women of child-bearing age. Valproate is highly teratogenic and evidence supports that use in pregnancy leads to neurodevelopmental disorders (approx. 30–40% risk) and congenital malformations (approx. 10% risk). Valproate must not be used in women and girls of childbearing potential unless the conditions of the Pregnancy Prevention Programme are met and only if other treatments are ineffective or not tolerated, as judged by an experienced specialist. Clinical guideline [CG185] Published: 24 September 2014 Last updated: 21 December 2023 https://www.nice.org.uk/guidance/cg185/chapter/Recommendations

---
### 476. Question 476
A 6 month old baby vomited and developed an erythematous rash over her lips and chin, within minutes of being given formula milk for the first time. The rash took 1 hour to subside. The following week, the mother dripped a couple of drops of formula milk onto the baby's arm. The baby develops an erythematous rash over the arm within 1 minute of this. The mother is returning to work and does not wish to continue breastfeeding or expressing milk

What is the best management option?

A. Goat's milk formula
B. Hydrolysed formula
C. Lactose free formula
D. Latex free teat
E. Soya milk formula

**Answer**: B

**Explanation**: The best management option is hydrolysed formula. These symptoms suggest a potential allergic reaction to cow’s milk protein, prompting the need for an alternative formula that is less allergenic. Hydrolysed formula contains proteins that are broken down into smaller fragments, making them less likely to trigger an allergic response compared to intact cow’s milk protein. Goat’s milk is not recommended for infants as it has similar protein structures to cow’s milk and can cause similar allergic reactions. Lactose-free formula is not necessary unless the infant has a diagnosed lactose intolerance, which is rare in infants. A latex-free teat may be needed if the infant has a latex allergy, but this is not relevant in this case. Soya milk is not recommended for infants under 6 months of age, as it may also cause an allergic reaction and may contain phyto-oestrogens.

---
### 477. Question 477
A 28 year old woman is admitted with a sudden onset of abdominal pain and vaginal bleeding. She is 38 weeks pregnant. Her pulse is 120 bpm and BP 110/80 mmHg. She has a tender abdomen. The fetal heart rate is 170 bpm

What is the most likely diagnosis?

A. Necrosis of a fibroid
B. Placenta praevia
C. Placental abruption
D. Pre-term labour
E. Uterine rupture

**Answer**: C

**Explanation**: The most likely diagnosis is placental abruption. Placental abruption occurs when the placenta separates prematurely from the uterine wall before delivery, leading to maternal and fetal complications including abdominal pain, vaginal bleeding, and fetal distress. The sudden onset of abdominal pain and vaginal bleeding along with the tender abdomen and tachycardia are suggestive of this diagnosis. The high fetal heart rate may indicate fetal distress. Prompt evaluation and management are necessary to optimise the chances of a successful outcome for both the mother and the baby.

---
### 478. Question 478
A 60 year old man believes that the government has been monitoring him for 10 years, despite him repeatedly writing to the Prime Minister to ask for this to stop. His beliefs are present whatever his mood. He has never heard voices when nobody else is around

What is the most likely diagnosis?

A. Anankastic personality disorder
B. Delusional disorder
C. Depression with psychosis
D. Paranoid schizophrenia
E. Schizoid personality disorder

**Answer**: B

**Explanation**: The most likely diagnosis is delusional disorder. The delusions have not escalated or changed for significant period and are considered to be "non-bizarre" i.e. situations that are not real but also not impossible. These beliefs began 10 years old so this is not a personality disorder as symptoms were not present since late adolescence. There are no other symptoms commonly seen in schizophrenia, such as hearing voices or experiencing disorganised speech and behaviour.

---
### 479. Question 479
A 35 year old woman has started to bleed heavily following a normal vaginal delivery and delivery of the placenta. She had gestational hypertension and was induced at 40 weeks' gestation

What is the most appropriate initial management?

A. Carboprost
B. Ergometrine
C. Oxytocin
D. Misoprostol
E. Tranexamic acid

**Answer**: C

**Explanation**: The most appropriate management for postpartum haemorrhage following delivery of the placenta in a woman with gestational hypertension is oxytocin, as it can help to contract the uterus and reduce bleeding. Carboprost, and misoprostol may also be used if oxytocin is ineffective, but they can cause adverse effects and should be used with caution. Ergometrine can exacerbate hypertension and is essentially contra- indicated in hypertension. Tranexamic acid may also be used as an adjunct therapy to help control bleeding, but it should not be used as the sole treatment. However, the specific management will depend on the severity of the bleeding and other clinical factors, and close monitoring of the patient is essential.

---
### 480. Question 480
A 23 year old woman has barricaded herself with her baby in the bathroom, shouting that it is unsafe to come out because the house is infected. She thinks that someone is trying to kill her and her baby. Her mood has not been low at any stage. She is four days post-caesarean section, and her physical recovery has been uncomplicated. She was not on any medication during her pregnancy. She drinks 20 units of alcohol a week. She is orientated in time and place

What is the most likely diagnosis?

A. Alcohol withdrawal
B. Delirium
C. Obsessive-compulsive disorder
D. Post-natal depression
E. Puerperal psychosis

**Answer**: E

**Explanation**: Puerperal psychosis is the most likely diagnosis in this case. Puerperal psychosis is a rare but serious mental illness that affects women in the days or weeks following childbirth. It typically presents with symptoms such as delusions, hallucinations, confusion, agitation, and a lack of insight into the illness. Risk factors include a personal or family history of mental illness, a difficult or traumatic childbirth, and lack of social support. Treatment often involves hospitalisation, medication, and support from mental health professionals. It is important to seek help quickly in order to provide the best possible outcome for both the mother and baby.

---
### 481. Question 481
A 20 year old woman seeks contraceptive advice. She had unprotected sexual intercourse 4 days ago. Her last menstrual period was 16 days ago. She has a 28 day cycle. She has been using condoms reliably as her method of contraception until this incident

What is the most appropriate method of contraception?

A. Copper-containing intrauterine device
B. Ella-One ® (ulipristal acetate postcoital contraception)
C. Intrauterine progestogen system (Mirena coil)
D. Levonelle ® (levonorgestrel) postcoital contraception
E. Postcoital contraception not appropriate

**Answer**: A

**Explanation**: The most appropriate method of contraception after unprotected sexual intercourse is emergency contraception. The options for emergency contraception include the copper-containing intrauterine device (IUD) and emergency contraceptive pills. The copper containing IUD is highly effective up to 5 days post UPSI (nearly 100% effective) and is therefore the most appropriate option at this stage. COCP and high dose progestogens can also be used but are less effective. Depot and Mirena are not licenced for emergency contraception.

---
### 482. Question 482
A 3 year old girl has had a fever and a runny nose for 2 days. She is alert but miserable. Her temperature is 39.6°C, pulse is 150 bpm (95- 140), BP 105/62 mmHg (90/50-120/80), respiratory rate 36 breaths per minute (20-30) and oxygen saturation 97% in air. She has a red throat and looks flushed with a flat, erythematous rash across her trunk and face that feels rough. There is no rash around her mouth

What is the most likely diagnosis?

A. Kawasaki disease
B. Measles
C. Parvovirus infection
D. Rhinovirus infection
E. Scarlet fever

**Answer**: E

**Explanation**: The most likely diagnosis is scarlet fever. Scarlet fever is a bacterial infection caused by Group A Streptococcus. It typically presents with a high fever, sore throat, and a characteristic sandpaper-like rash that starts on the trunk and spreads to the extremities. The cheeks may look flushed with often a pale area around the mouth. Measles can cause fever and rash, but typically presents with a cough, runny nose, and red, watery eyes. Parvovirus infection can cause a rash, but it is typically milder and not associated with a fever. Kawasaki disease can also cause a fever and rash, but it usually presents with conjunctivitis, swollen lymph nodes, and redness and later peeling of the hands and feet. Rhinovirus infection can cause a runny nose, but is not typically associated with fever or rash.

---
### 483. Question 483
A 28 year old primigravida attends the antenatal clinic at 35 weeks' gestation. She has 2 weeks of persistent itching of her palms, soles and abdomen. Her pregnancy has been uncomplicated to date, and she is feeling good foetal movements. She has red scratch marks on her abdomen with no rash

What is the most appropriate diagnostic investigation?

A. Anti-mitochondrial antibody
B. Iron studies
C. Liver function tests
D. Thyroid function tests
E. Urea and electrolytes

**Answer**: C

**Explanation**: The most appropriate investigation in this case is liver function tests. The persistent itching and scratch marks suggest obstetric cholestasis, a liver disorder that occurs in pregnancy. Liver function tests are important to assess the degree of hepatic dysfunction, and elevated serum bile acids would confirm the diagnosis. Other investigations such as anti-mitochondrial antibody, iron studies, thyroid function tests, and urea and electrolytes would not be helpful in diagnosing obstetric cholestasis.

---
### 484. Question 484
A full term newborn boy is discharged home 48 hours after birth. The next day, his 2 year old sibling develops a florid chickenpox rash. His mother has detectable varicella antibodies. The newborn remains clinically well

What is the most appropriate management decision?

A. Admit for observation
B. Check the newborn's antibody status for varicella antibodies
C. No action is necessary
D. Treat with Aciclovir
E. Treat with zoster immune globulin

**Answer**: C

**Explanation**: The most appropriate management decision is no action is necessary. The newborn remains clinically well, and the mother has detectable varicella antibodies, indicating likely passive immunity transfer to the newborn. The fact that the newborn is clinically well also supports a conservative approach with no specific treatment or observation required.

---
### 485. Question 485
A 56 year old woman has had 2 months of intermittent vertigo, which typically occurs when turning over in bed or looking over her shoulder while driving. Each episode lasts for up to 1 minute. She has no hearing loss, tinnitus or ear pain

Which further action is most likely to confirm the diagnosis?

A. Audiometry
B. CT scan of head
C. Dix–Hallpike manoeuvre
D. Epley manoeuvre
E. MR of internal auditory meatus

**Answer**: C

**Explanation**: The Dix-Hallpike manoeuvre is used to evaluate for benign paroxysmal positional vertigo (BPPV), when caused by canalithiasis in the posterior semicircular canal. During the Dix-Hallpike manoeuvre, the patient is quickly moved from a seated position to a lying position with the head turned to one side, which causes displacement of free- floating calcium carbonate crystals (otoconia) in the inner ear. The manoeuvre is diagnostic if it elicits vertigo and nystagmus (involuntary eye movement) in patients with BPPV. Most cases are clinically diagnosed and imaging is not helpful. https://cks.nice.org.uk/topics/benign-paroxysmal-positional- vertigo/diagnosis/diagnosis/

---